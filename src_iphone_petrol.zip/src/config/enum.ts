export const EnumVanBanDenAction = {
  Priority: 1,
  Recall: 2,
  Comment: 4,
  Forward: 8,
  ReAssignment: 16,
  Assignment: 32,
  SubmitBOD: 64,
  RecallOrForward: 128,
  Completed: 256,
  CommentBOD: 512,
  FowardArchives: 1024,
  RecallBOD: 2048,
  Share: 32768,
}

export const TypeSelectUser = {
  Single: 0,
  Multiple: 1
}

export const TinNoiBoType = {
  DashBoard: 0,
  News: 1,
  Horizontal: 2,
  Vertical: 3,
  ListLoadMore: 4
}

export const TypeDatVeMayBay = {
  DangKy: "Đăng ký",
  PhieuToiTao: "Phiếu tôi tạo",
  ChoPheDuyet: "Chờ phê duyệt",
  ChoMuaVe: "Chờ mua vé",
  DaMuaVe: "Đã mua vé",
  TatCa: "Tất cả"
}

export const ViewModeTinNoiBo = {
  Horizontal: 1,
  Vertical: 2,
}

export const EnumTaskAction = {
  //Action 4,8,64,128 sẽ không có trong bản Mobile Tập đoàn
  Save: 1,//Lưu
  Assignment: 2,//Phân công
  CreateRecord: 4,//Lập hồ sơ xử lý
  CreateRecordDraft: 8,//Lập hồ sơ dự thảo
  Feedback: 16,//Trao đổi lại
  Completed: 32,//Hoàn tất
  Again: 64,//Thực hiện lại
  Evalute: 128//Đánh giá
}

export const EnumTaskRole = {
  AssignedTo: 64,//Người nhận Task
  Assignor: 320,//Người giao Task
  AssignorPBan: 256,//Phòng ban giao Task
  Viewer: 0//Người xem
}
