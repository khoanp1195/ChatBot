export const getTextSplit=(text:string,splitReg:string, positionTake:number)=>{
    if(text.includes(splitReg))
    {
        return text.split(splitReg)[positionTake];
    }
    else
    {
        return text;
    }
}