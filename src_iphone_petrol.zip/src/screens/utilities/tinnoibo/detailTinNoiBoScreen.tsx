import { Text, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import { WebView } from "react-native-webview";
import { getFullLink } from "../../../config/constants.ts";
import React from "react";
import { getScreenWidth } from "../../../utils/functions.ts";
import { useSelector } from "react-redux";

export const DetailTinNoiBoScreen=()=>{
  const navigation=useNavigation();
  const route= useRoute();
  const parent =useSelector((state: any) => state.tinNoiBo.item);

  // @ts-ignore
  const item= route.params["item"];
  return <View style={{flex:1}}>
    <ModalTopBar title={`Tin nội bộ / ${parent!=undefined?parent.Title:""}`} onPress={()=>navigation.goBack()}/>
    <WebView
      style={{ height:'100%',width:getScreenWidth(), backgroundColor:'white' }}
      originWhitelist={['*']}
      source={{ uri: getFullLink()+`/news/SitePages/DetailNewsMobile.aspx?IID=${item.ID}&CID=${item.CategoryId}&Isdlg=1&IsMobile=1`}}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
    />
  </View>
}
