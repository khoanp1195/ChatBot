import { useDispatch, useSelector } from "react-redux";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { getLeftMenu } from "../../services/api/apiTinNoiBo.ts";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";

export const LeftMenuTinNoiBoScreen=()=>{
  const dispatch= useDispatch();
  const navigation=useNavigation();
  const item =useSelector((state: any) => state.tinNoiBo.item);
  const [id, setID] = useState(0);
  useEffect(()=>{
    getLeftMenu().then(value => {
      if(item!=undefined)
      {
        const currentID=value?.findIndex(r=>r.Title==item.Title);
        // @ts-ignore
        setID(currentID);
      }
      // @ts-ignore
      setData(value);
    });
  },[])
  const [data,setData]= useState();
  return (
    <View style={styles.container}>
      {
        // @ts-ignore
        data != undefined &&data.map((item) => (
        <TouchableOpacity key={item.ID} onPress={() => {
          if (item.EnableClick) {
            // @ts-ignore
            setID(item.ID);
            dispatch(changePageTypeTinNoiBo(item));
            navigation.dispatch(DrawerActions.closeDrawer());
          }
        }}>
          <View style={styles.rowContainer}>
            <View style={[styles.indicator, { backgroundColor: id === item.ID ? '#0072C6' : 'white' },
              (id !== item.ID && item.IsParent) && { backgroundColor: '#F5F5F5CC' }]} />
            <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? '#E6F5FF80' : 'white' },
              (id !== item.ID && item.IsParent) && { backgroundColor: '#F5F5F5CC' }]}>
              <Image source={item.Icon} style={styles.icon} />
              <Text style={[styles.title, item.IsParent && { fontWeight: 'bold' }]}>{item.Title}</Text>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
  },
  rowContainer: {
    flexDirection: 'row',
  },
  indicator: {
    width: 10,
    height: 50,
  },
  itemContainer: {
    flexDirection: 'row',
    width: '96%',
    padding: 10,
    alignItems: 'center',
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10,
  },
  title: {
    color: '#000000',
  },
});

