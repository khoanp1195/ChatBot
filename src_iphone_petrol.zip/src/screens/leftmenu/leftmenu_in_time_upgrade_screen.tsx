import React from 'react';
import { ImageBackground, View, StyleSheet } from 'react-native';

export const LeftMenuInTimeUpgradeScreen = () => {
  return (
    <View style={styles.container}>
      <ImageBackground style={styles.image} source={require('../../assets/images/img_under_dev.png')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '100%',
    flex: 1,
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 50,
  },
});
