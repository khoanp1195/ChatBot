import { FlatList, Image, Text, TouchableOpacity, View,StyleSheet } from "react-native";
import ReactNativeCalendarStrip from "react-native-calendar-strip";
import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
import { showLeftMenuCalendar, showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import { useCallback, useEffect, useState } from "react";
import BaseScreen from "../../components/basescreen.tsx";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import { getDisplayTxtFromDateString, getDisplayTxtFromHourString } from "../../utils/functions.ts";
import moment, { isDate } from "moment";
import { appMainBlueColor } from "../../utils/color.ts";
import { getListDonVi, getMeetingCalendars } from "../../services/api/api_calendar.ts";
import Empty_view from "../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";

export const CalendarScreen = () => {
  moment.locale("en");
  const dispatch = useDispatch();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(new Date().toLocaleDateString());
  const [donvi, setDonVi] = useState();
  const [lichhHop, setlichhHop] = useState();
  const [firstDayofWeek, setfirstDayofWeek] = useState(new Date());
  const [lastDayOfWeek, setlastDayOfWeek] = useState(new Date())
  const [titledonvi, settitledonvi] = useState("");
  const itemUnitSelected = useSelector((state: any) => state.lichtuan.item);
  const onChangedUnitCalendar = useSelector((state: any) => state.lichtuan.reload)
  console.log("itemUnitSelected - here - title " + onChangedUnitCalendar)


  // const [flag, setFlag] = useState()
  const datesBlacklistFunc = (date: { isoWeekday: () => number; }) => {
    return date.isoWeekday() === 6 || date.isoWeekday() === 7; // disable Saturdays
  };
  const tabs = [
    { title: "Lịch lãnh đạo" },
    { title: "Lịch ban" },
    { title: "Lịch của tôi" }
  ];

  const [indexTab, setIndexTab] = useState(0);
  const [isFullWeek, setIsFullWeek] = useState(false);

  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const getColorByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case "Lịch dự kiến":
          return '#A7FFA5'
        case "Điều chỉnh":
          return '#ACB0EE';
        case "Hủy lịch":
          return '#FF8685';
        case "Hoãn":
          return '#FFD770';
        default:
          return '#E7F8FF';
      }
    }
    const getColorBorderByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case "Lịch dự kiến":
          return '#A7FFA5'
        case "Điều chỉnh":
          return '#ACB0EE';
        case "Hủy lịch":
          return '#FF8685';
        case "Hoãn":
          return '#FFD770';
        default:
          return '#8ECFFF';
      }
    }

    const getStatusItem = (StatusItem: any) => {
      switch (StatusItem) {
        case 1:
          return "Bổ sung"
        case 2:
          return "Điều chỉnh";
        case 3:
          return "Hoãn";
        case 4:
          return "Dự kiến";
        default:
          return '';
      }
    }

    return <View style={{
      borderWidth: 1.5,
      borderRadius: 10,
      flexDirection: "row",
      alignItems: "center",
      alignContent: "center",
      justifyContent: "center",
      marginTop: 10,
      borderColor: getColorBorderByAppStatus(item.Status)
    }}>
      <View style={{
        padding: 10,
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
        flexDirection: "column",
        flex: 3,
        height: "100%",
        backgroundColor: getColorByAppStatus(item.Status),
        alignItems: "center"
      }}>

        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.StartTime)}</Text>
          <Text> - </Text>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.EndTime)}</Text>
        </View>

        <View style={{
          // borderWidth: 1,
          // borderRadius: 3,
          width: "100%",
          alignItems: "center"
        }}>
          <Text>{getStatusItem(item.StatusItem)}</Text>
        </View>
        <Text style={{ marginTop: '15%' }}>{item.LocationTitle}</Text>


        {
          item.MeetingLink != undefined && item.MeetingLink != "" ? (<View style={{ flexDirection: "row", marginTop: '45%' }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
              source={require("../../assets/images/icon_meeting_call.png")} />
            <Text>Vào link họp</Text>
          </View>) : null
        }


      </View>
      <View style={{
        flexDirection: "column",
        flex: 7,
        height: "100%",
        padding: 10,
        backgroundColor: "white",
        borderTopRightRadius: 9,
        borderBottomRightRadius: 9
      }}>
        <Text>{item?.Title}</Text>
        <View style={{
          width: "100%",
          height: 1,
          borderWidth: 0.5,
          marginTop: '3%',
          borderColor: "#474747",
          borderStyle: "dashed"

        }} />
        <View style={{ flexDirection: "column", marginTop: 20 }}>
          <View style={{ flexDirection: "row", marginBottom: 10 }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_user_calendar.png")} />
            <Text>{item.HostTitle}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_group_calendar.png")} />
            <Text style={{ width: '80%', marginLeft: '2%' }}>{item.PreparerDetail}</Text>
          </View>
        </View>
      </View>
    </View>;
  };
  console.log("selectedDate = >: ", selectedDate);


  useEffect(() => {
    getListDonVi().then(data => {
      if (data != null) {
        setDonVi(data)
      }
      calculateWeekBounds();

      loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 1, "")
      console.log("onLoading - here 2 => " + onLoading)
    })    


  
  }, [onLoading])

  const handleChange = () => {
   console.log("data changed")
  };


  const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag: number, keyConnection: any) => {
    const data = await getMeetingCalendars(fromDate, toDate, flag, keyConnection);
    if (data != null) {
      setlichhHop(data)
      return data;
    } else {
      return [];
    }
  };

  const OnClickUnit = (item: any) => {
    // @ts-ignore
    navigation.navigate("Calendar_unit", { item: donvi,
    onSelected: (title: string, siteConnection: string) =>{
      settitledonvi(title)

    }
    })
  };
  const onDateChanged = (date: any) => {
    setSelectedDate(date)
    loadListCalendarByWeek(date, date, 2, "")
  };

  const changeTab = (index: any) => {
    loadListCalendarByWeek(selectedDate, selectedDate, getFlag(index), "")
  }

  const getStartOfWeek = () => {
    let toDay = new Date()
    let dayOfWeek = toDay.getDate()
    let diff = toDay.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Adjust when today is Sunday
    return new Date(toDay.setDate(diff));
  }
  const calculateWeekBounds = () => {
    const firstDay = getStartOfWeek();
    const lastDay = new Date(firstDay);
    lastDay.setDate(firstDay.getDate() + 6); // Add 6 days to get the last day of the week
    setfirstDayofWeek(firstDay);
    setlastDayOfWeek(lastDay);
  };
  const formatDate = (date: any) => {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };


  LocaleConfig.locales["vn"] = {
    monthNames: [
      "Tháng 1",
      "Tháng 2",
      "Tháng 3",
      "Tháng 4",
      "Tháng 5",
      "Tháng 6",
      "Tháng 7",
      "Tháng 8",
      "Tháng 9",
      "Tháng 10",
      "Tháng 11",
      "Tháng 12"
    ],
    monthNamesShort: [
      "Th 1",
      "Th 2",
      "Th 3",
      "Th 4",
      "Th 5",
      "Th 6",
      "Th 7",
      "Th 8",
      "Th 9",
      "Th 10",
      "Th 11",
      "Th 12"
    ],
    dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
  };

  LocaleConfig.defaultLocale = "vn";

  const getFlag = (index: number) => {
    switch (index) {
      case 0:
        return 2
      case 1:
        return 1;
      case 2:
        return 3;
    }
  }

  return (
    <BaseScreen>
      <View style={{ height: "100%", backgroundColor: "white" }}>
        <PetroAppBarCustom
          title={"Lịch tuần"}
          rightAction={
            <TouchableOpacity onPress={() => {
              setIsFullWeek(!isFullWeek);
            }}>
              <Image style={{ height: 25, width: 25 }} source={
                !isFullWeek ?
                  require("../../assets/images/icon_change_type_date.png") :
                  require("../../assets/images/icon_change_type_week.png")
              } />
            </TouchableOpacity>
          }
          onPress={() => {
            dispatch(showLeftMenuCalendar());
            // @ts-ignore
            navigation.openDrawer();
          }} />
        <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

        {/* <ReactNativeCalendarStrip
          locale={{
            name: "vi",
            config: {
              months: [
                "Tháng 1",
                "Tháng 2",
                "Tháng 3",
                "Tháng 4",
                "Tháng 5",
                "Tháng 6",
                "Tháng 7",
                "Tháng 8",
                "Tháng 9",
                "Tháng 10",
                "Tháng 11",
                "Tháng 12"
              ],
              weekdaysShort: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
              weekdays: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"]
            }
          }}
          datesBlacklist={datesBlacklistFunc}
          highlightDateNameStyle={{ color: "#0072C6" }}
          highlightDateNumberStyle={{ color: "#0072C6" }}
          scrollable
          // @ts-ignore
          selectedDate={Date.now()}
          style={{
            width: "100%",
            height: 60
          }} /> */}

        <View style={{ height: 80, backgroundColor: "cyan" }}>
          <CalendarProvider
            date={moment(new Date()).format("YYYY-MM-DD")} // date={"2024-01-01"}
            //@ts-ignore
            onDateChanged={(date) => { onDateChanged(date) }}
            disabledOpacity={1}
            showTodayButton={true}
          >
            <WeekCalendar testID={'weekCalendar'}
              firstDay={1}
              theme={{
                backgroundColor: '#ffffff',
                calendarBackground: 'white',//#ffffff
                textSectionTitleColor: 'black',
                selectedDayBackgroundColor: appMainBlueColor,//'#00adf5'
                selectedDayTextColor: '#ffffff',
                todayTextColor: appMainBlueColor,// '#00adf5'
                dayTextColor: 'black',
              }}
              disableOnPageChange={true}
            />
          </CalendarProvider>
        </View>

        <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

        <TouchableOpacity
          style={{ paddingVertical: 10, paddingHorizontal: 15, flexDirection: "row", backgroundColor: "white" }}
          onPress={(item) => {
            OnClickUnit(item);
          }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
            source={require("../../assets/images/icon_focus_contact.png")} />
          <Text style={{ color: "black", fontWeight: "bold", fontSize: 16, backgroundColor: "white" }}>{itemUnitSelected.Title}</Text>
        </TouchableOpacity>

        <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

        <Tab
          value={indexTab}
          onChange={(index) => {
            setIndexTab(index);
            // setFlag(index)
            console.log("Index here " + index)
            changeTab(index)
          }}

          indicatorStyle={{ backgroundColor: "#0072C6", height: 3, borderRadius: 100, marginHorizontal: 4 }}
        >
          {tabs.map((tab, index) => (
            <Tab.Item key={index} title={tab.title} containerStyle={{ backgroundColor: "white" }} titleStyle={{
              fontSize: 12,
              color: "#000000",
              height:30,
              width:'100%'
            }} />
          ))}
        </Tab>

        <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA", marginTop: 5 }} />
        <ScrollView style={{ alignContent: 'center' }} >
          {lichhHop != undefined && lichhHop.length > 0 ? (
            <FlatList
              data={lichhHop}
              renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              style={{ padding: 10 }}
            />
          ) : (
            <View style={styles.viewNoData}>
            <Text style={styles.textNoData}>Không có dữ liệu</Text>
          </View>)}
        </ScrollView>
      </View>
    </BaseScreen>
  );
};
const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    marginTop:'50%',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#5E5E5E',
    fontStyle:'italic'
  },
});
