import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import { useNavigation, useRoute } from '@react-navigation/native'
import { FlatList } from 'react-native-gesture-handler';
import { ModalTopBar } from '../../components/modalTopBar';
import { useDispatch } from 'react-redux';
import { changeDataDonvi } from '../../stores/lichtuan/actions';

export const Calendar_unit = ({ route }: any) => {
  const navigation = useNavigation();
  const item = route.params["item"];
  const dispatch = useDispatch();
  const Item = ({ item, index }: any) => {
    return (
      <TouchableOpacity onPress={() => {
        console.log("Item cliked: " + item.Title)
        dispatch(changeDataDonvi(item));
        if (navigation.canGoBack())
             navigation.goBack();
      }
      }>
        <Text style={{ color: 'black' }}>{item.Title}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{ backgroundColor: 'brown', flex: 1 }}>
      <ModalTopBar
        title={"Đơn vị"}
        rightAction={undefined}
        onPress={() => {
          navigation.goBack()
        }}
      />
      <FlatList
        data={item} // Assuming item is an array
        renderItem={({ item, index }) => <Item item={item} index={index} />}
        keyExtractor={item => item.id} // Ensure item has an id property
        scrollEnabled={false}
        style={styles.flatList}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  flatList: {
    backgroundColor: 'white', // Example background color
    paddingHorizontal: 20, // Example padding horizontal
    paddingVertical: 10, // Example padding vertical

  },
})
export default Calendar_unit