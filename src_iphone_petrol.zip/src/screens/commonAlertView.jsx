import React from 'react';
import { Alert } from 'react-native';
import strings from "../assets/strings.ts";
import { isNullOrEmpty } from "../utils/functions.ts";

export const showAlert = (message, is1Button = true, onPress = () => { }, title1 = '', title2 = '') =>
    Alert.alert(
        strings.AlertTitle,
        message,
        is1Button ? [
            {
                text: !isNullOrEmpty(title1) ? title1 : "Đóng",//'Cancel',
                // onPress: () => Alert.alert('Cancel Pressed'),
                style: 'cancel',
            },
        ] : [
            {
                text: title1,//'Cancel',
                style: 'cancel',
            },
            {
                text: title2, //'Yes',
                onPress: () => onPress(),//Alert.alert('Cancel Pressed'),
                style: 'default'
            },
        ]
        ,
        {
            cancelable: true,
            onDismiss: () =>
                Alert.alert(
                    'This alert was dismissed by tapping outside of the alert dialog.',
                ),
        },
    );
