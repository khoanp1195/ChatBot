import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { getVBDen } from "../../../services/api/api_doc.ts";
import { CustomFlatListRefreshLoadMore } from "../../../components/custom_flat_list_refresh_loadmore.tsx";
import { useNavigation } from "@react-navigation/native";
import { ItemOfListNoChild } from "../menu_no_child/item_of_list_no_child.tsx";
import { PetroAppBarCustom } from "../../../components/petro_appbar_custom.tsx";
import {
  VBDenChoChoYKien,
  VBDenChoThucHien,
  VBDenDaGiaiQuyet, VBDenTatCa, VBDenThongBao,
  VBDenTitle
} from "../../../stores/base_screen/action_types.ts";
// import { addMonths, format } from "date-fns";
import { FilterComponent } from "../../../components/filterComponent.tsx";
import { CustomCalendarView } from "../../../components/customCalendarView.tsx";
import { DbServices } from "../../../services/database/db_service.ts";
import { isNullOrEmpty } from "../../../utils/functions.ts";

// @ts-ignore
export const VBDenScreen = ({ action }) => {
  const navigation = useNavigation();
  const [status, setStatus] = useState(0);
  const [totalRecord, setTotalRecord] = useState("");
  const [title, setTitle] = useState("");
  const [isShowSearch, setIsShowSearch] = useState(false);
  const [isShowFilter, setIsShowFilter] = useState(false);
  const [fromDate, setFromDate] = useState(addMonths(new Date(), -1));
  const [toDate, setToDate] = useState(new Date());
  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexCalendarSelect, setIndexCalendarSelect] = useState(0);
  const [filterText, setFilterText] = useState("");

  const [dataFilter, setDataFilter] = useState({
    FromDate: "",
    ToDate: "",
    FilterText: filterText,
    BanLanhDao: "",
    LoaiVanBan: ""
  });
  const [banLanhDaoSelected, setBanLanhDaoSelected] = useState({
    ID: "",
    Title: "Tất cả"
  });
  const [lstBanLanhDao, setLstBanLanhDao] = useState([{
    ID: "",
    Title: "Tất cả"
  }]);
  const [loaiVanBanSelected, setLoaiVanBanSelected] = useState({
    ID: 1,
    Title: "Tất cả"
  });
  const lstLoaiVanBan = [
    {
      ID: 1,
      Title: "Tất cả"
    },
    {
      ID: 2,
      Title: "Trình Lãnh đạo"
    },
    {
      ID: 3,
      Title: "Chuyển đơn vị"
    },
    {
      ID: 4,
      Title: "Hoàn tất"
    }
  ];
  useEffect(() => {
    DbServices.getInstance().getBanLanhDaoRepository().findAll().then(value => {
      if (lstBanLanhDao.length == 1) {
        // @ts-ignore
        setLstBanLanhDao((prevData) => [...prevData, ...value]);
      }
    });
  }, []);
  useEffect(() => {
    switch (action) {
      case VBDenTitle:
        setTitle("Văn bản đến");
        break;
      case VBDenChoChoYKien:
        setTitle("Chờ cho ý kiến");
        break;
      case VBDenChoThucHien:
        setTitle("Chờ thực hiện");
        break;
      case VBDenDaGiaiQuyet:
        setTitle("Đã xử lý");
        break;
      case VBDenThongBao:
        setTitle("Thông báo");
        break;
      case VBDenTatCa:
        setTitle("Tất cả");
        break;
    }
  }, []);
  const getData = async (limit: number, offset: number) => {
    const data = await getVBDen(action, limit, offset, status, dataFilter.FromDate, dataFilter.ToDate, dataFilter.FilterText, dataFilter.BanLanhDao, dataFilter.LoaiVanBan);
    if (data != null && data["Data"] != null) {
      if (status == 0) setTotalRecord(data["MoreInfo"][0]["totalRecord"]);
      return data["Data"];
    } else {
      return [];
    }
  };

  // @ts-ignore
  const item = ({ item, index }) => {
    if (action === VBDenTitle || action === VBDenThongBao)
      return <ItemOfListNoChild item={item}
        index={index}
        navigation={navigation}
        Action={item.Action}
        DueDate={item.DueDate}
        SendUnit={item.SendUnit}
        Priority={item.Priority}
        Content={item.Content}
        CategoryText={item.CategoryText}
        TaskCategory={item.TaskCategory}
        Created={item.Created}
        ImagePath={item.ImagePath}
      />;
    else
      item.ModuleId = 0;
    return <ItemOfListNoChild item={item}
      index={index}
      navigation={navigation}
      Action={item.TrangThai}
      DueDate={item.DueDate}
      SendUnit={item.CoQuanGuiText}
      Priority={item.DoKhan == "Thường" ? 0 : 1}
      Content={item.TrichYeu}
      CategoryText={item.ListName}
      TaskCategory={item.Title}
      Created={item.Created}
      ImagePath={item.ImagePath}
    />;
  };
  useEffect(() => {
    setTimeout(() => {
      getData(10, 0);
    }, 500);
  }, [status]);
  const ViewFilter = () => {
    return <View style={{ backgroundColor: "white" }}>
      <View style={{ width: "100%", height: 15, backgroundColor: "#F9F9F9" }} />
      <View style={{ padding: 10, flexDirection: "row" }}>
        <View style={{ flex: 1, flexDirection: "row" }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }}
            source={require("../../../assets/images/icon_loaivanban.png")} />
          <Text style={{ color: "black" }}>Lãnh đạo cho ý kiến</Text>
        </View>
        <TouchableOpacity onPress={() => {
          // @ts-ignore
          navigation.navigate("TypeSelectScreen",
            {
              data: lstBanLanhDao,
              enableAvatar: true,
              title: "Lãnh đạo cho ý kiến",
              selectedTitle: banLanhDaoSelected.Title,
              onSelected: (item: any) => {
                setBanLanhDaoSelected(item);
              }
            });
        }} style={{ flexDirection: "row", flex: 1, justifyContent: "flex-end" }}>
          <Text style={{ color: "black" }}>{banLanhDaoSelected.Title}</Text>
          <Image style={{ marginLeft: 10, height: 20, width: 20, padding: 4 }} resizeMode={"contain"}
            source={require("../../../assets/images/icon_leftmenu_user_next.png")} />
        </TouchableOpacity>
      </View>
      <View style={{ width: "100%", height: 15, backgroundColor: "#F9F9F9" }} />
      <View style={{ padding: 10, flexDirection: "row" }}>
        <View style={{ flex: 1, flexDirection: "row" }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }}
            source={require("../../../assets/images/icon_loaivanban.png")} />
          <Text style={{ color: "black" }}>Loại văn bản</Text>
        </View>
        <TouchableOpacity onPress={() => {
          // @ts-ignore
          navigation.navigate("TypeSelectScreen",
            {
              data: lstLoaiVanBan,
              selectedTitle: loaiVanBanSelected.Title,
              title: "Loại văn bản",
              onSelected: (item: any) => {
                setLoaiVanBanSelected(item);
              }

            });
        }} style={{ flexDirection: "row", flex: 1, justifyContent: "flex-end" }}>
          <Text style={{ color: "black" }}>{loaiVanBanSelected.Title}</Text>
          <Image style={{ marginLeft: 10, height: 20, width: 20, padding: 4 }} resizeMode={"contain"}
            source={require("../../../assets/images/icon_leftmenu_user_next.png")} />
        </TouchableOpacity>
      </View>
      <View style={{ width: "100%", height: 15, backgroundColor: "#F9F9F9" }} />
      <View style={{ padding: 10, flexDirection: "row" }}>
        <View style={{ flexDirection: "row", flex: 1 }}>
          <Image style={{ height: 20, width: 20, padding: 4 }} resizeMode={"contain"}
            source={require("../../../assets/images/icon_calendar.png")} />
          <Text style={{ marginLeft: 10, color: "black" }}>Ngày đến</Text>
        </View>
      </View>
      <View style={{ marginHorizontal: 10, width: "100%", height: 2, backgroundColor: "#F9F9F9" }} />
      <View style={{ flexDirection: "row" }}>
        <View style={{ flex: 1, padding: 10 }}>
          <TouchableOpacity onPress={() => {
            setIndexCalendarSelect(0);
            setIsVisibleCalendar(!isVisibleCalendar);
          }}>
            <Text style={{ color: "#5E5E5E" }}>Từ ngày</Text>
            <Text>{format(fromDate, "dd/MM/yy")}</Text>
          </TouchableOpacity>
        </View>

        <View style={{ flex: 1, padding: 10, borderLeftWidth: 1, borderLeftColor: "#F9F9F9" }}>
          <TouchableOpacity onPress={() => {
            setIndexCalendarSelect(1);
            setIsVisibleCalendar(!isVisibleCalendar);
          }}>
            <Text style={{ color: "#5E5E5E" }}>Đến ngày</Text>
            <Text>{format(toDate, "dd/MM/yy")}</Text>
          </TouchableOpacity>

        </View>
      </View>
      <View style={{ flexDirection: "row", justifyContent: "flex-end", padding: 10 }}>
        <TouchableOpacity style={{ padding: 10 }} onPress={() => {
          setFromDate(addMonths(new Date(), -1));
          setToDate(new Date());
          setIsShowFilter(false);
          setIsShowSearch(false);
          setLoaiVanBanSelected({
            ID: 1,
            Title: "Tất cả"
          });
          setBanLanhDaoSelected({
            ID: "",
            Title: "Tất cả"
          });
          setDataFilter({
            FromDate: "",
            ToDate: "",
            FilterText: "",
            BanLanhDao: "",
            LoaiVanBan: ""
          });
        }}>
          <Text style={{ color: "#0072C6" }}>Thiết lập lại</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{ padding: 10, backgroundColor: "#0072C6", borderRadius: 5 }} onPress={() => {
          setIsShowFilter(false);
          setDataFilter({
            FromDate: format(fromDate, "yyyy-MM-dd"),
            ToDate: format(toDate, "yyyy-MM-dd"),
            FilterText: filterText,
            BanLanhDao: isNullOrEmpty(banLanhDaoSelected.ID.toString()) ? "" : banLanhDaoSelected.Title,
            LoaiVanBan: loaiVanBanSelected.ID == 1 ? "" : loaiVanBanSelected.Title
          });
        }}>
          <Text style={{ color: "white", marginHorizontal: 20 }}>Áp dụng</Text>
        </TouchableOpacity>
      </View>
    </View>;
  };


  return (
    <View style={{ marginBottom: action === VBDenTitle || action === VBDenThongBao ? 230 : 110 }}>
      <PetroAppBarCustom
        title={title}
        onPress={() => {
          // @ts-ignore
          navigation.openDrawer();
        }}
        rightAction={<View style={{ flexDirection: "row" }}>
          <TouchableOpacity onPress={() => setIsShowSearch(!isShowSearch)}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
              source={require("../../../assets/images/icon_search.png")} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setIsShowFilter(!isShowFilter)}>
            <Image style={{ height: 20, width: 20 }} resizeMode={"contain"}
              source={require("../../../assets/images/icon_filter.png")} />
          </TouchableOpacity>
        </View>}
      />
      {

        isShowSearch && <TextInput value={filterText} onChangeText={text => {
          setFilterText(text);
          setDataFilter({
            FromDate: dataFilter.FromDate,
            ToDate: dataFilter.ToDate,
            FilterText: text,
            LoaiVanBan: dataFilter.LoaiVanBan,
            BanLanhDao: dataFilter.BanLanhDao
          });
        }} />
      }
      {
        action == VBDenTitle || action === VBDenThongBao ? <View style={styles.container}>
          <View style={styles.statusContainer}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => {
                setStatus(0);
              }}
              style={status == 0 ? styles.activeLanguage : styles.inactiveLanguage}
            >
              <View style={{ flexDirection: "row" }}>
                <Text style={status == 0 ? styles.languageTextActive : styles.languageTextUnActive}>
                  VB {
                    action === VBDenTitle || action === VBDenThongBao ? "chưa đọc" : "chờ xử lý"
                  }

                </Text>
                {
                  parseInt(totalRecord, 0) > 0 &&
                  <Text style={{ color: "#FF7A3A", fontWeight: "500" }}>({totalRecord})</Text>
                }
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => {
                setStatus(1);
              }}
              style={status == 0 ? styles.inactiveLanguage : styles.activeLanguage}
            >
              <Text style={status == 0 ? styles.languageTextUnActive : styles.languageTextActive}>
                VB {
                  action === VBDenTitle || action === VBDenThongBao ? "đã đọc" : "đã xử lý"
                }
              </Text>
            </TouchableOpacity>
          </View>
        </View> : <View />
      }

      <CustomFlatListRefreshLoadMore
        key={status + JSON.stringify(dataFilter)}
        ItemRenderFlatlist={item} limit={10}
        callData={getData}
        enableMoreData={true} numColumn={1} />

      {isShowFilter &&
        <FilterComponent onPressOutSite={() => {
          setIsShowFilter(!isShowFilter);
        }}>
          <ViewFilter />
        </FilterComponent>}

      {isVisibleCalendar &&
        <CustomCalendarView
          onTouchOutSite={() => setIsVisibleCalendar(!isVisibleCalendar)}
          onPressDate={(date: { year: number; month: number; day: number | undefined; } | undefined) => {
            if (date != undefined) {
              if (indexCalendarSelect == 0) {
                setFromDate(new Date(date.year, date.month, date.day));
              } else {
                setToDate(new Date(date.year, date.month, date.day));
              }
            }
            setIsVisibleCalendar(false);
          }}
        />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white"
  },
  statusContainer: {
    height: 30,
    width: "60%",
    backgroundColor: "#0072C6",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#0072C6",
    flexDirection: "row",
    justifyContent: "center",
    bottom: 0,
    margin: 10
  },
  inactiveLanguage: {
    flex: 1,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0072C6"
  },
  activeLanguage: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center"
  },
  itemContainer: {
    padding: 10
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%"
  },
  avatar: {
    height: 35,
    width: 35
  },
  detailsContainer: {
    width: "100%",
    marginLeft: 10
  },
  senderText: {
    color: "#19191E",
    fontSize: 15,
    fontWeight: "400",
    textAlign: "left",
    width: "45%"
  },
  dateText: {
    color: "#5E5E5E",
    fontSize: 12,
    fontWeight: "400",
    textAlign: "right",
    width: "45%"
  },
  categoryText: {
    width: "40%",
    color: "#5E5E5E",
    fontSize: 12
  },
  taskCategoryText: {
    width: "50%",
    textAlign: "right",
    color: "#5E5E5E",
    fontSize: 12
  },
  titleText: {
    width: "100%",
    color: "#000000",
    fontSize: 15,
    paddingVertical: 10
  },
  actionContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%"
  },
  actionBox: {
    backgroundColor: "#D1E9FF",
    padding: 5,
    borderRadius: 5
  },
  actionText: {
    color: "#0072C6",
    fontSize: 12
  },
  priorityBox: {
    width: 25,
    height: 25,
    marginLeft: 5,
    backgroundColor: "red"
  },
  dueDateText: {
    width: "50%",
    textAlign: "right"
  },
  languageTextUnActive: {
    color: "white"
  },
  languageTextActive: {
    color: "#0072C6"
  }
});
