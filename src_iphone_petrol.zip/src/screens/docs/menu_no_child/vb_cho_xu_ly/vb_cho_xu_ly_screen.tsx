import { Image, Modal, Pressable, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import React, { FC, memo, useEffect, useState } from "react";
import { getVBChoXuLy } from "../../../../services/api/api_doc.ts";
import { CustomFlatListRefreshLoadMore } from "../../../../components/custom_flat_list_refresh_loadmore.tsx";
import { useNavigation } from "@react-navigation/native";
import { ItemOfListNoChild } from "../item_of_list_no_child.tsx";
import { PetroAppBarCustom } from "../../../../components/petro_appbar_custom.tsx";
import { FilterComponent } from "../../../../components/filterComponent.tsx";
// import { addMonths, format } from "date-fns";
import { CustomCalendarView } from "../../../../components/customCalendarView.tsx";
interface Props{
  isHigh:boolean
}
export const VBChoXuLyScreen:FC<Props> = memo(({isHigh}) => {
  const navigation = useNavigation();
  const [status, setStatus] = useState(0);
  const [totalRecord, setTotalRecord] = useState("");
  const [isShowSearch, setIsShowSearch] = useState(false);
  const [isShowFilter, setIsShowFilter] = useState(false);
  const [fromDate, setFromDate] = useState(addMonths(new Date(), -1));
  const [toDate, setToDate] = useState(new Date());
  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexCalendarSelect, setIndexCalendarSelect] = useState(0);
  const [filterText, setFilterText] = useState("");
  const [typeSelect, setTypeSelect] = useState({
    moduleId: "",
    Title: "Tất cả"
  });
  const [dataFilter, setDataFilter] = useState({
    FromDate: "",
    ToDate: "",
    FilterText: filterText,
    moduleId: ""
  });
  const lstType = [
    {
      moduleId: "",
      Title: "Tất cả"
    },
    {
      moduleId: "3",
      Title: "Văn bản đến"
    },
    {
      moduleId: "7",
      Title: "Văn bản đi"
    }
  ];
  const getData = async (limit: number, offset: number) => {
    const data = await getVBChoXuLy(limit, offset, status, dataFilter.moduleId, dataFilter.FromDate, dataFilter.ToDate, dataFilter.FilterText,isHigh);
    if (data != null && data["Data"] != null) {
      if (status == 0) setTotalRecord(data["MoreInfo"][0]["totalRecord"]);
      return data["Data"];
    } else {
      return [];
    }
  };

  // @ts-ignore
  const item = ({ item, index }) => {
    return <ItemOfListNoChild item={item}
      index={index}
      navigation={navigation}
      Action={item.Action}
      DueDate={item.DueDate}
      SendUnit={item.SendUnit}
      Priority={item.Priority}
      Content={item.ModuleId === 10 ? item.Title : item.Content}
      CategoryText={item.CategoryText}
      TaskCategory={item.TaskCategory}
      Created={item.Created}
      ImagePath={item.ImagePath}
    />;
  };

  useEffect(() => {
    setTimeout(() => {
      getData(10, 0);
    }, 500);
  }, [status]);
  const ViewFilter = () => {
    return <View style={{ backgroundColor: "white" }}>
      <View style={{ width: "100%", height: 15, backgroundColor: "#F9F9F9" }} />
      <View style={{ padding: 10, flexDirection: "row" }}>
        <View style={{ flex: 1 }}>
          <Image style={{ height: 20, width: 20 }}
            source={require("../../../../assets/images/icon_loaivanban.png")} />
        </View>
        <TouchableOpacity onPress={() => {
          // @ts-ignore
          navigation.navigate("TypeSelectScreen",
            { title:'Loại',
              data: lstType,
              selectedTitle: typeSelect.Title,
              onSelected: (item: any) => {
                setTypeSelect(item);
              }
            });
        }} style={{ flexDirection: "row", flex: 1, justifyContent: "flex-end" }}>
          <Text style={{ color: "black" }}>{typeSelect.Title}</Text>
          <Image style={{ marginLeft: 10, height: 20, width: 20, padding: 4 }} resizeMode={"contain"}
            source={require("../../../../assets/images/icon_leftmenu_user_next.png")} />
        </TouchableOpacity>
      </View>
      <View style={{ width: "100%", height: 15, backgroundColor: "#F9F9F9" }} />
      <View style={{ padding: 10, flexDirection: "row" }}>
        <View style={{ flexDirection: "row", flex: 1 }}>
          <Image style={{ height: 20, width: 20, padding: 4 }} resizeMode={"contain"}
            source={require("../../../../assets/images/icon_calendar.png")} />
          <Text style={{ marginLeft: 10, color: "black" }}>Ngày đến</Text>
        </View>
      </View>
      <View style={{ marginHorizontal: 10, width: "100%", height: 2, backgroundColor: "#F9F9F9" }} />
      <View style={{ flexDirection: "row" }}>
        <View style={{ flex: 1, padding: 10 }}>
          <TouchableOpacity onPress={() => {
            setIndexCalendarSelect(0);
            setIsVisibleCalendar(!isVisibleCalendar);
          }}>
            <Text style={{ color: "#5E5E5E" }}>Từ ngày</Text>
            <Text>{format(fromDate, "dd/MM/yy")}</Text>
          </TouchableOpacity>
        </View>

        <View style={{ flex: 1, padding: 10, borderLeftWidth: 1, borderLeftColor: "#F9F9F9" }}>
          <TouchableOpacity onPress={() => {
            setIndexCalendarSelect(1);
            setIsVisibleCalendar(!isVisibleCalendar);
          }}>
            <Text style={{ color: "#5E5E5E" }}>Đến ngày</Text>
            <Text>{format(toDate, "dd/MM/yy")}</Text>
          </TouchableOpacity>

        </View>
      </View>
      <View style={{ flexDirection: "row", justifyContent: "flex-end", padding: 10 }}>
        <TouchableOpacity style={{ padding: 10 }} onPress={() => {
          setFromDate(addMonths(new Date(), -1));
          setToDate(new Date());
          setIsShowFilter(false);
          setIsShowSearch(false);
          setTypeSelect({
            moduleId: "",
            Title: "Tất cả"
          });
          setDataFilter({
            FromDate: "",
            ToDate: "",
            FilterText: "",
            moduleId: ""
          });
        }}>
          <Text style={{ color: "#0072C6" }}>Thiết lập lại</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{ padding: 10, backgroundColor: "#0072C6", borderRadius: 5 }} onPress={() => {
          setIsShowFilter(false);
          setDataFilter({
            FromDate: format(fromDate, "yyyy-MM-dd"),
            ToDate: format(toDate, "yyyy-MM-dd"),
            FilterText: filterText,
            moduleId: typeSelect.moduleId
          });
        }}>
          <Text style={{ color: "white", marginHorizontal: 20 }}>Áp dụng</Text>
        </TouchableOpacity>
      </View>
    </View>;
  };


  return (
    <View>
      <View style={{ marginBottom: 340 }}>
        <PetroAppBarCustom
          title={"Việc chờ xử lý"}
          rightAction={<View style={{ flexDirection: "row" }}>
            <TouchableOpacity onPress={() => setIsShowSearch(!isShowSearch)}>
              <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                source={require("../../../../assets/images/icon_search.png")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsShowFilter(!isShowFilter)}>
              <Image style={{ height: 20, width: 20 }} resizeMode={"contain"}
                source={require("../../../../assets/images/icon_filter.png")} />
            </TouchableOpacity>
          </View>}
          onPress={() => {
            // @ts-ignore
            navigation.openDrawer();
          }} />
        {
          isShowSearch && <TextInput
            placeholder={"Search"}
            value={filterText}
            onChangeText={text => {
              setFilterText(text);
              setDataFilter({
                FromDate: dataFilter.FromDate,
                ToDate: dataFilter.ToDate,
                FilterText: text,
                moduleId: dataFilter.moduleId
              });
            }} />
        }
        <View style={styles.container}>
          <View style={styles.statusContainer}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => {
                setStatus(0);
              }}
              style={status == 0 ? styles.activeLanguage : styles.inactiveLanguage}
            >
              <View style={{ flexDirection: "row" }}>
                <Text style={status == 0 ? styles.languageTextActive : styles.languageTextUnActive}>VB chờ xử lý</Text>
                <Text style={{ color: "#FF7A3A", fontWeight: "500" }}>({totalRecord})</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => {
                setStatus(1);
              }}
              style={status == 0 ? styles.inactiveLanguage : styles.activeLanguage}
            >
              <Text style={status == 0 ? styles.languageTextUnActive : styles.languageTextActive}>VB đã xử lý</Text>
            </TouchableOpacity>
          </View>
        </View>
        <CustomFlatListRefreshLoadMore key={status + JSON.stringify(dataFilter)} ItemRenderFlatlist={item} limit={10}
          callData={getData}
          enableMoreData={true} numColumn={1} />
      </View>
      {isShowFilter &&
        <FilterComponent onPressOutSite={() => {
          setIsShowFilter(!isShowFilter);
        }}>
          <ViewFilter />
        </FilterComponent>}
      {isVisibleCalendar &&
        <CustomCalendarView
          onTouchOutSite={() => setIsVisibleCalendar(!isVisibleCalendar)}
          onPressDate={(date: { year: number; month: number; day: number | undefined; } | undefined) => {
            if (date != undefined) {
              if (indexCalendarSelect == 0) {
                setFromDate(new Date(date.year, date.month, date.day));
              } else {
                setToDate(new Date(date.year, date.month, date.day));
              }
            }
            setIsVisibleCalendar(false);
          }}
        />}
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white"
  },
  statusContainer: {
    height: 30,
    width: "50%",
    backgroundColor: "#0072C6",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#0072C6",
    flexDirection: "row",
    justifyContent: "center",
    bottom: 0,
    margin: 10
  },
  inactiveLanguage: {
    flex: 1,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0072C6"
  },
  activeLanguage: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center"
  },
  itemContainer: {
    padding: 10
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%"
  },
  avatar: {
    height: 35,
    width: 35
  },
  detailsContainer: {
    width: "100%",
    marginLeft: 10
  },
  senderText: {
    color: "#19191E",
    fontSize: 15,
    fontWeight: "400",
    textAlign: "left",
    width: "45%"
  },
  dateText: {
    color: "#5E5E5E",
    fontSize: 12,
    fontWeight: "400",
    textAlign: "right",
    width: "45%"
  },
  categoryText: {
    width: "40%",
    color: "#5E5E5E",
    fontSize: 12
  },
  taskCategoryText: {
    width: "50%",
    textAlign: "right",
    color: "#5E5E5E",
    fontSize: 12
  },
  titleText: {
    width: "100%",
    color: "#000000",
    fontSize: 15,
    paddingVertical: 10
  },
  actionContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%"
  },
  actionBox: {
    backgroundColor: "#D1E9FF",
    padding: 5,
    borderRadius: 5
  },
  actionText: {
    color: "#0072C6",
    fontSize: 12
  },
  priorityBox: {
    width: 25,
    height: 25,
    marginLeft: 5,
    backgroundColor: "red"
  },
  dueDateText: {
    width: "50%",
    textAlign: "right"
  },
  languageTextUnActive: {
    color: "white"
  },
  languageTextActive: {
    color: "#0072C6"
  }
});
