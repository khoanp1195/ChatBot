import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { gotoDetailDocs } from "../../../screens/details/docs/detail_doc_handler.ts";
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
import { convertStringToMoment, isNullOrEmpty } from "../../../utils/functions.ts";
import React from "react";

/// Nhớ bỏ hết title, chỉ truyền 1 field title hoặc trich yếu cho item để hiển thị thôi
// @ts-ignore
export const ItemOfListNoChild = ({ navigation, item, index, ImagePath, SendUnit, CategoryText, TaskCategory, Content, Action, Priority, Created, DueDate }) => {
  return (
    <TouchableOpacity onPress={() => {
      gotoDetailDocs(navigation, item);
    }}>
      <View style={[styles.itemContainer, { backgroundColor: index % 2 == 0 ? "white" : "#F3F9FF" }]}>
        <View style={styles.rowContainer}>
          <View style={styles.avatar}>
            <CustomFastImage
              styleImg={{
                height: 40,
                width: 40,
                borderRadius: 100,
              }}
              urlOnline={getFullLink() + ImagePath}
              defaultImage={require("../../../assets/images/avatar80.jpg")} />
          </View>
          <View style={styles.detailsContainer}>
            <View style={styles.rowContainer}>
              <Text style={styles.senderText} numberOfLines={2}>{SendUnit}</Text>
              <Text style={styles.dateText}>
                {convertStringToMoment(Created).format("DD/MM/YYYY")}
              </Text>
            </View>
            <View style={styles.rowContainer}>
              <Text style={styles.categoryText}>{CategoryText}</Text>
              <Text style={styles.taskCategoryText} numberOfLines={1}>
                {TaskCategory}
              </Text>
            </View>
          </View>
        </View>
        <Text
          numberOfLines={2}
          style={[
            styles.titleText,
            {
              fontWeight: item["Status"] == 1 ? "400" : "bold"
            }
          ]}
        >
          {
            Content
          }
        </Text>
        <View style={styles.rowContainer}>
          <View style={styles.actionContainer}>
            <View style={[styles.actionBox, { opacity: isNullOrEmpty(Action) ? 0 : 1 }]}>
              <Text style={styles.actionText}>{Action}</Text>
            </View>
            {Priority == 1 &&
              <View style={{ padding: 5 }}>
                <Image style={{ height: 25, width: 20, resizeMode: 'stretch' }} source={require('../../../assets/images/icon_flag.png')} />
              </View>
            }
          </View>
          <Text style={styles.dueDateText}>
            {DueDate != null && convertStringToMoment(DueDate).format("DD/MM/yyyy")}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: "white"
  },
  statusContainer: {
    height: 30,
    width: "50%",
    backgroundColor: "#0072C6",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#0072C6",
    flexDirection: "row",
    justifyContent: "center",
    bottom: 0,
    margin: 10
  },
  inactiveLanguage: {
    flex: 1,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0072C6"
  },
  activeLanguage: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center"
  },
  itemContainer: {
    padding: 10
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%"
  },
  avatar: {
    height: 35,
    width: 35
  },
  detailsContainer: {
    width: "100%",
    marginLeft: 10
  },
  senderText: {
    color: "#19191E",
    fontSize: 15,
    fontWeight: "400",
    textAlign: "left",
    width: "60%"
  },
  dateText: {
    color: "#5E5E5E",
    fontSize: 12,
    fontWeight: "400",
    textAlign: "right",
    width: "30%"
  },
  categoryText: {
    width: "40%",
    color: "#5E5E5E",
    fontSize: 12
  },
  taskCategoryText: {
    width: "50%",
    textAlign: "right",
    color: "#5E5E5E",
    fontSize: 12
  },
  titleText: {
    width: "100%",
    color: "#000000",
    fontSize: 15,
    paddingVertical: 10
  },
  actionContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%"
  },
  actionBox: {
    backgroundColor: "#D1E9FF",
    padding: 5,
    borderRadius: 5
  },
  actionText: {
    color: "#0072C6",
    fontSize: 12
  },
  priorityBox: {
    width: 25,
    height: 25,
    marginLeft: 5,
  },
  dueDateText: {
    width: "50%",
    textAlign: "right"
  },
  languageTextUnActive: {
    color: "white"
  },
  languageTextActive: {
    color: "#0072C6"
  }
});
