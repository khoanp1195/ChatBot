import { Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { getVBPH } from "../../../../services/api/api_doc.ts";
import { CustomFlatListRefreshLoadMore } from "../../../../components/custom_flat_list_refresh_loadmore.tsx";
import { ItemOfListNoChild } from "../item_of_list_no_child.tsx";
import { PetroAppBarCustom } from "../../../../components/petro_appbar_custom.tsx";

export const VBPHScreen = () => {
  const navigation = useNavigation();
  const [status, setStatus] = useState(0);
  const [moduleId, setModuleId] = useState("");
  const [totalRecord, setTotalRecord] = useState("");
  const [filterText, setFilterText] = useState("");
  const [isShowSearch, setIsShowSearch] = useState(false);

  const getData = async (limit: number, offset: number) => {

    const data = await getVBPH(limit, offset, status, filterText);

    if (data != null && data["Data"] != null) {
      if (status == 0) setTotalRecord(data["MoreInfo"][0]["totalRecord"]);
      return data["Data"];
    } else {
      return [];
    }
  };

  // @ts-ignore
  const item = ({ item, index }) => {
    return <ItemOfListNoChild item={item}
      index={index}
      navigation={navigation}
      Action={item.Action}
      DueDate={""}//{item.DueDate}
      SendUnit={item.SendUnit}
      Priority={item.DoKhan == "Thường" ? 0 : 1}
      Content={item.TrichYeu}
      CategoryText={"Văn bản ban hành"}//{item.CategoryText}
      TaskCategory={item.TaskCategory}
      Created={item.Created}
      ImagePath={item.ImagePath}
    />;
  };
  useEffect(() => {
    setTimeout(() => {
      getData(10, 0);
    }, 500);
  }, [status]);

  return (
    <View style={{ marginBottom: 230 }}>
      <PetroAppBarCustom
        title={"Văn bản phối hợp"}
        rightAction={
          <TouchableOpacity onPress={() => setIsShowSearch(!isShowSearch)}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
              source={require("../../../../assets/images/icon_search.png")} />
          </TouchableOpacity>
        }
        onPress={() => {
          // @ts-ignore
          navigation.openDrawer();
        }} />
      {
        isShowSearch && <TextInput
          placeholder={"Search"}
          value={filterText}
          onChangeText={str => setFilterText(str)} />
      }
      <View style={styles.container}>
        <View style={styles.statusContainer}>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => {
              setStatus(0);
            }}
            style={[status == 0 ? styles.activeLanguage : styles.inactiveLanguage, { flexDirection: "row" }]}
          >
            <Text style={status == 0 ? styles.languageTextActive : styles.languageTextUnActive}>VB chờ xử lý</Text>
            {
              parseInt(totalRecord, 0) > 0 &&
              <Text style={{ color: "#FF7A3A", fontWeight: "500" }}>({totalRecord})</Text>
            }
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => {
              setStatus(1);
            }}
            style={status == 0 ? styles.inactiveLanguage : styles.activeLanguage}
          >
            <View style={{ flexDirection: "row" }}>
              <Text style={status != 0 ? styles.languageTextActive : styles.languageTextUnActive}>VB đã xử lý</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
      <CustomFlatListRefreshLoadMore key={status + filterText} ItemRenderFlatlist={item} limit={10} callData={getData}
        enableMoreData={true} numColumn={1} />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    backgroundColor: "white"
  },
  statusContainer: {
    height: 30,
    width: "70%",
    backgroundColor: "#0072C6",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#0072C6",
    flexDirection: "row",
    justifyContent: "center",
    bottom: 0,
    margin: 10
  },
  inactiveLanguage: {
    flex: 1,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0072C6"
  },
  activeLanguage: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center"
  },
  itemContainer: {
    padding: 10
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%"
  },
  avatar: {
    height: 35,
    width: 35
  },
  detailsContainer: {
    width: "100%",
    marginLeft: 10
  },
  senderText: {
    color: "#19191E",
    fontSize: 15,
    fontWeight: "400",
    textAlign: "left",
    width: "45%"
  },
  dateText: {
    color: "#5E5E5E",
    fontSize: 12,
    fontWeight: "400",
    textAlign: "right",
    width: "45%"
  },
  categoryText: {
    width: "40%",
    color: "#5E5E5E",
    fontSize: 12
  },
  taskCategoryText: {
    width: "50%",
    textAlign: "right",
    color: "#5E5E5E",
    fontSize: 12
  },
  titleText: {
    width: "100%",
    color: "#000000",
    fontSize: 15,
    paddingVertical: 10
  },
  actionContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%"
  },
  actionBox: {
    backgroundColor: "#D1E9FF",
    padding: 5,
    borderRadius: 5
  },
  actionText: {
    color: "#0072C6",
    fontSize: 12
  },
  priorityBox: {
    width: 25,
    height: 25,
    marginLeft: 5,
    backgroundColor: "red"
  },
  dueDateText: {
    width: "50%",
    textAlign: "right"
  },
  languageTextUnActive: {
    color: "white"
  },
  languageTextActive: {
    color: "#0072C6"
  }
});

