import {
  FlatList,
  Image,
  Keyboard,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import React, { useCallback, useEffect, useState } from "react";
import { SwipeableRight } from "../../../components/swipeableRight.tsx";
import { convertStringToMoment, getDisplayTxtFromDateString, getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { CustomCalendarView } from "../../../components/customCalendarView.tsx";
import { ListIdea } from "../../../screens/details/docDetail/listIdea.jsx";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { useDispatch, useSelector } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { LoadingScreen } from "../../../components/loadingScreen.tsx";
import { redirectScreen } from "../../../stores/base_screen/actions.ts";
import { ListDepartmentTask } from "../../../screens/details/docDetail/listDepartmentTask.tsx";
import { AssignmentHeaderView } from "../../../components/assignmentHeaderView.tsx";
import { getDataAssignTree } from "./assignHelper.tsx";
import { AssignItem } from "../../../components/assignItem.tsx";
import { currentUserStore } from "../../../config/constants.ts";
import { TextEditorWithBorder } from "../../../components/customTextEditor.tsx";
import strings from "../../../assets/strings.ts";

export const ReassignScreen = () => {
  const dispatch = useDispatch();
  const route = useRoute();
  const navigation = useNavigation();
  // const [index, setIndex] = useState(0);
  // const [departments, setDepartments] = useState();
  const [dataTreeView, setDataTreeView] = useState();
  const [dataPhanCong, setDataPhanCong] = useState();
  const [userComment, setUserComment] = useState("");
  // @ts-ignore
  const beanVanBanDen = route.params["beanVanBanDen"];
  // @ts-ignore
  // const lstTCTHClone = route.params["lstTCTH"];
  const [lstTCTHClone, setLstTCTHClone] = useState(route.params["lstTCTH"]);
  const [lstTCTH, setlstTCTH] = useState(lstTCTHClone);

  // console.log("ltct nè", JSON.stringify(lstTCTHClone))
  // @ts-ignore
  const lstYKienLanhDao = JSON.parse(beanVanBanDen.CommentJson);

  // @ts-ignore
  const btnAction = route.params["btnAction"];
  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexItemSetDueDate, setIndexItemSetDueDate] = useState(-1);
  // let removeDepartment: any[] = [];
  const [removeDepartment, setRemoveDepartment] = useState([]);
  const onLoading = useSelector((state: any) => state.loading.onLoading);

  useEffect(() => {
    //@ts-ignore
    getDataAssignTree(beanVanBanDen)
      .then(value => {
        console.log("cây nè:", JSON.stringify(value))
        setDataTreeView(value)
      });
  }, []);

  const submitAction = () => {
    beanVanBanDen.NguoiDanhGiaUserValue = currentUserStore.getCurrentUser().AccountID + ";#" + currentUserStore.getCurrentUser().Title
    beanVanBanDen.YKien = userComment
    //Phòng ban
    // @ts-ignore
    if (dataPhanCong != undefined && dataPhanCong.length > 0) {
      // @ts-ignore
      beanVanBanDen.ListAssignmentUsers = dataPhanCong.map(department => {
        var hanXuLy = isNullOrEmpty(department.HanXuLy) ? "" : getDisplayTxtFromDateString(department.HanXuLy, strings.SubmitFormatDate);

        if (!department.IsUser) // Phòng
        {
          department.DepartmentTitle = department.ID + ";#" + department.Title;
          console.log("Phòng nè", JSON.stringify(department))

          return department.GroupManager + (department.IsThucHien ? "&&1&&0&&0&&" : "&&0&&0&&1&&") + hanXuLy + "&&" + department.DepartmentTitle + "&&" + department.Comment;
        } else // Người
        {
          console.log("Người nè", JSON.stringify(department))

          return department.AccountID + ";#" + department.Title + (department.IsThucHien ? "&&1&&0&&0&&" : "&&0&&0&&1&&") + hanXuLy + "&&" + department.DepartmentTitle + "&&" + department.Comment;
        }
      }).join("&&@@");
    }

    if (removeDepartment != undefined && removeDepartment.length > 0) {
      if (__DEV__)
        console.log("removeDepartment nè", JSON.stringify(removeDepartment))
      // @ts-ignore
      beanVanBanDen.ListIDDelete = removeDepartment.map((item: any) => {
        return item.ID //+ ";#" + item.DepartmentId + ";#" + item.DepartmentName + ";#" + item.DepartmentUrl
      }).join("|");
      if (__DEV__)
        console.log("Chuỗi ID xóa nè", beanVanBanDen.ListIDDelete)
    }
    else {
      if (__DEV__)
        console.log("removeDepartment nul gòi nè")
    }

    if (isNullOrEmpty(beanVanBanDen.ListAssignmentUsers) && isNullOrEmpty(beanVanBanDen.ListIDDelete)) {
      showAlert("Vui lòng chọn phòng ban để phân công hoặc điều chỉnh tổ chức phân công thực hiện");
    }
    else {
      sendActionVanBanDen(btnAction, beanVanBanDen).then(value => {
        if (value) {
          dispatch(endLoading());
          navigation.goBack();
          navigation.goBack();
        }
        else {
          showAlert("Thao tác không thực hiện được");
        }
      });
    }
  }

  const onChooseDepartment = () => {
    let cutter = strings.SplitSignal
    // @ts-ignore
    navigation.navigate("AssignTreeView",
      {
        // @ts-ignore
        dataSelected: dataPhanCong != undefined ? new Set(dataPhanCong.map(item => {
          var text = [item.ID,
          item.Title,
          item.IsThucHien ?? "false",
          item.IsPhoiHop ?? "false",
          item.IsUser ?? "false",
          item.DepartmentTitle,
          item.GroupManager,
          item.HanXuLy
          ].join(cutter);

          if (__DEV__)
            console.log("Chọn nè: ", text)
          return text;
        })) : new Set(),
        data: dataTreeView,
        onSubmit: (departments: any) => {
          if (__DEV__)
            console.log("Item nè: ", JSON.stringify(departments))

          setDataPhanCong(departments.map((item: string) => (
            {
              // ID: item.split(';@')[0],
              // Title: item.split(';@')[1],
              // IsThucHien: JSON.parse(item.split(';@')[2]),
              // IsPhoiHop: JSON.parse(item.split(';@')[3]),
              // IsUser: JSON.parse(item.split(';@')[4]),
              // DepartmentTitle: item.split(';@')[5],
              // GroupManager: item.split(';@')[6],

              ID: item.split(cutter)[0],
              Title: item.split(cutter)[1],
              IsThucHien: item.split(cutter)[2] === 'true',
              IsPhoiHop: item.split(cutter)[3] === 'true', //JSON.parse(item.split(cuuter)[3]),
              IsUser: item.split(cutter)[4] === 'true', //JSON.parse(item.split(cuuter)[4]),
              DepartmentTitle: item.split(cutter)[5],
              GroupManager: item.split(cutter)[6],

              HanXuLy: "",
              Comment: ""
            }))
          );
        }
      });
  };

  // @ts-ignore
  const renderItemPhongBan = ({ item, index }) => <AssignItem
    item={item}
    index={index}
    onDelete={() => {
      // @ts-ignore
      setDataPhanCong((prevData) => prevData.filter((_, _index) => _index !== index));
    }}
    onShowCalendar={() => {
      setIndexItemSetDueDate(index);
      setIsVisibleCalendar(true);
    }}
    textLabelBellowTitle={item.IsThucHien ? "Thực hiện" : "Phối hợp"}
  />

  // @ts-ignore
  const onDeleteItem =
    useCallback(
      // @ts-ignore
      (item, index) => {
        console.log("Item Xóa nè", JSON.stringify(item))
        // if (removeDepartment == null || removeDepartment == undefined) {
        //   setRemoveDepartment([]);
        // }

        if (item != undefined) {
          // // @ts-ignore
          // if (!removeDepartment?.some(dept => dept.ID == item.ID)) {
          //   // @ts-ignore
          //   setRemoveDepartment(removeDepartment?.push(item))
          //   // if (__DEV__)
          //   //   console.log("onDeleteItem - Thêm item gòi")
          // }
          // else {
          //   // if (__DEV__)
          //   //   console.log("onDeleteItem - Không tồn tại item gòi")
          // }
          if (removeDepartment == null || removeDepartment == undefined)
            // @ts-ignore
            setRemoveDepartment([item]);
          else
            // @ts-ignore
            setRemoveDepartment([...removeDepartment, item])
        }
        else {
          // if (__DEV__)
          //   console.log("onDeleteItem - item null gòi")
        }
        if (__DEV__)
          console.log("onDeleteItem - danh sách item bị xóa nè removeDepartment: ", JSON.stringify(removeDepartment))

        if (__DEV__)
          console.log("List ban đầu nè", JSON.stringify(lstTCTH))

        setLstTCTHClone(lstTCTHClone.splice(index, 1));
        setlstTCTH(lstTCTHClone)//.pop(item)
      }
      , [lstTCTH, removeDepartment])

  return <Pressable
    onPress={() => {
      Keyboard.dismiss();
    }}
    style={{
      flex: 1
    }}>
    <ModalTopBar
      title={""}
      onPress={() => {
        navigation.goBack();
      }} />
    <ScrollView style={{ backgroundColor: "white" }} onScroll={() => Keyboard.dismiss()} scrollEventThrottle={16}>
      <View style={{ backgroundColor: "white", padding: 10 }}>
        <Text>Ý kiến lãnh đạo</Text>
        <TextEditorWithBorder
          didFinishedEditting={(text: any) => {
            setUserComment(text)
          }} />
        {
          lstYKienLanhDao != undefined && <ListIdea data={lstYKienLanhDao} />
        }
      </View>
      <View style={{ paddingHorizontal: 10 }}>
        {
          lstTCTH != undefined && <ListDepartmentTask
            data={lstTCTH}
            OnPress={(item: any) => {
            }}
            onDelete={(item: any, index: number) => {
              onDeleteItem(item, index)
            }}
            isEdited={true}
          />
        }
      </View>
      <View style={{ paddingHorizontal: 10 }}>
        <AssignmentHeaderView titleHeader={"Các phòng/ban nghiệp vụ Tập đoàn"}
          titleButton={"Phòng/ban"}
          onPress={() => {
            onChooseDepartment();
          }}
          placeHolder={"Vui lòng bấm vào nút để chọn phòng/ban"}
          imageButton={require("../../../assets/images/icon_tick_phong_ban.png")} />

        <View style={{ marginTop: 10 }}>
          {
            // @ts-ignore
            dataPhanCong != undefined &&
            <FlatList
              style={{ marginTop: 10 }}
              data={dataPhanCong}
              renderItem={renderItemPhongBan}
              scrollEnabled={false}
            />
          }
        </View>
      </View>
    </ScrollView>
    <View style={{ justifyContent: "flex-end", flexDirection: "row", padding: 10, backgroundColor: "white" }}>
      <View style={{ flex: 2 }} />
      <Pressable
        onPress={() => {
          navigation.goBack();
        }}
        style={{ padding: 10, flex: 1 }}>
        <Text style={{ color: "#f65a5b" }}>Thoát</Text>
      </Pressable>
      <Pressable
        onPress={() => {
          submitAction();
        }}
        style={{
          padding: 10,
          flex: 1,
          backgroundColor: "#0072C6",
          borderRadius: 2
        }}>
        <Text style={{
          textAlign: "center",
          color: "white"
        }}>Phân công</Text>
      </Pressable>
    </View>
    {isVisibleCalendar &&
      <CustomCalendarView
        onTouchOutSite={() => {
          setIndexItemSetDueDate(-1);
          setIsVisibleCalendar(!isVisibleCalendar);
        }}
        onPressDate={(date: any) => {
          if (dataPhanCong != undefined) { // @ts-ignore
            dataPhanCong[indexItemSetDueDate].HanXuLy = date.dateString;
          }
          setIsVisibleCalendar(false);
        }}
      />}
    {onLoading && <LoadingScreen />}
  </Pressable>;
};

// const styles = StyleSheet.create({
//   container: {
//     flex: 1
//   },
//   tabContainer: {
//     height: 50
//   },
//   tabIndicatorStyle: {
//     backgroundColor: "#0072C6",
//     height: 3,
//     borderRadius: 100,
//     marginHorizontal: 4
//   }
// });