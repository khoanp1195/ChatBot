import { useNavigation, useRoute } from "@react-navigation/native"
import { Keyboard, Pressable, Text } from "react-native"
import strings from "../../../assets/strings";
import { convertStringToMoment, isNullOrEmpty } from "../../../utils/functions";
import { ModalTopBar } from "../../../components/modalTopBar";
import { View } from "react-native";
import { FlatList, TextInput } from "react-native-gesture-handler";
import { Input } from "react-native-elements";
import { useEffect, useState } from "react";
import { EnumVanBanDenAction, TypeSelectUser } from "../../../config/enum";
import { BeanUser } from "../../../services/database/models/bean_user";
import { appMainBlueColor } from "../../../utils/color";
import TextRequire from "../../../components/textRequire";
import { showAlert } from "../../commonAlertView";
import { BeanVanBanDen } from "../../../services/database/models/beanVanBanDen";
import { BeanVBBH } from "../../../services/database/models/beanVBBH";
import { getListShareVBBH, submitShareVBBH } from "../../../services/api/apiDetailVBBH";
import { BeanComment } from "../../../services/database/models/beanComment";
import { getTextSplit } from "../../../utils/textHelper";
import { CustomFastImage } from "../../../components/custom_fast_image";
import { getFullLink } from "../../../config/constants";
import RowSpaceBetween from "../../../components/rowSpaceBetween";
import { getListShareVBDen, sendActionVanBanDen } from "../../../services/api/apiDetailVBDen";

export const ShareScreen = () => {
    const navigation = useNavigation();
    const route = useRoute();
    //@ts-ignore
    const item: BeanVanBanDen | BeanVBBH = route.params['item'];
    //@ts-ignore
    const type: string = route.params['type'];
    const [note, setNote] = useState<string>("");
    const [selectUsers, setSelectUsers] = useState<BeanUser[]>();
    const [userShared, setUserShared] = useState<BeanComment[]>();
    useEffect(() => {
        getListShare();
    }, []);
    const getListShare = () => {
        switch (type) {
            case 'VBBH':
                getListShareVBBH(item as BeanVBBH).then(value => {
                    if (value != null) {
                        setUserShared(value as BeanComment[])
                    }
                });
                break;
            case 'VBDen':
                getListShareVBDen(item as BeanVanBanDen).then(value => {
                    if (value != null) {
                        setUserShared(value as BeanComment[])
                    }
                });
                break;
        }
    }
    const submitAction = () => {
        if (selectUsers == undefined || selectUsers.length == 0) {
            showAlert("Vui lòng chọn người được chia sẻ");
            return;
        }
        switch (type) {
            case 'VBBH':
                submitActionVBBH();
                break;
            case 'VBDen':
                submitActionVBDen();
                break;
        }
        setSelectUsers([]);
    }
    const submitActionVBDen=()=>{
        const itemVBDen = item as BeanVanBanDen;
        itemVBDen.YKien = note;
        itemVBDen.UserCC = selectUsers!.map(r => `${r.AccountID.toString()};#${r.Name}`).join(";#");
        sendActionVanBanDen(EnumVanBanDenAction.Share,itemVBDen).then(result => {
            if (result) {
                getListShare();
            }
            else {
                showAlert("Danh sách user share đã tồn tại. Vui lòng kiểm tra lại")
            }
        });;
    }
    const submitActionVBBH = () => {
        const itemVBBH = item as BeanVBBH;
        itemVBBH.YKien = note;
        itemVBBH.PeopleText = selectUsers!.map(r => `${r.AccountID.toString()};#${r.Name}`).join(";#");
        submitShareVBBH(itemVBBH).then(result => {
            if (result) {
                getListShare();
            }
            else {
                showAlert("Danh sách user share đã tồn tại. Vui lòng kiểm tra lại")
            }
        });

    };


    const RenderItemShared = ({ item }: { item: BeanComment }) => (
        <View style={{ padding: 10, flexDirection: 'row' }}>
            <CustomFastImage
                defaultImage={require("../../../assets/images/avatar80.jpg")}
                urlOnline={getFullLink() + item.ImagePath}
                styleImg={{
                    height: 50,
                    width: 50,
                    borderRadius: 100
                }}
            />
            <View style={{ marginLeft: 10, flex: 1 }}>
                <Text style={{ fontSize: 15, color: 'black' }}>{item.Title}</Text>
                <Text style={{ fontSize: 12 }}>{getTextSplit(item.Position, ";#", 1)}</Text>
                <Text style={{ fontSize: 15 }}>{item.Value}</Text>
            </View>
            <Text >{convertStringToMoment(item.Created!).format("DD/MM/yyyy HH:mm")}</Text>
        </View>
    );

    return <View style={{ flex: 1 }}>
        <ModalTopBar title={"Chia sẽ"} onPress={() => {
            navigation.goBack();
        }} />
        <View style={{ flex: 1, backgroundColor: 'white', padding: 10 }}>
            <View style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                    <Text style={{ color: '#5e5e5e' }}>
                        Chọn người hoặc nhóm người để chia sẻ
                    </Text>
                    <TextRequire />
                </View>
                <Pressable onPress={() => {
                    //@ts-ignore
                    navigation.navigate("SelectUserScreen",
                        {
                            typeSelect: TypeSelectUser.Multiple,
                            usersSelected: selectUsers,
                            onSelectApply: (users: any) => {
                                setSelectUsers(users);
                            },
                            beanTask: null,
                            result: null
                        });
                }}>
                    <Text style={{ borderRadius: 10, borderColor: '#E5E5E5', borderWidth: 1, padding: 10 }}>
                        {
                            selectUsers != undefined && selectUsers.map((item: BeanUser) => item.Title).join(';')
                        }
                    </Text>
                </Pressable>
            </View>
            <View>
                <Text style={{ color: '#5e5e5e', marginBottom: 10 }}>
                    Ý kiến
                </Text>
                <TextInput
                    multiline={true}
                    numberOfLines={3}
                    scrollEnabled
                    onChangeText={setNote}
                    style={{
                        textAlignVertical: 'top',
                        borderRadius: 10,
                        borderColor: '#E5E5E5',
                        borderWidth: 1,
                        padding: 10,
                        height: 100,
                    }}
                />
            </View>
            <View style={{ flexDirection: 'row-reverse' }}>
                <Pressable
                    onPress={submitAction}
                    style={{ padding: 10, backgroundColor: appMainBlueColor, borderRadius: 10, marginTop: 10 }}>
                    <Text style={{ color: 'white', paddingLeft: 20, paddingRight: 20 }}>Chia sẻ</Text>
                </Pressable>
            </View>
            {
                (userShared != undefined && userShared!.length > 0) &&
                <View>
                    <Text style={{ color: appMainBlueColor }}> Danh sách đã chia sẻ</Text>
                    <FlatList
                        data={userShared}
                        renderItem={RenderItemShared}
                    />
                </View>
            }

        </View>
    </View>
}