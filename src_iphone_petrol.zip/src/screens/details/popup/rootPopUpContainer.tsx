import { Image, Pressable, Text, TextInput, View } from "react-native";
import { getRequireImageAction, isNullOrEmpty } from "../../../utils/functions.ts";
import { EnumVanBanDenAction, TypeSelectUser } from "../../../config/enum.ts";
import { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { DbServices } from "../../../services/database/db_service.ts";
import { subsiteStore } from "../../../config/constants.ts";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { useDispatch, useSelector } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { redirectScreen } from "../../../stores/base_screen/actions.ts";

// @ts-ignore
export const FormOnlyComment = ({ onChangeText, isForce = false }) => {
  return <View style={{ maxHeight: ' 80%' }}>
    <Text style={{ marginBottom: 10 }}>Ý kiến</Text>

    <TextInput
      onChangeText={text => onChangeText(text)}
      multiline
      style={{ borderRadius: 10, borderWidth: 1, borderColor: "#E5E5E5", paddingVertical: 10 }}
      placeholder={"Vui lòng nhập ý kiến …"} />

    {
      isForce && <Text style={{ marginBottom: 10, color: 'red' }}>Anh/Chị xác nhận kết thúc luồng xử lý của văn bản này?</Text>
    }
  </View>;
};

// @ts-ignore
export const RootPopUpContainer = ({ action, cancelPress, itemVB, type }) => {
  // const screen = useSelector((state: any) => state.baseScreen.screen.toString());

  const dispatch = useDispatch();
  const navigation = useNavigation();
  let yKien = "";

  const [isCheckBOD, setIsCheckBOD] = useState(false);
  const [isUuTienCheckBOD, setIsUuTienCheckBOD] = useState(false);
  const [bodSelectTed, setBODSelected] = useState();
  const [bodCCSelectTed, setBODCCSelected] = useState();

  const [isCheckCVPTPTH, setIsCheckCVPTPTH] = useState(false);
  const [isUuTienCheckCVPTPTH, setIsUuTienCheckCVPTPTH] = useState(false);
  const [CVPTPTHSelectTed, setCVPTPTHSelected] = useState();
  const [CVPTPTHCCSelectTed, setCVPTPTHCCSelectTed] = useState();

  const ContentOnlyEditText = () => {
    switch (action.ID) {
      case EnumVanBanDenAction.RecallBOD:
      case EnumVanBanDenAction.Recall:
      case EnumVanBanDenAction.Priority:
        return <View />;
      case EnumVanBanDenAction.Comment:
      case EnumVanBanDenAction.CommentBOD:
      case EnumVanBanDenAction.Forward:
      case EnumVanBanDenAction.FowardArchives:
      case EnumVanBanDenAction.Completed:
        return <FormOnlyComment onChangeText={(text: string) => {
          yKien = text;
        }} />;
      case EnumVanBanDenAction.SubmitBOD:
        return <FormSubmitBOD />;
      default:
        return <View />;
    }
  };

  const FormSubmitBOD = () => {
    // @ts-ignore
    const SelectForm = ({ isUuTien, onPressUutien, onBODPress, lanhDaoSelected, onSelectUserCC, userCC }) => {
      return <View style={{ marginLeft: 20, marginTop: 10 }}>
        <Text>Lãnh đạo Công ty</Text>
        <Pressable onPress={() => {
          onBODPress();
        }} style={{
          borderWidth: 1,
          padding: 5,
          marginTop: 10,
          flexDirection: "row",
          borderColor: "#E5E5E5",
          borderRadius: 5
        }}>
          <Text style={{ flex: 1 }}>{lanhDaoSelected}</Text>
          <Image style={{ height: 20, width: 20 }} resizeMode={"contain"}
            source={require("../../../assets/images/icon_user_dropdown.png")} />
        </Pressable>
        <Text style={{ marginTop: 10 }}>CC</Text>
        <Pressable onPress={() => {
          onSelectUserCC();
        }} style={{
          borderWidth: 1,
          padding: 5,
          marginTop: 10,
          flexDirection: "row",
          borderColor: "#E5E5E5",
          borderRadius: 5
        }}>
          <Text style={{ flex: 1 }}>{userCC}</Text>
        </Pressable>
        <Pressable onPress={() => {
          onPressUutien();
        }} style={{ flexDirection: "row", marginTop: 10 }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }}
            source={!isUuTien ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
          <Text>Ưu tiên</Text>
        </Pressable>
      </View>;
    };
    const handlePressCPVSelect = async () => {

      let type = "'" + "Chánh văn phòng" + "'" + "," + "'" + "Trưởng phòng Tổng hợp - HĐQT" + "'";
      // get data by type
      let banLanhDaos = [];
      if (!isNullOrEmpty(subsiteStore.getSubsite())) {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllDifLanhDao(type);
      } else {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllLanhDao(type);
      }
      console.log("type", banLanhDaos);


      // @ts-ignore
      navigation.navigate("TypeSelectScreen",
        {
          title: "Lãnh đạo Công ty",
          data: banLanhDaos,
          enableAvatar: true,
          selectedTitle: CVPTPTHSelectTed != undefined ? CVPTPTHSelectTed["Title"] : "",
          onSelected: (item: any) => {
            setCVPTPTHSelected(item);
          }
        });
    };
    const handlePressBODSelect = async () => {
      let _banLanhDao = itemVB.BanLanhDao;
      let type = "";
      if (_banLanhDao.includes(";#")) {
        _banLanhDao = _banLanhDao.split(";#")[0];
      }
      const data = await DbServices.getInstance().getBanLanhDaoRepository().findByLanhDaoID(_banLanhDao);

      if (data != null) {
        // @ts-ignore
        if (data[0].LanhDao == "Chánh văn phòng" || data[0].LanhDao == "Ban TGĐ") {
          type = "'" + "Ban TGĐ" + "'";
        } else
          type = "'" + "HĐQT" + "'";
      }

      // get data by type
      let banLanhDaos = [];
      if (!isNullOrEmpty(subsiteStore.getSubsite())) {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllDifLanhDao(type);
      } else {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllLanhDao(type);
      }
      console.log("type", banLanhDaos);


      // @ts-ignore
      navigation.navigate("TypeSelectScreen",
        {
          title: "Lãnh đạo Công ty",
          data: banLanhDaos,
          enableAvatar: true,
          selectedTitle: bodSelectTed != undefined ? bodSelectTed["Title"] : "",
          onSelected: (item: any) => {
            setBODSelected(item);
          }
        });
    };

    return <View>
      <FormOnlyComment onChangeText={(text: string) => {
        yKien = text;
      }} />
      <Pressable
        onPress={() => {
          setIsCheckBOD(!isCheckBOD);
          setIsCheckCVPTPTH(false);
          setIsUuTienCheckCVPTPTH(false);
          setCVPTPTHSelected(undefined);
          setCVPTPTHCCSelectTed(undefined);
        }}
        style={{ flexDirection: "row", marginTop: 10 }}
      >
        <Image style={{ height: 20, width: 20, marginRight: 10 }}
          source={!isCheckBOD ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
        <Text>Chuyển đến lãnh đạo Tập đoàn</Text>
      </Pressable>
      {
        isCheckBOD && <SelectForm
          // @ts-ignore
          userCC={bodCCSelectTed == undefined ? "" : bodCCSelectTed.map(item => item.Title).join(";")}
          onSelectUserCC={() => {
            // @ts-ignore
            navigation.navigate("SelectUserScreen",
              {
                typeSelect: TypeSelectUser.Multiple,
                usersSelected: bodCCSelectTed,
                onSelectApply: (users: any) => {
                  setBODCCSelected(users);
                },
                beanTask: null,
                result: null
              });
          }}
          lanhDaoSelected={bodSelectTed != undefined ? bodSelectTed["Title"] : ""}
          isUuTien={isUuTienCheckBOD}
          onBODPress={handlePressBODSelect}
          onPressUutien={() => {
            setIsUuTienCheckBOD(!isUuTienCheckBOD);
          }} />
      }
      <Pressable onPress={() => {
        setIsCheckCVPTPTH(!isCheckCVPTPTH);
        setIsCheckBOD(false);
        setIsUuTienCheckBOD(false);
        setBODSelected(undefined);
        setBODCCSelected(undefined);

      }} style={{ flexDirection: "row", marginTop: 10 }}>
        <Image style={{ height: 20, width: 20, marginRight: 10 }}
          source={!isCheckCVPTPTH ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
        <Text>Chuyển đến CVP/TPTH</Text>
      </Pressable>
      {
        isCheckCVPTPTH && <SelectForm
          // @ts-ignore
          userCC={CVPTPTHCCSelectTed == undefined ? "" : CVPTPTHCCSelectTed.map(item => item.Title).join(";")}
          onSelectUserCC={() => {
            // @ts-ignore
            navigation.navigate("SelectUserScreen",
              {
                typeSelect: TypeSelectUser.Multiple,
                usersSelected: CVPTPTHCCSelectTed,
                onSelectApply: (users: any) => {
                  setCVPTPTHCCSelectTed(users);
                },
                beanTask: null,
                result: null
              });
          }}
          lanhDaoSelected={CVPTPTHSelectTed != undefined ? CVPTPTHSelectTed["Title"] : ""}
          onBODPress={handlePressCPVSelect}
          isUuTien={isUuTienCheckCVPTPTH}
          onPressUutien={() => {
            setIsUuTienCheckCVPTPTH(!isUuTienCheckCVPTPTH);
          }} />
      }
    </View>;
  };

  const submitAction = () => {
    if (type == "VBDen") {
      itemVB.YKien = yKien;
      if (action.ID == EnumVanBanDenAction.SubmitBOD) {
        if (isCheckBOD) {
          itemVB.chkLanhDao = "true";
          itemVB.chkCVP_TPTH = "false";
          itemVB.chkPhanCong = "false";
          // @ts-ignore
          itemVB.chkLanhDaoValue = bodSelectTed.ID + ";#" + bodSelectTed.Title;
        } else if (isCheckCVPTPTH) {
          itemVB.chkCVP_TPTH = "true";
          itemVB.chkLanhDao = "false";
          itemVB.chkPhanCong = "false";
          // @ts-ignore
          itemVB.chkCVP_TPTHValue = bodSelectTed.ID + ";#" + bodSelectTed.Title;
        } else {
          showAlert("Vui lòng chọn user");
          return;
        }
        itemVB.UuTien = isUuTienCheckBOD || isUuTienCheckCVPTPTH;
      }
      dispatch(startLoading());
      cancelPress();
      sendActionVanBanDen(action.ID, itemVB).then(
        value => {
          dispatch(endLoading());
          if (value) {
            //ToDO reload list
            navigation.goBack();
          } else {
            showAlert("Thao tác không thực hiện được!");
          }
        }
      );

    }
  };

  return <Pressable
    onPress={() => {
      cancelPress();
    }}
    style={{
      position: "absolute",
      height: "100%",
      width: "100%",
      backgroundColor: "#19191EB2",
      alignItems: "center",
      justifyContent: "center"
    }}>
    <Pressable style={{ backgroundColor: "white", width: "90%", borderRadius: 10 }}>
      <View style={{ flexDirection: "row", borderBottomWidth: 0.7, borderBottomColor: "#f4f4f4", padding: 10 }}>
        <Image
          style={{ height: 25, width: 25, marginRight: 10 }}
          resizeMode={"contain"}
          source={getRequireImageAction(action.ID, action.Class)}
        />
        <Text style={{ color: "#0072c6", fontSize: 15 }}>{action.Title}</Text>
      </View>
      <View style={{ padding: 10 }}>
        <ContentOnlyEditText />
      </View>
      <View style={{ flexDirection: "row", padding: 10 }}>
        <View style={{ flex: 1 }} />
        <View style={{ flex: 1, flexDirection: "row" }}>
          <Pressable onPress={() => {
            cancelPress();
          }} style={{ flex: 1 }}><Text
            style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
          <Pressable
            onPress={() => {
              submitAction();
            }}
            style={{
              flex: 1,
              backgroundColor: "#0072C6",
              padding: 10,
              borderRadius: 6
            }}>
            <Text style={{
              textAlign: "center",
              backgroundColor: "#0072C6",
              color: "white",
              borderRadius: 6
            }}>Đồng ý</Text>
          </Pressable>
        </View>
      </View>
    </Pressable>
  </Pressable>;
};
