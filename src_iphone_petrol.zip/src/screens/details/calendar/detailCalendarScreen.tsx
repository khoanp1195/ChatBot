import { Text, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import WebView from "react-native-webview";
import { BASE_URL, subsiteStore } from "../../../config/constants.ts";
import { useEffect, useState } from "react";
import { isNullOrEmpty } from "../../../utils/functions.ts";

export const DetailCalendarScreen=()=>{
  const navigation=useNavigation();
  const route = useRoute();
  // @ts-ignore
  const item = route.params['item'];
  // @ts-ignore
  const siteConnect = route.params['siteConnect']??"";
  // @ts-ignore
  const enableIsView = route.params['enableIsView']??false;
  const [url,setUrl]=useState("");
  useEffect(() => {
    if (item.ID == -2)
    {
      setUrl(getSite() + "/calendar/SitePages/MeetingRoomStatus.aspx");
    }
    else if (item.ID  == -1)
    {
      setUrl(getSite() + "/calendar/SitePages/meetingbooking_form.aspx?");
    }
    else
    {
      setUrl(getSite() + "/calendar/SitePages/meetingbooking_form.aspx?IID=" +item.ID + (enableIsView ? "&IsView=1" : ""));
    }
  }, []);
  console.log(url);
  const getSite=()=>{
    if(!isNullOrEmpty(siteConnect))
    {
      if(siteConnect.toLowerCase()==="portal")
      {
        return BASE_URL;
      }
      return BASE_URL + "/" + siteConnect;
    }
    else
    {
      return BASE_URL + "/" + subsiteStore.getSubsite();
    }
  }
  return <View style={{flex:1}}>
    <ModalTopBar onPress={()=>{
      if (navigation.canGoBack())
        navigation.goBack();
    }} title={""} />
    {
      !isNullOrEmpty(url)&&<WebView
        setUseWideViewPort={true}
        javaScriptEnabled={true}
        allowFileAccess={true}
        originWhitelist={['*']}
        style={{ width: '100%', height: '100%',backgroundColor:'black' }}
        source={{uri:url}}
        setSupportMultipleWindows={false}
      />
    }
  </View>
}
