import { FlatList, Image, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { getAttFileVBDi, getDetailVBDi, getIdeaOfBODv2 } from "../../../../services/api/apiDetailVBDi.ts";
import EmptyView from "../../../../components/empty_view.tsx";
import { DetailVBDI } from "../../docDetail/detailVBDI.jsx";
import { useSelector } from "react-redux";
import { ListAttachment } from "../../docDetail/listAttachment.jsx";


// @ts-ignore
export const VBDiDetailScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const [detailVBDI, setDetailVBDI] = useState();
  const [attFile, setAttFile] = useState();
  const [iDeaOfBOD, setIDeaOfBOD] = useState();
  const [isLoading, setLoading] = useState(true);
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  // @ts-ignore
  const item = route.params["item"];
  useEffect(() => {
    // @ts-ignore
    getDetailVBDi(item.DocumentID ?? item.ID).then(value => {
      setLoading(value == null)
      if (value != null) {
        setDetailVBDI(value);
        getIdeaOfBODv2(value.ID, value.SPItemId, value.SPListId).then(value => setIDeaOfBOD(value));
      }
    });
    getAttFileVBDi(item.DocumentID ?? item.ID).then(value => setAttFile(value));
  }, [onLoading]);

  return <View style={{ flex: 1 }}>
    <ModalTopBar
      title={""}
      rightAction={<TouchableOpacity onPress={() => {
        // @ts-ignore
        navigation.navigate("WorkflowHistoryVBDi", {
          itemVB: detailVBDI
        });
      }}>
        <Image style={{ height: 25, width: 25 }} resizeMode={"stretch"}
          source={require("../../../../assets/images/icon_proce.png")} />
      </TouchableOpacity>}
      onPress={() => {
        navigation.goBack();
      }} />
    <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row" }}>
      <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>
        {
          // @ts-ignore
          detailVBDI?.DocumentName
        }
      </Text>
    </View>
    <ScrollView style={{ flex: 1, backgroundColor: 'white' }}>
      <DetailVBDI
        // @ts-ignore
        vBDi={detailVBDI} />
      {attFile != undefined ? (
        <ListAttachment data={attFile} onClick={undefined} />

      ) : null}
    </ScrollView>
  </View>
}
const styles = StyleSheet.create({
  flatList: {
    backgroundColor: 'white', // Example background color
    paddingHorizontal: 20, // Example padding horizontal
    paddingVertical: 10, // Example padding vertical

  },
})