import { Button, Image, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { useEffect, useState } from "react";
import EmptyView from "../../../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { ListIdea } from "../../docDetail/listIdea.jsx";
import { getDisplayTxtFromDateString, isNullOrEmpty, mapActionVBDen, sortTask, getTextFromFormatText } from "../../../../utils/functions.ts";
import { useSelector } from "react-redux";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { currentUserStore } from "../../../../config/constants.ts";
import { BtnDocType } from "../../../../components/customSearchViewDocTypeBtn.tsx";
import { CustomCalendarView } from "../../../../components/customCalendarView.tsx";
import { compareDateFromTxt } from "../../../../utils/functions.ts";
import { showAlert } from "../../../commonAlertView.jsx";
import { TaskPopUpContainer } from "../../popup/taskPopUpContainer.tsx";
import { TypeSelectUser, EnumTaskAction } from "../../../../config/enum.ts";
import { sendActionTaskVBDen } from "../../../../services/api/apiTaskVB.ts";
import { BeanUser } from "../../../../services/database/models/bean_user.ts";

interface Props{
    item:any;
    itemVB:any;
    isVBDen:boolean;
    lstBODIdea:any;
}
// @ts-ignore
export const NhiemVuDaPhanCongView:FC<Props> = ({item,itemVB,isVBDen,lstBODIdea}) => {
    const navigation = useNavigation();
    const onLoading = useSelector((state:any) => state.loading.onLoading);
    const [isShowPopup, setShowPopup] = useState(false);
    // const [isPhoiHopChiXem, setIsPhoiHopChiXem] = useState(false);
    const [isVisibleCalendar, setIsVisibleCalendar] = useState<boolean>();
    const [selectedUser, setSelectedUser] = useState<BeanUser>();
    const [nguoiNhanTitle, setNguoiNhanTitle] = useState(item.AssignedToText != undefined ? item.AssignedToText : item.DepartmentTitle != undefined ? item.DepartmentTitle : "");
    const [dueDate, setDueDate] = useState(item.DueDate);

    if (__DEV__)
        console.log("Task nè " + JSON.stringify(item), "item nè:", JSON.stringify(itemVB), "User nè: ", JSON.stringify(selectedUser), "nguoiNhanTitle nè:", nguoiNhanTitle, "Hạn XL nè", dueDate);

    useEffect(() => {
        const name = item.AssignedToTextJson;
        if (name != undefined && String(name).includes(";#")) {
            const txt = String(name).split(";#");
            //@ts-ignore
            setSelectedUser({
                AccountID: parseInt(txt[0]),
                Name: txt[0],
            });
        }
    }, []);

    const onClickDueDateEditting = () => {
        setIsVisibleCalendar(true);
    }

    const onChooseDate = (date:any) => {
        const value = compareDateFromTxt(date, new Date().toDateString())
        if (__DEV__) console.log("dueDate nè ", value)
        if (value >= 0) {
            setDueDate(date)
            if (__DEV__) console.log("dueDate gán nè ", dueDate)
            setIsVisibleCalendar(false);
        }
        else {
            showAlert("Ngày được chọn không được nhỏ hơn ngày hôm nay!")
        }
    }

    const onChooseUser = () => {
        // @ts-ignore
        navigation.navigate("SelectUserScreen",
            {
                typeSelect: TypeSelectUser.Single,
                usersSelected: selectedUser,
                // @ts-ignore
                onSelectApply: (user) => {
                    setSelectedUser(user);
                },
                beanTask: null,
                result: null
            });

    }

    const onDeleteUser = () => {
        setSelectedUser(undefined)
        setNguoiNhanTitle(undefined)
    }

    // const onSubmitAction = () => {
    //     dispatch(startLoading());
    //     taskVB.Percent = percentage;
    //     taskVB.TrangThai = taskState;
    //     if (__DEV__) console.log("item gửi nè:", JSON.stringify(taskVB))

    //     const res = sendActionTaskVBDen(
    //         EnumTaskAction.Assignment
    //         , taskVB).then(value => {
    //             dispatch(endLoading());
    //             if (value) {
    //                 //ToDO reload list
    //                 navigation.goBack();
    //             } else {
    //                 showAlert("Thao tác không thực hiện được!");
    //             }
    //         }
    //         );
    //     return;
    // }

    return <View style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>

            <ModalTopBar
                title={"Nhiệm vụ đã phân công"}
                onPress={() => {
                    navigation.goBack();
                }} />

            {
                item != null
                    ? <View style={{
                        flex: 1,
                        backgroundColor: 'white',
                    }}>

                        <View style={{
                            flex: 1,
                            backgroundColor: "white"
                        }}>
                            <ScrollView style={{ flex: 1, backgroundColor: "white" }}>
                                <View style={{ flex: 1, backgroundColor: "white", marginHorizontal: 10 }}>
                                    <View style={[styles.basicStyle]} >
                                        <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người chuyển</Text>
                                        <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                                            {
                                                //@ts-ignore
                                                !isNullOrEmpty(item.AssignorText)
                                                    //@ts-ignore
                                                    ? item.AssignorText
                                                    : currentUserStore.currentUser.Title
                                            }
                                        </Text>
                                    </View>

                                    <View>
                                        <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người nhận</Text>
                                        <View style={[styles.customBorderStyle, { flex: 1, flexDirection: 'row', height: 40, alignItems: 'center' }]}>
                                            <View style={[{ flexWrap: 'wrap', maxWidth: '950%', alignItems: 'center', flex: 1, }]}>
                                                {
                                                    selectedUser != undefined || nguoiNhanTitle != undefined ?
                                                        <View style={[{ backgroundColor: '#f5f5f5', flexWrap: 'wrap', paddingHorizontal: 5, borderRadius: 99, justifyContent: 'center' }]} >
                                                            <Text
                                                                style={[{ fontSize: 15, color: 'black', paddingHorizontal: 5 }, { maxWidth: "90%", }]}
                                                                numberOfLines={1}
                                                                ellipsizeMode='tail'
                                                            >
                                                                {selectedUser != undefined ?
                                                                    selectedUser.Title != undefined ?
                                                                        selectedUser.Title :
                                                                        selectedUser.Name
                                                                    : nguoiNhanTitle}
                                                            </Text>
                                                            <TouchableOpacity
                                                                onPress={() => { onDeleteUser() }}>
                                                                <Image
                                                                    source={require("../../../../assets/images/icon_Btn_action_16.png")}
                                                                    style={[styles.customIconInBoxStyle]}
                                                                    resizeMode='contain'
                                                                />
                                                            </TouchableOpacity>
                                                        </View>
                                                        : null
                                                }
                                            </View>


                                            <TouchableOpacity onPress={() => { onChooseUser() }} >
                                                <Image
                                                    source={require("../../../../assets/images/icon_user_dropdown.png")}
                                                    style={[styles.customIconInBoxStyle]}
                                                    resizeMode='contain'
                                                />
                                            </TouchableOpacity>
                                        </View>
                                    </View>

                                    <View style={styles.basicStyle}>
                                        <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                                            <Text style={styles.titleTextStyle}>Ngày bắt đầu</Text>
                                            <Text style={styles.titleTextStyle}>Hạn hoàn tất</Text>
                                        </View>
                                        <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                                            <View style={[styles.basicStyle, { flexDirection: 'row', alignItems: 'center' }]}>
                                                <Text style={[styles.customValueTextStyle, { flex: 1 }]}
                                                //@ts-ignore
                                                > {getDisplayTxtFromDateString(item.StartDate)} </Text>
                                            </View>
                                            <TouchableOpacity style={[styles.basicStyle, styles.customBorderStyle, { flexDirection: 'row', alignItems: 'center' }]}
                                                onPress={() => { onClickDueDateEditting() }}
                                            >
                                                <Text style={[styles.valueTextStyle, { flex: 1 }]}
                                                //@ts-ignore
                                                >{getDisplayTxtFromDateString(dueDate)}
                                                </Text>
                                                <Image
                                                    source={require("../../../../assets/images/icon_calendar.png")}
                                                    style={[styles.customIconInBoxStyle]}
                                                    resizeMode='contain'
                                                    tintColor='gray'
                                                />
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                    {
                                        //@ts-ignore
                                        lstBODIdea != null && lstBODIdea.length > 0 ? <ListIdea data={lstBODIdea} isBODIdea={true} />
                                            : null
                                    }
                                    <View style={[styles.basicStyle]}>
                                        <Text style={[styles.titleTextStyle, styles.basicStyle]}>Ý kiến người chuyển</Text>
                                        <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(item.YKienChiDao)}</Text>

                                        <Text style={[styles.titleTextStyle, styles.basicStyle]}>Ý kiến của người nhận</Text>
                                        <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(item.YKienCuaNguoiGiaiQuyet)}</Text>
                                        <View style={styles.basicStyle}>
                                            <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                                                <Text style={styles.titleTextStyle}>Tình trạng</Text>
                                                <Text style={styles.titleTextStyle}>Tiến độ</Text>
                                            </View>
                                            <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                                                <Text style={[styles.valueTextStyle, { flex: 1 }]}>{item.TrangThai}</Text>
                                                <Text style={[styles.valueTextStyle]}>{item.Percent + "\t%"}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            </ScrollView>
                        </View>

                        <View style={{
                            height: 50,
                            width: 240,
                            alignSelf: "flex-end",
                            paddingRight: 5,
                            flexDirection: "row",
                            justifyContent: 'center',
                        }}>
                            <BtnDocType
                                title={"Thoát"}
                                onClickHandle={() => {
                                    navigation.goBack();
                                }}
                                buttonStyle={[styles.normalButton]}
                                textStyle={[styles.normalButtonText]}
                            />
                            <BtnDocType
                                title={"Phân công"}
                                onClickHandle={() => {
                                    setShowPopup(true);
                                }}
                                buttonStyle={[styles.activeButton]}
                                textStyle={[styles.activeButtonText]}
                            />
                        </View>

                    </View >
                    :
                    <EmptyView />
            }
        </View >

        {
            isVisibleCalendar &&
            <CustomCalendarView
                onTouchOutSite={() => {
                    // setIndexItem(-1);
                    setIsVisibleCalendar(!isVisibleCalendar);
                }}
                onPressDate={(date:any) => {
                    onChooseDate(date.dateString);
                }}
            />
        }

        {
            isShowPopup && <TaskPopUpContainer
                //@ts-ignore
                action={{
                    ID: EnumTaskAction.Assignment,
                    Title: "Phân công",
                    Class: "TaskVBDen"
                }}
                cancelPress={() => {//isReload
                    // if (isReload)
                    //     reloadContent()
                    setShowPopup(false)
                }}
                itemVB={item}
                dueDate={dueDate}
                //@ts-ignore
                selectedUser={selectedUser}
            />
        }
        {onLoading && <LoadingScreen />}
    </View >;
};

const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
    customBorderStyle: {
        borderWidth: 1,
        borderColor: 'lightgray',
        borderRadius: 5,
        padding: 5,
    },
    customValueTextStyle: {
        fontSize: 14,
        color: 'black',
    },
    customIconInBoxStyle: {
        height: "100%",
        width: 15,
    },
    normalButton: {
        backgroundColor: "white"//"#f5f5f5"
    },
    activeButton: {
        backgroundColor: "#0072C6"
    },
    normalButtonText: {
        color: "red"//"black"
    },
    activeButtonText: {
        color: "white"
    },
})