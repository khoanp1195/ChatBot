import React from "react";
import {
  FlatList, StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import {
  convertStringToMoment,
  getListItemBackground,
  isNullOrEmpty,
} from "../../../../utils/functions.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import { BASE_URL, subsiteStore } from "../../../../config/constants.ts";
import { useNavigation } from "@react-navigation/native";

// @ts-ignore
export const OtherDepartmentScreen = ({ data, isVBDen, itemVB }) => {
  const navigation = useNavigation();
  // @ts-ignore
  const renderItem = ({ item, index }) => (
    <TouchableOpacity
      onPress={() => {
        // @ts-ignore
        navigation.navigate("WorkflowOtherDepartment", {
          isVBDen: isVBDen,
          itemVB: itemVB,
          itemDepartment: item,
        });
      }}
    >
      <View
        style={[
          styles.itemContainer,
          { backgroundColor: getListItemBackground(index % 2 !== 0) },
        ]}
      >
        <View style={{ justifyContent: "center", flex: 1 }}>
          <Text style={styles.departmentName}>{item.DepartmentName}</Text>
          <View style={styles.siteAndCreatedContainer}>
            <Text style={styles.siteName}>{item.SiteName}</Text>
            <Text style={styles.createdDate}>
              {convertStringToMoment(item.Created).format("DD/MM/YY HH:mm")}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={{ backgroundColor: "white", flex: 1 }}>
      <FlatList data={data} renderItem={renderItem} />
    </View>
  );
};
const styles = StyleSheet.create({
  itemContainer: {
    padding: 10,
    flexDirection: "row",
  },
  departmentName: {
    flex: 1,
    color: "black",
    fontSize: 15,
  },
  siteAndCreatedContainer: {
    flexDirection: "row",
  },
  siteName: {
    flex: 1,
    color: "black",
    fontSize: 12,
  },
  createdDate: {
    flex: 1,
    textAlign: "right",
    fontSize: 12,
    color: "#5e5e5e",
  },
});

