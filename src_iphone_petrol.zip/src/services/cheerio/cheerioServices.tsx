import Cheerio from "cheerio";

export const getImagePathTagImageCheerio = (value: string) => {
    const $ = Cheerio.load(value);
    return $('img').attr('src');
}