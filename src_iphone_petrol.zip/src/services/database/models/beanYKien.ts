export class BeanYKien {
    public Title: string;
    public Value: string;
    public Created: string | null;

    constructor() {
        this.Title = '';
        this.Value = '';
        this.Created = null;
    }
}
