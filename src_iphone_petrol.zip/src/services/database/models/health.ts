class Health {
    ID: number;
    Height: number;
    Weight: number;
    BMI: number;
    HeartRate: string;
    BloodPressure: string;
    Classification: string;

    constructor(ID:number,Height: number, Weight: number, BMI: number, HeartRate: string, BloodPressure: string, Classification: string) {
        this.ID=ID;
        this.Height = Height;
        this.Weight = Weight;
        this.BMI = BMI;
        this.HeartRate = HeartRate;
        this.BloodPressure = BloodPressure;
        this.Classification = Classification;
    }
}