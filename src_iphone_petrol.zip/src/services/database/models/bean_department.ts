import { Entity } from "typeorm";
import { Column, PrimaryColumn } from "typeorm/browser";

// @ts-ignore
@Entity({ name: "BeanDepartment" })
export class BeanDepartment {
  // @ts-ignore
  @PrimaryColumn({ type: "int" })
  public ID: number = 0;
  // @ts-ignore
  @Column({ type: "text" })
  public SiteName: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public Title: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public TenToChucVN: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public Code: string = "";
  // @ts-ignore
  @Column({ type: "int" })
  public ParentID: number = 0;
  // @ts-ignore
  @Column({ type: "text" })
  public Manager: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public GroupManager: string = "";
  // @ts-ignore
  @Column({ type: "int" })
  public DeptLevel: number = 0;
  // @ts-ignore
  @Column({ type: "text" })
  public ParentDept: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public Url: string = "";
  // @ts-ignore
  @Column({ type: "int" })
  public Order: number = 0;
  // @ts-ignore
  @Column({ type: "int" })
  public DeptStatus: number = 0;
  // @ts-ignore
  @Column({ type: "boolean" })
  public Status: boolean = false;
  // @ts-ignore
  @Column({ type: "boolean" })
  public IsRoot: boolean = false;
  // @ts-ignore
  @Column({ type: "text" })
  public Modified: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public Created: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public DepartmentTitle: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public SPNhomUserId: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public MultipleManager: string = "";
  // @ts-ignore
  @Column({ type: "text" })
  public MultipleManagerGroup: string = "";

  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.SiteName = data.SiteName || "";
      this.Title = data.Title || "";
      this.TenToChucVN = data.TenToChucVN || "";
      this.Code = data.Code || "";
      this.ParentID = data.ParentID || 0;
      this.Manager = data.Manager || "";
      this.GroupManager = data.GroupManager || "";
      this.DeptLevel = data.DeptLevel || 0;
      this.ParentDept = data.ParentDept || "";
      this.Url = data.Url || "";
      this.Order = data.Order || 0;
      this.DeptStatus = data.DeptStatus || 0;
      this.Status = data.Status || false;
      this.IsRoot = data.IsRoot || false;
      this.Modified = data.Modified || "";
      this.Created = data.Created || "";
      this.DepartmentTitle = data.DepartmentTitle || "";
      this.SPNhomUserId = data.SPNhomUserId || "";
      this.MultipleManager = data.MultipleManager || "";
      this.MultipleManagerGroup = data.MultipleManagerGroup || "";
    }
  }

  static fromJson(json: any): BeanDepartment {
    return new BeanDepartment(json);
  }
  static listFromJson(jsonArray: any[]): BeanDepartment[] {
    return jsonArray.map((item) => new BeanDepartment(item));
  }
}
