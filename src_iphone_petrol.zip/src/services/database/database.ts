import {getConnectionManager, Connection} from 'typeorm/browser';
import {  BeanBanLanhDao } from "./models/bean_ban_lanh_dao.ts";
import { BeanSetting } from "./models/bean_setting.ts";
import { BeanDepartment } from "./models/bean_department.ts";
import { BeanCoQuanGui } from "./models/bean_co_quan_gui.ts";
import { BeanLoaiVanBan } from "./models/bean_loai_van_ban.ts";
import { BeanNguoiKyVanBan } from "./models/bean_nguoi_ky_van_ban.ts";
import { BeanUser } from "./models/bean_user.ts";
import { BeanGroup } from "./models/bean_group.ts";

export class Database {
  private static db: Promise<Connection | null> | null = null;

  static async initializeDatabase(): Promise<void> {
    if (!Database.db) {
      const connectionManager = getConnectionManager();
      Database.db = connectionManager
        .create({
          type: 'react-native',
          database: 'your-database-name.db',
          location: 'default',
          synchronize: true,
          logging: true,
          entities: [
            BeanBanLanhDao,
            BeanSetting,
            BeanDepartment,
            BeanCoQuanGui,
            BeanLoaiVanBan,
            BeanNguoiKyVanBan,
            BeanUser,
            BeanGroup
          ],
        })
        .connect();
    }

    await Database.db;
  }

  private static async closeConnection(): Promise<void> {
    if (Database.db) {
      const connection = await Database.db;
      await connection?.close();
      Database.db = null;
    }
  }

  public static async getDb(): Promise<Connection | null> {
    if (!Database.db) {
      await Database.initializeDatabase();
    }

    return Database.db;
  }

  public static async closeDb(): Promise<void> {
    await Database.closeConnection();
  }
}
