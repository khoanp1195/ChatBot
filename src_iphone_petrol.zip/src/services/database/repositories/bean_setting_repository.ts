import {EntityRepository, Repository} from 'typeorm';
import { BeanBanLanhDao } from "../models/bean_ban_lanh_dao.ts";
import { BeanSetting } from "../models/bean_setting.ts";

// @ts-ignore
@EntityRepository(BeanSetting)
export class BeanSettingRepository extends Repository<BeanSetting> {
  async insertAll(datas: BeanSetting[]): Promise<void> {
    await this.manager.save(datas);
  }
  async findAll(): Promise<BeanSetting[]> {
    const queryString = `SELECT * FROM BeanSetting`;
    return this.query(queryString);
  }
  async findByKey(key:string): Promise<BeanSetting[]> {
    const queryString = `SELECT VALUE FROM BeanSetting WHERE KEY = '${key}'`;
    return this.query(queryString);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanSetting`;
    return this.query(queryString);
  }
}
