import {EntityRepository, Repository} from 'typeorm';
import { BeanNguoiKyVanBan } from "../models/bean_nguoi_ky_van_ban.ts";

// @ts-ignore
@EntityRepository(BeanNguoiKyVanBan)
export class BeanNguoiKyVanBanRepository extends Repository<BeanNguoiKyVanBan> {
  async insertAll(datas: BeanNguoiKyVanBan[]): Promise<void> {
    await this.manager.save(datas);
  }
  async findAll(): Promise<BeanNguoiKyVanBan[]> {
    const queryString = `SELECT * FROM BeanNguoiKyVanBan`;
    return this.query(queryString);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanNguoiKyVanBan`;
    return this.query(queryString);
  }
}
