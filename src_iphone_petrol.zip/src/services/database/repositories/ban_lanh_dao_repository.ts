import {EntityRepository, Repository} from 'typeorm';
import { BeanBanLanhDao } from "../models/bean_ban_lanh_dao.ts";
import { subsiteStore } from "../../../config/constants.ts";

// @ts-ignore
@EntityRepository(BeanBanLanhDao)
export class BanLanhDaoRepository extends Repository<BeanBanLanhDao> {
  async insertAll(datas: BeanBanLanhDao[]): Promise<void> {
    await this.manager.save(datas);
  }
  async findByTitle(title: string): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT * FROM BeanBanLanhDao WHERE Title LIKE '%${title}%'`;
    return this.query(queryString);
  }
  async findByLanhDaoID(ID: string): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT LanhDao FROM BeanBanLanhDao WHERE ID = ${ID}`;
    return this.query(queryString);
  }
  async findAllDifLanhDao(lanhDao: string): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT * FROM BeanBanLanhDao WHERE LanhDao <> ${lanhDao} ORDER BY [Orders]`;
    return this.query(queryString);
  }
  async findAllLanhDao(lanhDao: string): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT * FROM BeanBanLanhDao WHERE LanhDao IN (${lanhDao}) ORDER BY [Orders]`;
    return this.query(queryString);
  }
  async findAll(): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT * FROM BeanBanLanhDao`;
    return this.query(queryString);
  }
  async findLanhDaoByID(column:string,id:number): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT ${column} FROM BeanBanLanhDao WHERE ID = ${id} `;
    return this.query(queryString);
  }
  async excuseQuery(str:string): Promise<BeanBanLanhDao[]> {
    return this.query(str);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanBanLanhDao`;
    return this.query(queryString);
  }
  async findById(column:string,id: string):Promise<BeanBanLanhDao[]>{
    const queryString = `SELECT ${column} FROM BeanBanLanhDao WHERE ID = ${id}`;
    return this.query(queryString);
  }
  async findDiffId(column:string,id: string):Promise<BeanBanLanhDao[]>{
    const queryString = `select ${column} from BanLanhDao where ID <> ${id} `;
    return this.query(queryString);
  }
  async findByLanhDao(column:string,lanhdao: string):Promise<BeanBanLanhDao[]>{
    const queryString = `SELECT ${column} FROM BeanBanLanhDao WHERE LanhDao = ${lanhdao} ORDER BY [Orders] `;
    return this.query(queryString);
  }
  async findInLanhDao(column:string,lanhdao: string):Promise<BeanBanLanhDao[]>{
    const queryString = `SELECT ${column} FROM BeanBanLanhDao WHERE LanhDao IN(${lanhdao}) ORDER BY [Orders] `;
    return this.query(queryString);
  }
  async findBeanDepartmentById( column:string,id: string):Promise<BeanBanLanhDao[]>{
    const queryString = `SELECT ${column} FROM BeanDepartment WHERE DeptStatus = 1 AND ID = ${id} ORDER BY [Order]`;
    return this.query(queryString);
  }
  async findBeanDepartmentByUrl( column:string,url: string):Promise<BeanBanLanhDao[]>{
    const queryString = `SELECT ${column} FROM BeanDepartment WHERE Url = '${subsiteStore.getSubsite()}' ORDER BY [Order] `;
    return this.query(queryString);
  }
}
