import { EntityRepository, Repository } from 'typeorm';
import { BeanBanLanhDao } from "../models/bean_ban_lanh_dao.ts";
import { BeanSetting } from "../models/bean_setting.ts";
import { BeanDepartment } from "../models/bean_department.ts";

// @ts-ignore
@EntityRepository(BeanDepartment)
export class BeanDepartmentRepository extends Repository<BeanDepartment> {
  async insertAll(datas: BeanDepartment[]): Promise<void> {
    await this.manager.save(datas);
  }
  async findByTitle(title: string): Promise<BeanDepartment[]> {
    const queryString = `SELECT * FROM BeanDepartment WHERE Title LIKE '%${title}%'`;
    return this.query(queryString);
  }
  async findAll(): Promise<BeanDepartment[]> {
    const queryString = `SELECT * FROM BeanDepartment`;
    return this.query(queryString);
  }
  async findDepartmentByIDAndDeptStatus(column: string, id: number, depStatus: number): Promise<BeanDepartment[]> {
    const queryString = `SELECT ${column} FROM BeanDepartment WHERE DeptStatus = ${depStatus} AND ID = ${id} ORDER BY [Order] `;
    return this.query(queryString);
  }
  async findDepartmentByUrl(column: string, url: string): Promise<BeanDepartment[]> {
    const queryString = `SELECT ${column} FROM BeanDepartment WHERE Url LIKE '${url}' ORDER BY [Order] `;
    return this.query(queryString);
  }
  async excuseQuery(str: string): Promise<BeanDepartment[]> {
    return this.query(str);
  }
  async getDepartmentByParentID(departmentID: number): Promise<BeanDepartment[]> {
    const queryString = `SELECT ID,Title,MultipleManager,Url,GroupManager FROM BeanDepartment WHERE (Url IS NULL OR Url = '') AND DeptStatus = 1 AND ParentID = ${departmentID} ORDER BY [Order] `;
    return this.query(queryString);
  }

  async getDepartmentByParentIDURLEmpty(column: string, id: number, deptStatus: number): Promise<BeanDepartment[]> {
    const queryString = `SELECT ${column} FROM BeanDepartment WHERE (Url IS NULL OR Url = '') AND DeptStatus = ${deptStatus} AND ParentID = ${id} ORDER BY [Order] `;
    return this.query(queryString);
  }

  async deleteAll(): Promise<void> {
    const queryString = `Delete FROM BeanDepartment`;
    return this.query(queryString);
  }

  async findDepartmentByIsRoot() {
    const queryString = `SELECT * FROM BeanDepartment WHERE IsRoot = 1`;
    return this.query(queryString);
  }
}
