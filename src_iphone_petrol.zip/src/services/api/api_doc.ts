import { get, post } from "../api/api_client.ts";
import { BeanGroup } from "services/database/models/bean_group.ts";
import { DbServices } from "services/database/db_service.ts";

export const getVBChoXuLy=async (limit:number,offset:number,status:number,ModuleId:string,FromDate:string,ToDate:string,FilterText:string,IsHigh:boolean)=>{
    const res= await get(
      '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
      {
        func:'Get',
        Action:'ProcessingNotify',
        limit:limit,
        offset:offset,
        status:status,
        Params:'IsHigh,Status,Limit,Offset,ModuleId,ToDate,FromDate,FilterText,IsCount',
        IsCount:0,
        ModuleId:ModuleId,
        FromDate:FromDate,
        ToDate:ToDate,
        FilterText:FilterText,
        IsHigh:IsHigh?1:0
      }
    )
    if(res.data["status"]!="ERR")
    {
        return res.data["data"];
    }
    else
    {
        return null;
    }
}
export const getVBPH=async (limit:number,offset:number,status:number,FilterText:string)=>{
    const res= await get(
      '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
      {
          func:'Get',
          Action:'PhoiHop',
          limit:limit,
          offset:offset,
          status:status,
          Params:'Status,Limit,Offset,FilterText,IsCount',
          IsCount:0,
          FilterText:FilterText
      }
    )
    if(res.data["status"]!="ERR")
    {
        return res.data["data"];
    }
    else
    {
        return null;
    }
}
export const getThongBao=async (limit:number,offset:number,status:number,ModuleId:string,FromDate:string,ToDate:string,FilterText:string)=>{
  const res= await get(
    '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func:'Get',
      Action:'TCThongBao',
      limit:limit,
      offset:offset,
      status:status,
      Params:'Status,Limit,Offset,ModuleId,ToDate,FromDate,FilterText,IsCount',
      IsCount:0,
      ModuleId:ModuleId,
      FromDate:FromDate,
      ToDate:ToDate,
      FilterText:FilterText
    }
  )
  if(res.data["status"]!="ERR")
  {
    return res.data["data"];
  }
  else
  {
    return null;
  }
}

export const getVBDen=async (Action:string,
                             limit:number,
                             offset:number,
                             status:number,
                             FromDate:string,
                             ToDate:string,
                             FilterText:string,
                             BanLanhDao:string,
                             TinhTrang:string
)=>{
  const res= await get(
    '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func:'Get',
      Action:Action,
      limit:limit,
      offset:offset,
      status:status,
      Params:'Status,Limit,BanLanhDao,TinhTrang,FromDate,ToDate,Offset,FilterText,IsCount',
      IsCount:0,
      FromDate:FromDate,
      ToDate:ToDate,
      FilterText:FilterText,
      BanLanhDao:BanLanhDao,
      TinhTrang:TinhTrang,
    }
  )
  if(res.data["status"]!="ERR")
  {
    return res.data["data"];
  }
  else
  {
    return null;
  }
}
export const getVBDi=async (Action:string,
                             limit:number,
                             offset:number,
                             status:number,
                             FromDate:string,
                             ToDate:string,
                             FilterText:string,
                             TinhTrang:string
)=>{
  const res= await get(
    '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func:'Get',
      Action:Action,
      limit:limit,
      offset:offset,
      status:status,
      Params:'Status,Limit,BanLanhDao,TinhTrang,FromDate,ToDate,Offset,FilterText,IsCount',
      IsCount:0,
      FromDate:FromDate,
      ToDate:ToDate,
      FilterText:FilterText,
      TinhTrang:TinhTrang,
    }
  )
  if(res.data["status"]!="ERR")
  {
    return res.data["data"];
  }
  else
  {
    return null;
  }
}

export const getHSTL=async (MenuId:number
)=>{
  const res= await get(
    '/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func:'Get',
      Action:'HSLT',
      Params:'MenuId',
      MenuId:MenuId,
    }
  )
  if(res.data["status"]!="ERR")
  {
    return res.data["data"];
  }
  else
  {
    return null;
  }
}

