import { get, post } from "./api_client.ts";
import { getCurrentTimeFormatted, getDisplayTxtFromDateString, isNullOrEmpty } from "../../utils/functions.ts";
import { EnumTaskAction, EnumTaskRole } from "../../config/enum.ts";
import { subsiteStore } from "../../config/constants.ts";
import strings from "../../assets/strings.ts";

export const sendActionTaskVBDen = async (action: number, taskVB: any) => {
    let obj;
    console.log("item nè sendActionTaskVBDen", JSON.stringify(taskVB))
    switch (taskVB.Role) {
        case EnumTaskRole.Assignor:
        case EnumTaskRole.AssignorPBan: {
            ///NhiemVuDaPhanCongView
            switch (action) {
                case EnumTaskAction.Feedback:
                    obj = {
                        ID: taskVB.ID,
                        YKienChiDao: taskVB.YKienChiDao,
                    };
                    break;
                case EnumTaskAction.Save:
                    if (taskVB.DueDate != undefined)
                        obj = {
                            ID: taskVB.ID,
                            YKienChiDao: taskVB.YKienChiDao,
                            DueDate: getDisplayTxtFromDateString(taskVB.DueDate, strings.SubmitFormatDate),
                            AssignedToUserValue: taskVB.AssignedToUserValue,
                        };
                    else {
                        obj = {
                            ID: taskVB.ID,
                            YKienChiDao: taskVB.YKienChiDao,
                            AssignedToUserValue: taskVB.AssignedToUserValue,
                        };
                    }
                    break;
                case EnumTaskAction.Assignment:
                    obj = {
                        ID: taskVB.ID,
                        NguoiChuyen: taskVB.NguoiChuyen,
                        ListAssignmentUsers: taskVB.ListAssignmentUsers,
                    };
                    break;
                default: break;
            }
            break;
        }
        default: {
            ///TaskDetailScreen
            switch (action) {
                case EnumTaskAction.Completed:
                case EnumTaskAction.Feedback:
                    obj = {
                        ID: taskVB.ID,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                    };
                    break;
                case EnumTaskAction.Save:
                    obj = {
                        ID: taskVB.ID,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                        TrangThai: taskVB.TrangThai,
                        Percent: taskVB.Percent,
                    };
                    break;
                case EnumTaskAction.Assignment:
                    obj = {
                        ID: taskVB.ID,
                        NguoiChuyen: taskVB.NguoiChuyen,
                        ListAssignmentUsers: taskVB.ListAssignmentUsers,
                        ListAssignmentDept: taskVB.ListAssignmentDept,
                        Percent: taskVB.Percent,
                    };
                    break;
                default: break;
            };
            break;
        }
    };
    if (__DEV__) console.log("item chuẩn bị gửi nè", JSON.stringify(obj))
    let newData = new FormData();
    newData.append("func", "taskSubmit");
    newData.append("action", action);
    newData.append("data", JSON.stringify(obj));
    const res = await post(
        "/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx",
        {
        },
        newData
    );

    if (res.data["status"] != "ERR") {
        return true;
    } else {
        return false;
    }
};

export const sendActionTaskVBBH = async (action: number, taskVB: any) => {
    console.log(" nè nè taskVB",taskVB)
    let obj;
    switch (taskVB.Role) {
        case EnumTaskRole.Assignor:
        case EnumTaskRole.AssignorPBan: {
            switch (action) {
                case EnumTaskAction.Feedback:
                    obj = {
                        ID: taskVB.ID,
                        YKienChiDao: taskVB.YKienChiDao,
                        TrangThai: taskVB.TrangThai,
                    };
                    break;
                case EnumTaskAction.Save:
                    if (taskVB.DueDate != undefined)
                        obj = {
                            ID: taskVB.ID,
                            YKienChiDao: taskVB.YKienChiDao,
                            DueDate: getDisplayTxtFromDateString(taskVB.DueDate, strings.SubmitFormatDate),
                            TrangThai: taskVB.TrangThai,
                            AssignedToUserValue: taskVB.AssignedToUserValue,
                        };
                    else {
                        obj = {
                            ID: taskVB.ID,
                            YKienChiDao: taskVB.YKienChiDao,
                            TrangThai: taskVB.TrangThai,
                            AssignedToUserValue: taskVB.AssignedToUserValue,
                        };
                    }
                    break;
                case EnumTaskAction.Assignment:
                    obj = {
                        ID: taskVB.ID,
                        NguoiChuyen: taskVB.NguoiChuyen,
                        ListAssignmentUsers: taskVB.ListAssignmentUsers,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                    };
                    break;
                default: break;
            }
            break;
        }
        default: {
            switch (action) {
                case EnumTaskAction.Completed:
                case EnumTaskAction.Feedback:
                    obj = {
                        ID: taskVB.ID,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                        TrangThai: taskVB.TrangThai,
                    };
                    break;
                case EnumTaskAction.Save:
                    obj = {
                        ID: taskVB.ID,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                        TrangThai: taskVB.TrangThai,
                        Percent: taskVB.Percent,
                    };
                    break;
                case EnumTaskAction.Assignment:
                    obj = {
                        ID: taskVB.ID,
                        NguoiChuyen: taskVB.NguoiChuyen,
                        ListAssignmentUsers: taskVB.ListAssignmentUsers,
                        YKienCuaNguoiGiaiQuyet: taskVB.YKienCuaNguoiGiaiQuyet,
                        Percent: taskVB.Percent,
                    };
                    break;
                default: break;
            };
            break;
        }
    };

    let newData = new FormData();
    newData.append("data", JSON.stringify(obj));
    const res = await post(
        "/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx",
        {
            func:"taskSubmit",
            action:action,
        },
        newData
    );

    if (res.data["status"] != "ERR") {
        return true;
    } else {
        return false;
    }
};