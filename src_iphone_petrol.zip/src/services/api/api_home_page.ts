import { get } from "./api_client.ts";

export const getCount = async () => {
  const res = await get(
    "/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx"
    ,
    {
      func: "getCount"
    }
  );

  if (res.data["status"] != "ERR") {
    return res.data["data"];
  } else {
    return { "ThongBao": 0, "VBCanXuLy": 0, "VBCanXuLyHigh": 0, "VBPhoiHop": 0 };
  }
};
