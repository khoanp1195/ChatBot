import { get } from "../api/api_client.ts";

export const getUserInfoQRCode = async () => {
    const res = await get(
        '/_layouts/15/VuThao.Petrolimex.API/ApiDanhBa.ashx',
        {
            func: 'GetQRCodeDanhBaUser',
        },
    );
    if (res.data["status"] != "ERR") {
        return res.data["data"];
    }
    else {
        return null;
    }
}
