import { get } from "../../services/api/api_client.ts";
import { getCurrentTimeFormatted } from "../../utils/functions.ts";

export const getDetailVBDi = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'get',
      rid: id,
      actionPer: 1,
      modified: getCurrentTimeFormatted()
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getAttFileVBDi = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getAttachFiles',
      rid: id,
      type: 1,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getIdeaOfBODv2 = async (id: number, SPItemId: number, SPListId: string) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getIdeaOfBODv2',
      rid: id,
      SPItemId: SPItemId,
      SPListId: SPListId,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getWorkflowHistoryVBDi = async (id: number, SPListId: string) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getWorkflowHistoryv2',
      rid: id,
      SPListId: SPListId,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}
