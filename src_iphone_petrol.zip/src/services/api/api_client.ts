import axios from 'axios';
import { BASE_URL, cookieStore, getFullLink, subsiteStore } from "../../config/constants.ts";
import { isNullOrEmpty } from "../../utils/functions.ts";
import RNFS from 'react-native-fs';
import ReactNativeBlobUtil from 'react-native-blob-util';
export const get = async (url: String, paramsUrl: any) => {
  const urlRequest = getFullLink() + url;
  const res = await axios({
    method: 'get',
    url: urlRequest,
    params: paramsUrl,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      //'Cookie':cookieStore.getCookie()
    },
  });
  if (__DEV__) {
    console.log('\x1B[32mApi:\x1B[0m', BASE_URL + `${isNullOrEmpty(subsiteStore.getSubsite()) ? "" : '/' + subsiteStore.getSubsite()}` + url + '?' + new URLSearchParams(paramsUrl).toString());
    console.log('\x1B[32mRes:\x1B[0m', JSON.stringify(res.data));
  }
  return res;
};
export const post = async (url: string, paramsUrl: any, dataPost: FormData) => {
  const urlRequest = getFullLink() + url;
  const res = await axios({
    method: 'post',
    url: urlRequest,
    params: paramsUrl,
    data: dataPost,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
      // 'Cookie': cookieStore.getCookie()
    },
  });
  if (__DEV__) {
    console.log('\x1B[32mApi:\x1B[0m', BASE_URL + `${isNullOrEmpty(subsiteStore.getSubsite()) ? "" : '/' + subsiteStore.getSubsite()}` + url + '?' + decodeURI(new URLSearchParams(paramsUrl).toString()));
    console.log('\x1B[32mRes:\x1B[0m', JSON.stringify(res.data));
    console.log('\x1B[32mPost:\x1B[0m', dataPost);
  }
  return res;
};

export const downloadFile = async (url: String) => {


  try {
    const urlRequest = getFullLink() + url;
    console.log("lik down", urlRequest);
    const filename = url.split('/').pop();
    const DirectoryPath = RNFS.DocumentDirectoryPath;// + "/DownloadedFiles";//RNFS.ExternalStorageDirectoryPath + '/' + "";

    // RNFS.exists(DirectoryPath)
    //   .then((exists) => {
    //     if (exists) {
    //       console.log("Folder tồn tại gòi");
    //     } else {
    //       console.log("Folder chưa tồn tại");
    //       RNFS.mkdir(DirectoryPath);
    //     }
    //   });

    //const localFilePath = DirectoryPath + `/${filename}`
    const localFilePath = DirectoryPath + `/${filename}`
    const res = await axios({
      method: 'get',
      url: urlRequest,
      responseType: 'arraybuffer',
    });

    if (__DEV__) {
      console.log(res);
    }
    await RNFS.writeFile(localFilePath, res.request._response, 'base64');
    const exist = await RNFS.exists(localFilePath);
    if (exist) {
      console.log('exist', exist);
      return localFilePath;
    }
    else {
      console.log('not exist')
      return '';
    }
    // console.log("tải rồi nè", localFilePath);
  }
  catch (e) {
    console.log("tải không được");
    return '';
  }

  // try {
  //   await RNFS.writeFile(localFilePath, res.request._response, 'base64');
  //   console.log("tải rồi nè", localFilePath);
  //   return localFilePath
  // }
  // catch (e) {
  //   console.log("tải không được");
  // }

  // return ''
};

// export const downloadFile1 = (url: String) => {
//   const urlRequest = BASE_URL + `${isNullOrEmpty(subsiteStore.getSubsite()) ? "" : '/' + subsiteStore.getSubsite()}` + url;
//   const filename = url.split('/').pop();
//   const localFilePath = RNFS.DocumentDirectoryPath + `/${filename}`

//   const res = axios({
//     method: 'get',
//     url: urlRequest,
//     responseType: 'arraybuffer',
//   })
//     .then((res) => {
//       try {
//         RNFS.writeFile(localFilePath, res.request._response, 'base64');
//         console.log("lưu rồi nè", localFilePath);
//         return localFilePath
//       }
//       catch (e) {
//         console.log("lưu không được");
//       }
//       return ''
//     })
//     .catch((e) => {
//       console.log("tải không được", e)
//     });

//   if (__DEV__) {
//     console.log(res);
//   }
// };

export const downloadFile2 = async (item: string) => {
  if (!isNullOrEmpty(item)) {
    const response = await ReactNativeBlobUtil.fetch(
      'GET',
      BASE_URL
      + item,
    )
    // const guui = uuid.v4();
    const fileName = item.split('/').pop();;
    // const fileExtention = getExtension(item.Path)
    const parentFolderPath = `${RNFS.DocumentDirectoryPath}/${"DownloadFiles"}`;
    const filePath: string = parentFolderPath + `/${fileName}`//fileExtention
    const status = response.info().status;

    if (status === 200) {
      console.log('File OK: ', status);
      const base64Str = response.base64();
      await ReactNativeBlobUtil.fs.mkdir(parentFolderPath)
      await ReactNativeBlobUtil.fs.writeFile(filePath, base64Str, 'base64')
      await ReactNativeBlobUtil.fs.exists(filePath).then(res => {
        if (res) {
          console.log('exist', res);
          return filePath;
        }
        else {
          console.log('not exist')
        }
      })
      //   const options = {
      //     url: `file://${filePath}`,
      //   };

      //   await Share.open(options)
      //     .then(r => {
      //       console.log(`Share exists`)

      //       if (__DEV__)
      //         console.log(r);
      //     })
      //     .catch(e => {
      //       console.log('share error: ', e);
      //     });
      // }
    }
  }
}