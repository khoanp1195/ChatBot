import { Text } from "react-native";

const TextRequire = () => {
    return <Text style={{ color: 'red' }}>
        {
            ' (*)'
        }
    </Text>;
}
export default TextRequire;