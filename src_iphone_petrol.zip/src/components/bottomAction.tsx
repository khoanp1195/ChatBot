import { Image, Text, TouchableOpacity, View } from "react-native";
import { getRequireImageAction } from "../utils/functions.ts";
import { ClassActionTasks } from "../services/database/models/classActionTasks.ts";
import { FC } from "react";

interface Props{
  data:ClassActionTasks[]|null|undefined;
  onPressAction(ID:number):void;
}
export const BottomAction:FC<Props> = ({ data,onPressAction }) => {
  const VisibleAction = () => {
    if(data!=null)
    {
      if (data.length == 1) {
        return <TouchableOpacity
          onPress={()=>onPressAction(data[0].ID)}
          style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical:5 }}>
          <Image style={{ height: 30, width: 30, marginRight: 10 }}
                 resizeMode={"contain"}
                 source={getRequireImageAction(data[0].ID, data[0].Class)} />
          <Text>{data[0].Title}</Text>
        </TouchableOpacity>;
      } else if(data.length==2)
      {
        return <View style={{flexDirection:'row',paddingVertical:5}}>
          <TouchableOpacity
            onPress={()=>onPressAction(data[0].ID)}
            style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10,flex:1 }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }}
                   resizeMode={"contain"}
                   source={getRequireImageAction(data[0].ID, data[0].Class)} />
            <Text>{data[0].Title}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={()=>onPressAction(data[1].ID)}
            style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10,flex:1 }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }}
                   resizeMode={"contain"}
                   source={getRequireImageAction(data[1].ID, data[1].Class)} />
            <Text>{data[1].Title}</Text>
          </TouchableOpacity>
        </View>
      } else if(data.length>2)
      {
        return <View style={{flexDirection:'row',paddingVertical:5}}>
          <TouchableOpacity
            onPress={()=>onPressAction(data[0].ID)}
            style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10,flex:4.5 }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }}
                   resizeMode={"contain"}
                   source={getRequireImageAction(data[0].ID, data[0].Class)} />
            <Text>{data[0].Title}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={()=>onPressAction(data[1].ID)} style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10,flex:4.5 }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }}
                   resizeMode={"contain"}
                   source={getRequireImageAction(data[1].ID, data[1].Class)} />
            <Text>{data[1].Title}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={()=>onPressAction(0)} style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", padding: 10,flex:1 }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }}
                   resizeMode={"contain"}
                   source={require('../assets/images/icon_more.png')} />
          </TouchableOpacity>
        </View>
      }
    }
    else
      return <View />;
  };

  return <View style={{ backgroundColor: "white",flex:1 }}>
    <VisibleAction />
  </View>;
};
