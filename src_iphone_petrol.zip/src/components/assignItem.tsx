import { SwipeableRight } from "../components/swipeableRight.tsx";
import { Image, Pressable, Text, TouchableOpacity, View } from "react-native";
import { showAlert } from "../screens/commonAlertView.jsx";
import { convertStringToMoment, getListItemBackground, isNullOrEmpty } from "../utils/functions.ts";
import React from "react";
import { appMainBlueColor } from "../utils/color.ts";

// @ts-ignore
export const AssignItem = ({ item, index, onDelete, onShowCalendar, textLabelBellowTitle = "Đơn vị thành viên" }) => {
  return <SwipeableRight
    rightActions={<Pressable onPress={() => {
      showAlert("Bạn chắc chắn muốn xóa", false, () => {
        // @ts-ignore
        onDelete();
      }, "Không", "Có");
    }} style={{ backgroundColor: "red", flex: 1, justifyContent: "center", paddingHorizontal: 15 }}>
      <Image
        resizeMode={"contain"}
        style={{ height: 20, width: 20 }}
        source={require("../assets/images/icon_swipe_delete.png")} />
    </Pressable>}>
    <View style={{ padding: 10, flexDirection: "row", backgroundColor: getListItemBackground(index % 2 != 0) }}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: "black", fontSize: 15 }}>{item.Title}</Text>
        <Text>{textLabelBellowTitle}</Text>
      </View>

      <TouchableOpacity onPress={() => {
        onShowCalendar()
      }}>
        {
          isNullOrEmpty(item.HanXuLy) ? <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
            source={require("../assets/images/icon_duedate.png")} /> :
            <Text style={{ color: appMainBlueColor }}>
              {
                convertStringToMoment(item.HanXuLy).format("DD/MM/YY")
              }
            </Text>
        }
      </TouchableOpacity>
    </View>
  </SwipeableRight>;
}
