import React, { FC, useState } from 'react';
import { StyleProp, StyleSheet, ViewStyle } from 'react-native';
import FastImage from 'react-native-fast-image';
import { isNullOrEmpty } from "../utils/functions.ts";
import { cookieStore } from "../config/constants.ts";

interface Props {
  onRetryPress?: () => any;
  urlOnline: string;
  priority?: any;
  resizeMode?: any;
  styleImg?: StyleProp<ViewStyle>;
  defaultImage: any;
}

export const CustomFastImage: FC<Props> = (props: Props) => {
  const { urlOnline = '', resizeMode, priority, defaultImage, styleImg = {} } = props;
  const [imageSource, setImageSource] = useState(
    !isNullOrEmpty(urlOnline)
      ? {
        uri: props.urlOnline,
        priority: priority ? priority : FastImage.priority.normal,
        headers: {
          cookie: cookieStore.getCookie()
        }
      }
      : defaultImage
  );

  const onError = () => {
    setImageSource(defaultImage);
  };
  return (
    <FastImage
      onError={onError}
      style={[styleImg]}//styles.container,
      source={imageSource}
      defaultSource={defaultImage}
      resizeMode={resizeMode ? resizeMode : FastImage.resizeMode.contain}

    />
  );
};

const styles = StyleSheet.create({
  container: {
    height: 40,
    width: 40,
    marginRight: 10,
    borderRadius: 20,
  },
});

