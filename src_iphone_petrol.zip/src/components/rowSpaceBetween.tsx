import React, { ReactNode } from 'react';
import { View } from 'react-native';

interface Props {
  children?: ReactNode;
}

const RowSpaceBetween = ({ children }: Props) => {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      {children}
    </View>
  );
};

export default RowSpaceBetween;
