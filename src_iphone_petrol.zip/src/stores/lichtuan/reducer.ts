import { CHANGE_DONVI } from "./action_types.ts";


const initialState = {
  item: [],
  title: '',
  reload : false
};

const typeLichTuanReducer = (state = initialState,   action: {type:any, payload:any}) => {
  switch (action.type) {
    case CHANGE_DONVI:
      return {
        ...state,
        item: action.payload,
        title: action.payload.Title,
        reload: true
      };
    default:
      return state;
  }
}

export default typeLichTuanReducer;
