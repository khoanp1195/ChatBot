import * as types from './action_types.ts';

export const changeDataDonvi = (item:any) => ({
  type: types.CHANGE_DONVI,
  payload: item
});

