export const VCXLScreen='VCXLScreen';
export const VBPHScreenState='VBPHScreenState';
export const VCXLHighScreen='VCXLHighScreen';
export const TBScreen='TBScreen';
export const VBDenTitle='VBDenTitle';
export const VBDenChoChoYKien='VBDenChoChoYKien';
export const VBDenChoThucHien ='VBDenChoThucHien';
export const VBDenDaGiaiQuyet='VBDenDaGiaiQuyet';
export const VBDenThongBao ='VBDenThongBao';
export const VBDenTatCa ='VBDenTatCa';

export const VBDiTitle ='VBDiTitle';
export const VBDiChoPheDuyet ='VBDiChoPheDuyet';
export const VBDiDaPheDuyet ='VBDiDaPheDuyet';
export const VBDiDaPhatHanh ='VBDiDaPhatHanh';
export const VBDiThongBao ='VBDiThongBao';
export const VBDiTatCa ='VBDiTatCa';
export const HSLTTatCa ='HSLTTatCa';
export const HSLTCuaToi ='HSLTCuaToi';


// Lịch
export  const LichDuKien='LichDuKien';
export  const LichChoDuyet='LichChoDuyet';
export  const LichChoXepPhong='LichChoXepPhong';
export  const LichTatCa='LichTatCa';
// Tien Ich

export  const DangKyXuatAn='DangKyXuatAn';
export  const BaoCaoThongMinhUtil='BaoCaoThongMinhUtil';
export  const TinNoiBo='TinNoiBo';
export  const DatVeMayBay='DatVeMayBay';
export  const DatVeXe='DatVeXe';

