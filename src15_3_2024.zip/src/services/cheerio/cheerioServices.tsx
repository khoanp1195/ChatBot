import Cheerio from "cheerio";

export const getImagePathTagImageCheerio = (value: string) => {
    if (value!=undefined && value.includes("img")) {
        const $ = Cheerio.load(value);
        return $('img').attr('src');
    }
    return value;
}