import { Database } from "./database";
import { BanLanhDaoRepository } from "./repositories/ban_lanh_dao_repository.ts";
import { BeanSetting } from "./models/bean_setting.ts";
import { BeanSettingRepository } from "./repositories/bean_setting_repository.ts";
import { BeanDepartmentRepository } from "./repositories/bean_department_repository.ts";
import { BeanCoQuanGuiRepository } from "./repositories/bean_co_quan_gui_repository.ts";
import { BeanLoaiVanBanRepository } from "./repositories/bean_loai_van_ban_repository.ts";
import { BeanNguoiKyVanBanRepository } from "./repositories/bean_nguoi_ky_van_ban_repository.ts";
import { BeanUserRepository } from "./repositories/bean_user_repository.ts";
import { BeanGroupRepository } from "./repositories/bean_group_repository.ts";

export class DbServices {
  private static instance: DbServices | null = null;
  private connection: any;
  private banlanhDao: BanLanhDaoRepository | null = null;
  private beanSettingDao: BeanSettingRepository | null = null;
  private beanDepartmentDao: BeanDepartmentRepository | null = null;
  private beanCoQuanGuiDao: BeanCoQuanGuiRepository | null = null;
  private beanLoaiVanBanDao: BeanLoaiVanBanRepository | null = null;
  private beanNguoiKyVanBanDao: BeanNguoiKyVanBanRepository | null = null;
  private beanUserDao: BeanUserRepository | null = null;
  private beanGroupDao: BeanGroupRepository | null = null;

  private constructor() {
  }

  public static getInstance(): DbServices {
    if (!DbServices.instance) {
      DbServices.instance = new DbServices();
    }
    return DbServices.instance;
  }

  public async initialize(): Promise<void> {
    if (!this.connection) {
      this.connection = await Database.getDb();
      this.banlanhDao =
        this.connection.getCustomRepository(BanLanhDaoRepository);
      this.beanSettingDao =
        this.connection.getCustomRepository(BeanSettingRepository);
      this.beanDepartmentDao =
        this.connection.getCustomRepository(BeanDepartmentRepository);
      this.beanCoQuanGuiDao =
        this.connection.getCustomRepository(BeanCoQuanGuiRepository);
      this.beanLoaiVanBanDao =
        this.connection.getCustomRepository(BeanLoaiVanBanRepository);
      this.beanNguoiKyVanBanDao =
        this.connection.getCustomRepository(BeanNguoiKyVanBanRepository);
      this.beanUserDao =
        this.connection.getCustomRepository(BeanUserRepository);
      this.beanGroupDao =
        this.connection.getCustomRepository(BeanGroupRepository);
    }
  }

  public async close(): Promise<void> {
    if (this.connection) {
      await Database.closeDb();
      this.connection = null;
      this.banlanhDao = null;
    }
  }

  public getBanLanhDaoRepository(): BanLanhDaoRepository {
    if (!this.banlanhDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.banlanhDao;
  }

  public getBeanSettingRepository(): BeanSettingRepository {
    if (!this.beanSettingDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanSettingDao;
  }

  public getBeanDepartmentRepository(): BeanDepartmentRepository {
    if (!this.beanDepartmentDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanDepartmentDao;
  }

  public getBeanCoQuanGuiRepository(): BeanCoQuanGuiRepository {
    if (!this.beanCoQuanGuiDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanCoQuanGuiDao;
  }

  public getBeanLoaiVanBanRepository(): BeanLoaiVanBanRepository {
    if (!this.beanLoaiVanBanDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanLoaiVanBanDao;
  }

  public getBeanNguoiKyVanBanRepository(): BeanNguoiKyVanBanRepository {
    if (!this.beanNguoiKyVanBanDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanNguoiKyVanBanDao;
  }

  public getBeanUserRepository(): BeanUserRepository {
    if (!this.beanUserDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanUserDao;
  }

  public getBeanGroupRepository(): BeanGroupRepository {
    if (!this.beanGroupDao) {
      throw new Error("DbController not initialized. Call initialize() first.");
    }
    return this.beanGroupDao;
  }

  public async deleteAll() {
    this.banlanhDao?.deleteAll();
    this.beanSettingDao?.deleteAll();
    this.beanDepartmentDao?.deleteAll();
    this.beanCoQuanGuiDao?.deleteAll();
    this.beanLoaiVanBanDao?.deleteAll();
    this.beanNguoiKyVanBanDao?.deleteAll();
    this.beanUserDao?.deleteAll();
    this.beanGroupDao?.deleteAll();
  }
}
