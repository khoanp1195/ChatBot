import { MoreInfo } from "./moreInfo";

class BeanNotify {
    ID: string;
    Title: string;
    DocumentID?: number;
    TaskID?: number;
    CategoryText: string;
    Type: boolean; // 0: phối hợp, 1: cần xử lý
    SendUnit: string;
    Priority?: number; // 1: cao, 2: thuong, 3: thap
    Status: number; // 0: chưa hoàn tất, 1: hoàn tất
    Action: string; // remove: loại bỏ
    DueDate?: string; // Change type to string
    Content: string;
    Percent: number;
    Modified?: string; // Change type to string
    Created?: string; // Change type to string
    Read?: boolean;
    TaskCategory: string;
    ModuleId: number;
    SearchData: string;
    IsSelected: boolean; // Dùng để kiểm tra object có được focus hay không
    ImagePath: string;
    IsLoadMore: boolean; // Dùng để LoadMore dữ liệu trên server

    constructor(
        ID: string,
        Title: string,
        CategoryText: string,
        Type: boolean,
        SendUnit: string,
        Status: number,
        Action: string,
        Content: string,
        Percent: number,
        TaskCategory: string,
        ModuleId: number,
        SearchData: string,
        IsSelected: boolean,
        ImagePath: string,
        IsLoadMore: boolean,
        DueDate?: Date,
        Modified?: Date,
        Created?: Date,
        Read?:boolean
    ) {
        this.ID = ID;
        this.Title = Title;
        this.CategoryText = CategoryText;
        this.Type = Type;
        this.SendUnit = SendUnit;
        this.Status = Status;
        this.Action = Action;
        this.DueDate = DueDate ? DueDate.toISOString() : undefined;
        this.Content = Content;
        this.Percent = Percent;
        this.Modified = Modified ? Modified.toISOString() : undefined;
        this.Created = Created ? Created.toISOString() : undefined;
        this.TaskCategory = TaskCategory;
        this.ModuleId = ModuleId;
        this.SearchData = SearchData;
        this.IsSelected = IsSelected;
        this.ImagePath = ImagePath;
        this.IsLoadMore = IsLoadMore;
        this.Read=Read!=null?Read:false;
    }
}

export default BeanNotify;
