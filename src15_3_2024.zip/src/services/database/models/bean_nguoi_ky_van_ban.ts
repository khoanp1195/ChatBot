import { Column, Entity, PrimaryColumn } from "typeorm";
// @ts-ignore
@Entity({name:'BeanNguoiKyVanBan'})
export class BeanNguoiKyVanBan{
  // @ts-ignore
  @PrimaryColumn({type: 'int'})
  public ID:number=0;
  // @ts-ignore
  @Column({type:'text'})
  public Title:string="";
  // @ts-ignore
  @Column({type:'boolean'})
  public IsHidden:boolean=false;
  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.Title = data.Title || '';
      this.IsHidden = data.IsHidden || false;
    }
  }
  static fromJson(json: any): BeanNguoiKyVanBan {
    return new BeanNguoiKyVanBan(json);
  }
  static listFromJson(jsonArray: any[]): BeanNguoiKyVanBan[] {
    return jsonArray.map((item) => new BeanNguoiKyVanBan(item));
  }
}
