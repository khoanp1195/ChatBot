import { Column, Entity } from "typeorm";
import { PrimaryColumn } from "typeorm/browser";

// @ts-ignore
@Entity({ name: "BeanLoaiVanBan" })
export class BeanLoaiVanBan {
  // @ts-ignore
  @PrimaryColumn({ type: "int" })
  public ID: number = 0;
  // @ts-ignore
  @Column({ type: "text" })
  public Title: string = "";
  // @ts-ignore
  @Column({ type: "int" })
  public Orders: number = 0;

  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.Title = data.Title || '';
      this.Orders = data.Orders || 0;
    }
  }
  static fromJson(json: any): BeanLoaiVanBan {
    return new BeanLoaiVanBan(json);
  }
  static listFromJson(jsonArray: any[]): BeanLoaiVanBan[] {
    return jsonArray.map((item) => new BeanLoaiVanBan(item));
  }

}
