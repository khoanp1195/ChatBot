import React, { useEffect, useState } from "react";
import { View, TextInput, StyleSheet, Pressable, FlatList, Keyboard, Text } from "react-native";
import { BtnChooseDate } from "../../components/buttonChooseDateSearchView";
import { BtnDocType } from "../../components/customSearchViewDocTypeBtn";
import { CircleButton } from "../../components/circleButton";
import { BtnChooseEle } from "../../components/buttonChooseSearchElement";
import { useDispatch } from "react-redux";
import { getSearchData } from "../../services/api/api_search.ts";
import { getListItemBackground, isNullOrEmpty, getDisplayTxtFromDateString } from "../../utils/functions.ts";
import { CustomFlatListRefreshLoadMore } from "../../components/custom_flat_list_refresh_loadmore.tsx";
import { CustomCalendarView } from "../../components/customCalendarView.tsx";
import { DbServices } from "../../services/database/db_service.ts";
import { useNavigation } from "@react-navigation/native";
import { format } from "date-fns";
import { showAlert } from "../../screens/commonAlertView.jsx";
import { appMainBlueColor } from "../../utils/color.ts";

export const SearchScreen = () => {

  // const dispatch = useDispatch();
  const navigation = useNavigation();
  const [searchKey, setSearchKey] = useState("");
  const [docTypeID, setDocTypeID] = useState(0);
  const [fromDate, setFromDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth() - 1, new Date().getDate()));
  const [toDate, setToDate] = useState(new Date());

  const [isViewAllElement, setIsViewAllElement] = useState(false);
  const [loaiVB, setLoaiVB] = useState({
    ID: null,
    Title: "Tất cả"
  });

  const [lstLoaiVB, setLstLoaiVB] = useState([{
    ID: "",
    Title: "Tất cả"
  }]);

  const [cQGui, setCQGui] = useState({
    ID: null,
    Title: "Tất cả"
  });
  const [lstCQGui, setLstCQGui] = useState([{
    ID: "",
    Title: "Tất cả"
  }]);
  const [nguoiKy, setNguoiKy] = useState({
    ID: null,
    Title: "Tất cả"
  });
  const [lstNguoiKy, setLstNguoiKy] = useState([{
    ID: "",
    Title: "Tất cả"
  }]);

  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexCalendarSelect, setIndexCalendarSelect] = useState(0);
  const [dataPost, setDataPost] = useState({
    ID: 0,
    Title: null,
    Status: null,
    TrichYeu: null,
    NgayDen: null,
    SoDen: null,
    NgayTrenVB: null,
    CoQuanGui: null,
    ModuleId: 0,
    Created: null,
    TuNgay: "2023-01-26",
    DenNgay: "2023-12-26",
    Content: "",
    LoaiVanBan: null,
    NguoiKyVanBan: null,
    Type: "0",
    ModifiedBy: null,
    IsSelected: false
  });
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    DbServices.getInstance().getBeanLoaiVanBanRepository().findAll().then(value => {
      if (lstLoaiVB.length == 1) {
        // @ts-ignore
        setLstLoaiVB((prevData) => [...prevData, ...value]);
      }
    });
    DbServices.getInstance().getBeanNguoiKyVanBanRepository().findAll().then(value => {
      if (lstNguoiKy.length == 1) {
        // @ts-ignore
        setLstNguoiKy((prevData) => [...prevData, ...value]);
      }
    });
    DbServices.getInstance().getBeanCoQuanGuiRepository().findAll().then(value => {
      if (lstCQGui.length == 1) {
        // @ts-ignore
        setLstCQGui((prevData) => [...prevData, ...value]);
      }
    });

  }, []);

  ///id: 1: Tất cả, 2: VB đến, 3: VB đi/Nội bộ
  const OnClickDocType = (id: number) => {
    if ((docTypeID == 1 && id == 2) || (docTypeID == 2 && id == 1)) {
      setDocTypeID(0);
    } else
      setDocTypeID(id);
    console.log("id", id);
  };

  const OnClickChooseDate = (id: number) => {
    switch (id) {
      case 0:
        console.log("chọn từ ngày nè");
        break;
      case 1:
        console.log("chọn đến ngày nè");
        break;
      default:
        console.log("id tào lao gòi");
        break;
    }
  };

  const OnClickChooseELement = (id: Number) => {
    switch (id) {
      case 0:
        // setFromDate()
        console.log("chọn loại VB nè");
        // @ts-ignore
        navigation.navigate("TypeSelectScreen",
          {
            data: lstLoaiVB,
            title: "Loại văn bản",
            selectedTitle: loaiVB.Title,
            onSelected: (item: any) => {
              setLoaiVB(item);
            }
          });
        break;
      case 1:
        // setToDate()
        console.log("chọn cơ quan gửi nè");
        // @ts-ignore
        navigation.navigate("TypeSelectScreen",
          {
            data: lstCQGui,
            title: "Cơ quan gửi",
            selectedTitle: cQGui.Title,
            onSelected: (item: any) => {
              setCQGui(item);
            }
          });
        break;
      case 2:
        console.log("chọn người ký nè");
        // @ts-ignore
        navigation.navigate("TypeSelectScreen",
          {
            data: lstNguoiKy,
            title: "Người ký văn bản",
            selectedTitle: nguoiKy.Title,
            onSelected: (item: any) => {
              setNguoiKy(item);
            }
          });
        break;
      default:
        console.log("id tào lao gòi");
        break;
    }
  };
  const OnClickExpand = () => {
    setIsViewAllElement(!isViewAllElement);
    console.log(isViewAllElement ? "mở" : "đóng");
  };

  const OnSearchDocument = async (limit: number, ofset: number) => {
    let newData = new FormData();
    newData.append("data", JSON.stringify(dataPost));
    const data = await getSearchData(limit, ofset, newData);
    if (data !== null) {
      return data;
    } else {
      return [];
    }

  };

  //@ts-ignore
  const SearchItem = ({ item, index }) => {
    return (
      <Pressable style={{ flex: 1, padding: 10, backgroundColor: getListItemBackground(index % 2 != 0) }}
        onPress={() => {
          OnClickSearchItem(item);
        }}>
        <View style={{
          flex: 1,
          flexDirection: "row",
          alignItems: "center"
        }}>
          <View style={{ flex: 1 }}>
            <Text>{item.CoQuanGui}</Text>
          </View>
          <View style={{ width: 70 }}>
            <Text style={{ textAlign: "right", fontSize: 13 }}>{getDisplayTxtFromDateString(item.NgayDen)}</Text>
          </View>
        </View>

        <View style={{
          alignSelf: "flex-end",
          marginVertical: 5
        }}>
          <Text style={{ textAlign: "right", color: appMainBlueColor }}>{item.Title}</Text>
        </View>
        <View style={{
          alignSelf: "flex-start",
          marginVertical: 5
        }}>
          <Text>{item.TrichYeu}</Text>
        </View>
        <View>
          <View style={{
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            alignContent: "center"
          }}>
            <View style={{ flex: 1, flexWrap: "wrap" }}>
              {
                (!isNullOrEmpty(item.Status) && item.Status.length != 0) &&
                <Text style={{
                  color: appMainBlueColor,
                  backgroundColor: "#D1E9FF",
                  padding: 5,
                  fontSize: 13
                }}>{item.Status}</Text>
              }
            </View>
            <View style={{ width: 60 }}>
              <Text style={{ textAlign: "right", fontSize: 13, }}>{item.SoDen}</Text>
            </View>
            <View style={{ width: 60 }}>
              <Text style={{ textAlign: "right", fontSize: 13, }}>{getDisplayTxtFromDateString(item.NgayTrenVB)}</Text>
            </View>
          </View>
        </View>
      </Pressable>
    );
  };

  // @ts-ignore
  const OnClickSearchItem = (item) => {
    console.log(item.TrichYeu);
    switch (item.ModuleId) {
      default:
        {
          showAlert("Thao tác không thực hiện được.")
          console.log("ModuleID: " + item.ModuleId)
          break
        }
      case 3://Văn bản đến Tập đoàn
      case 5://Văn bản đến Đơn vị
        {
          //@ts-ignore
          navigation.navigate("VBDenDetailScreen",
            {
              item: {
                ID: item.ID,
                TrichYeu: item.TrichYeu
              },
            });
          break
        }
      case 7://Văn bản đi
        {
          break
        }
      case 6:// Văn bản ban hành Đơn vị
      case 8://Văn bản đi đã ban hành (Văn bản ban hành Tập đoàn)
        {
          break
        }
      case 9://Hồ sơ tài liệu
        {
          break
        }
    }
  };

  return <Pressable style={{ flex: 1, marginBottom: 60 }} onPress={Keyboard.dismiss}>
    <View style={styles.rootContainer}>

      <TextInput
        style={styles.input}
        placeholder="Tìm kiếm..."
        autoCapitalize="none"
        value={searchKey}
        onChangeText={(text) => setSearchKey(text)} />

      <View style={
        {
          flexDirection: "row",
          height: 40
        }}>
        <BtnDocType
          title={"Tất cả VB"}
          onClickHandle={() => {
            OnClickDocType(0);
          }}
          buttonStyle={[docTypeID === 0 ? styles.activeButton : styles.normalButton]}
          textStyle={docTypeID === 0 ? styles.activeButtonText : styles.normalButtonText}
        />
        <BtnDocType
          title={"VB đến"}
          onClickHandle={() => {
            OnClickDocType(1);
          }}
          buttonStyle={[docTypeID === 1 ? styles.activeButton : styles.normalButton]}
          textStyle={docTypeID === 1 ? styles.activeButtonText : styles.normalButtonText}
        />
        <BtnDocType
          title={"VB đi/Nội bộ"}
          onClickHandle={() => {
            OnClickDocType(2);
          }}
          buttonStyle={[docTypeID === 2 ? styles.activeButton : styles.normalButton]}
          textStyle={docTypeID === 2 ? styles.activeButtonText : styles.normalButtonText}
        />
      </View>

      <View style={{
        flexDirection: "row",
        height: 60,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        margin: 5,
        borderColor: "lightgrey"
      }
      }>
        <BtnChooseDate id={0} title={"Từ ngày"} onClickHandle={() => {
          //OnClickChooseDate(0);
          setIndexCalendarSelect(0);
          setIsVisibleCalendar(true);
        }} dateText={fromDate} />
        <BtnChooseDate id={1} title={"Đến ngày"} onClickHandle={() => {
          //OnClickChooseDate(1);
          setIndexCalendarSelect(1);
          setIsVisibleCalendar(true);
        }} dateText={toDate} />
      </View>

      {
        isViewAllElement &&
        <View style={{
          flexDirection: "column",
          height: isViewAllElement ? 150 : 0,
          // flex: 1,
          // flexWrap: 'wrap',
          margin: 5,
          justifyContent: "space-between",
          gap: 5
        }}>
          <BtnChooseEle title={"Loại văn bản"}
            onClickHandle={() => {
              OnClickChooseELement(0);
            }}
            valueText={loaiVB.Title}
            imgPath={require("../../assets/images/icon_expand_contact.png")} />
          <BtnChooseEle title={"Cơ quan gửi"}
            onClickHandle={() => {
              OnClickChooseELement(1);
            }}
            valueText={cQGui.Title}
            imgPath={require("../../assets/images/icon_search26.png")}
            imgColor={"#0072C6"} />
          <BtnChooseEle title={"Người ký"}
            onClickHandle={() => {
              OnClickChooseELement(2);
            }}
            valueText={nguoiKy.Title}
            imgPath={require("../../assets/images/icon_expand_contact.png")} />
        </View>
      }

      <View style={{
        height: 40,
        aspectRatio: 1,
        alignSelf: "flex-end",
        alignContent: "center",
        flexDirection: "row-reverse",
        // margin: 5,
        marginRight: 5,
        padding: 10
      }}>
        <CircleButton
          path={isViewAllElement
            ? require("../../assets/images/icon_expand_up.png")
            : require("../../assets/images/icon_file_expand.png")}
          title=""
          onClick={() => {
            OnClickExpand();
          }}
        />
      </View>

      <View style={{
        height: 40,
        width: 150,
        alignSelf: "flex-end",
        paddingRight: 5
      }}>
        <BtnDocType
          title={"Tìm kiếm"}
          onClickHandle={() => {
            setIsSearching(true);
            const type = docTypeID == 0 && "0" || docTypeID == 1 && "1" || docTypeID == 2 && "2,3" || "0";
            setDataPost({
              ID: 0,
              Title: null,
              Status: null,
              TrichYeu: null,
              NgayDen: null,
              SoDen: null,
              NgayTrenVB: null,
              CoQuanGui: cQGui.ID,
              ModuleId: 0,
              Created: null,
              TuNgay: format(fromDate, "yyyy-MM-dd"),
              DenNgay: format(toDate, "yyyy-MM-dd"),
              Content: searchKey,
              LoaiVanBan: loaiVB.ID,
              NguoiKyVanBan: nguoiKy.ID,
              Type: type,
              ModifiedBy: null,
              IsSelected: false
            });
          }}
          buttonStyle={[styles.activeButton]}
          textStyle={[styles.activeButtonText]}
        />
      </View>

      {<View style={{
        flex: 1
      }}>
        {/* <FlatList
          data={data}
          renderItem={({ item, index }) =>
            <SearchItem item={item} index={index} />
          }
          // @ts-ignore
          keyExtractor={(item, index) => index}
        /> */}
        {
          isSearching && <CustomFlatListRefreshLoadMore
            key={JSON.stringify(dataPost)}
            enableMoreData={true}
            numColumn={1}
            limit={20}
            callData={OnSearchDocument}
            ItemRenderFlatlist={SearchItem} />
        }
      </View>
      }
    </View>
    {isVisibleCalendar &&
      <View style={{ height: "100%", width: "100%", position: 'absolute' }}>
        <CustomCalendarView
          dateFocus={indexCalendarSelect == 0?fromDate:toDate}
          onTouchOutSite={() => setIsVisibleCalendar(!isVisibleCalendar)}
          onPressDate={(date: { year: number; month: number; day: number | undefined; } | undefined) => {
            if (date != undefined) {
              if (indexCalendarSelect == 0) {
                setFromDate(new Date(date.year, date.month - 1, date.day));
              } else {
                setToDate(new Date(date.year, date.month - 1, date.day));
              }
            }
            setIsVisibleCalendar(false);
          }}
        />
      </View>}
  </Pressable>;
};

const styles = StyleSheet.create({
  rootContainer: {
    height: "100%",
    backgroundColor: "white"
  },
  input: {
    height: 40,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    borderWidth: 1,
    borderRadius: 6,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    backgroundColor: "#f5f5f5",
    borderColor: "lightgrey",
    fontSize: 14,
    marginVertical: 10
  },
  normalButton: {
    backgroundColor: "#f5f5f5"
  },
  activeButton: {
    backgroundColor: "#0072C6"
  },
  normalButtonText: {
    color: "black"
  },
  activeButtonText: {
    color: "white"
  },
  imgExpand: {
    padding: 10
  }
});
