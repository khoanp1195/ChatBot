import React, { useState } from 'react';
import { Image, Text, TouchableOpacity, View, StyleSheet, Alert } from 'react-native';
import { useDispatch } from "react-redux";
import {
  redirectLichChoDuyet,
  redirectLichChoXepPhong,
  redirectLichDuKien, redirectLichTatCa,
  redirectParentView
} from "../../stores/base_screen/actions.ts";
import { DrawerActions, useNavigation } from "@react-navigation/native";

export const LeftMenuCalendarScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [id, setID] = useState(null);

  const data = [
    {
      ID: 0,
      Title: 'ĐẶT LỊCH HỌP',
      Icon: require('../../assets/images/icon_parent_calendar.png'),
      IsParent: true,
      EnableClick: false,
    },
    {
      ID: 1,
      Title: 'Đăng ký',
      Icon: require('../../assets/images/icon_add_calendar.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 2,
      Title: 'Lịch chờ duyệt',
      Icon: require('../../assets/images/icon_wait_to_approve.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 3,
      Title: 'Lịch họp chờ xếp phòng',
      Icon: require('../../assets/images/icon_wait_room_calendar.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 4,
      Title: 'Lịch công tác tuần',
      Icon: require('../../assets/images/icon_weekly_calendar.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 5,
      Title: 'Lịch dự kiến',
      Icon: require('../../assets/images/icon_history.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 6,
      Title: 'Tình trạng phòng họp',
      Icon: require('../../assets/images/icon_status_room.png'),
      IsParent: false,
      EnableClick: true,
    },
    {
      ID: 7,
      Title: 'Tất cả',
      Icon: require('../../assets/images/icon_all_calendar.png'),
      IsParent: false,
      EnableClick: true,
    },
  ];
  const redirect = (title: string) => {
    switch (title) {
      case 'Tình trạng phòng họp':
        // @ts-ignore
        navigation.navigate("DetailCalendarScreen", {
          item: [],
          url: "MeetingRoomStatus.aspx",
        
        });
        break;
      case 'Đăng ký':
        // @ts-ignore
        navigation.navigate("DetailCalendarScreen", {
          item: [],
          url: "meetingbooking_form.aspx?"
        });
        break;
      case 'Lịch dự kiến':
        dispatch(redirectLichDuKien());
        break;
      case 'Lịch chờ duyệt':
        dispatch(redirectLichChoDuyet());
        break;
      case 'Lịch họp chờ xếp phòng':
        dispatch(redirectLichChoXepPhong());
        break;
      case 'Lịch công tác tuần':
        dispatch(redirectParentView());
        break;
      case 'Tất cả':
        dispatch(redirectLichTatCa());
        break;
    }
    navigation.dispatch(DrawerActions.closeDrawer());

  }

  return (
    <View style={styles.container}>
      {data.map((item) => (
        <TouchableOpacity key={item.ID} onPress={() => {
          if (item.EnableClick) {
            // @ts-ignore
            setID(item.ID);
            redirect(item.Title);
          }
        }}>
          <View style={styles.rowContainer}>
            <View style={[styles.indicator, { backgroundColor: id === item.ID ? '#0072C6' : 'white' },
            (id !== item.ID && item.IsParent) && { backgroundColor: '#F5F5F5CC' }]} />
            <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? '#E6F5FF80' : 'white' },
            (id !== item.ID && item.IsParent) && { backgroundColor: '#F5F5F5CC' }]}>
              <Image source={item.Icon} style={styles.icon} />
              <Text style={[styles.title, item.IsParent && { fontWeight: 'bold' }]}>{item.Title}</Text>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
  },
  rowContainer: {
    flexDirection: 'row',
  },
  indicator: {
    width: 10,
    height: 50,
  },
  itemContainer: {
    flexDirection: 'row',
    width: '96%',
    padding: 10,
    alignItems: 'center',
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10,
  },
  title: {
    color: '#000000',
  },
});
