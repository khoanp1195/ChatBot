import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { getHSTL } from "../../../services/api/api_doc.ts";
import { CustomFlatListRefreshLoadMore } from "../../../components/custom_flat_list_refresh_loadmore.tsx";
import { useNavigation } from "@react-navigation/native";
import { gotoDetailDocs } from "../../../screens/details/docs/detail_doc_handler.ts";
import { convertStringToMoment, isNullOrEmpty, removeSignVietnamese } from "../../../utils/functions.ts";
import { PetroAppBarCustom } from "../../../components/petro_appbar_custom.tsx";
import { BeanHSLT } from "../../../services/database/models/beanHSLT.ts";

// @ts-ignore
export const HSTLScreen = ({ menuId }) => {
  const navigation = useNavigation();
  const [title, setTitle] = useState("");
  const [keySearch, setKeySearch] = useState("");
  useEffect(() => {
    switch (menuId) {
      case 0:
        setTitle("HSLT Tất cả");
        break;
      case 1:
        setTitle("HSLT của tôi");
        break;
    }
  }, []);
  const getData = async () => {
    const data = await getHSTL(menuId);
    if (data != null) {
      if(isNullOrEmpty(keySearch))
        return data;
      else
        return data.filter((item:BeanHSLT )=>
          removeSignVietnamese(item.MaHoSo).toLowerCase().includes(removeSignVietnamese(keySearch).toLowerCase())||
          removeSignVietnamese(item.TenHoSo).toLowerCase().includes(removeSignVietnamese(keySearch).toLowerCase())||
          removeSignVietnamese(item.NoiDung).toLowerCase().includes(removeSignVietnamese(keySearch).toLowerCase())||
          removeSignVietnamese(item.ModifiedByText).toLowerCase().includes(removeSignVietnamese(keySearch).toLowerCase())
        );
    } else {
      return [];
    }
  };

  // @ts-ignore
  const item = ({ item, index }) => {
    const [read,setRead]=useState<boolean>(item.Read);
    return (
      <TouchableOpacity onPress={() => {
        setRead(true);
        // @ts-ignore
        navigation.navigate("DetailHSTLScreen", {item});
      }}>
        <View style={[styles.itemContainer, { backgroundColor: index % 2 == 0 ? "white" : "#F3F9FF" }]}>
          <View style={styles.rowContainer}>
            <View style={styles.detailsContainer}>
              <View style={styles.rowContainer}>
                <Text style={styles.senderText}>{item.MaHoSo}</Text>
                <Text style={styles.dateText}>
                  {convertStringToMoment(item.Created).format("DD/MM/YYYY")}
                </Text>
              </View>
            </View>
          </View>
          <Text
            numberOfLines={2}
            style={[
              styles.titleText,
              {
                fontWeight: read ? "400" : "bold"
              }
            ]}
          >
            {item.TenHoSo}
          </Text>
          <View style={styles.rowContainer}>
            <View style={styles.actionContainer}>
              <View style={styles.actionBox}>
                <Text style={styles.actionText}>{item.StatusText}</Text>
              </View>
            </View>
            <Text style={styles.dueDateText}>
              {item.ModifiedByText}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  useEffect(() => {
    setTimeout(() => {
      getData();
    }, 500);
  }, [menuId]);

  return (
    <View style={{ marginBottom: 200 }}>
      <PetroAppBarCustom
        title={title}
        onPress={() => {
          // @ts-ignore
          navigation.openDrawer();
        }} />
      <TextInput
        style={{paddingHorizontal:10,height:'7%'}}
        value={keySearch}
        placeholder={'Mã hồ sơ, tên hồ sơ, nội dung'}
        onChangeText={text => {
          setKeySearch(text);
        }}
      />
      <CustomFlatListRefreshLoadMore key={menuId+keySearch} ItemRenderFlatlist={item} limit={10} callData={getData}
                                     enableMoreData={true} numColumn={1} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white"
  },
  statusContainer: {
    height: 30,
    width: "60%",
    backgroundColor: "#0072C6",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#0072C6",
    flexDirection: "row",
    justifyContent: "center",
    bottom: 0,
    margin: 10
  },
  inactiveLanguage: {
    flex: 1,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0072C6"
  },
  activeLanguage: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center"
  },
  itemContainer: {
    padding: 10
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%"
  },
  avatar: {
    height: 35,
    width: 35
  },
  detailsContainer: {
    width: "100%"
  },
  senderText: {
    color: "#19191E",
    fontSize: 15,
    fontWeight: "400",
    textAlign: "left",
    width: "52%"
  },
  dateText: {
    color: "#5E5E5E",
    fontSize: 12,
    fontWeight: "400",
    textAlign: "right",
    width: "48%"
  },
  categoryText: {
    width: "40%",
    color: "#5E5E5E",
    fontSize: 12
  },
  taskCategoryText: {
    width: "50%",
    textAlign: "right",
    color: "#5E5E5E",
    fontSize: 12
  },
  titleText: {
    width: "100%",
    color: "#000000",
    fontSize: 15,
    paddingVertical: 10
  },
  actionContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "50%"
  },
  actionBox: {
    backgroundColor: "#D1E9FF",
    padding: 5,
    borderRadius: 5
  },
  actionText: {
    color: "#0072C6",
    fontSize: 12
  },
  priorityBox: {
    width: 25,
    height: 25,
    marginLeft: 5,
    backgroundColor: "red"
  },
  dueDateText: {
    width: "50%",
    textAlign: "right"
  },
  languageTextUnActive: {
    color: "white"
  },
  languageTextActive: {
    color: "#0072C6"
  }
});
