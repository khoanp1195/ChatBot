import { FlatList, Image, Text, TouchableOpacity, View, StyleSheet, Alert, Pressable, LogBox, Linking } from "react-native";
import ReactNativeCalendarStrip from "react-native-calendar-strip";
import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
import { showLeftMenuCalendar, showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import React, { memo, useCallback, useEffect, useMemo, useState } from "react";
import BaseScreen from "../../components/basescreen.tsx";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import { formatDate, formatDateNum, formatDateToVietnamese, getDisplayTxtFromDateString, getDisplayTxtFromHourString, getStartOfWeek, getWeekOfYear, isNullOrEmpty } from "../../utils/functions.ts";
import moment, { isDate } from "moment";
import { appMainBlueColor } from "../../utils/color.ts";
import { getListDonVi, getMeetingCalendars } from "../../services/api/api_calendar.ts";
import Empty_view from "../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { formatParticipantsDetail } from '../../utils/functions'
import { subsiteStore } from "../../config/constants.ts";
import * as Animatable from 'react-native-animatable'

export const CalendarScreen = () => {
  moment.locale("en");
  const dispatch = useDispatch();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
  const [donvi, setDonVi] = useState();
  const [lichhHop, setlichhHop] = useState([])
  const [lichtuan, setLichTuan] = useState([])
  const [firstDayofWeek, setfirstDayofWeek] = useState(new Date());
  const [lastDayOfWeek, setlastDayOfWeek] = useState(new Date())
  const [uniTitle, setUnitTitle] = useState("")
  const [siteConnection, setSiteConnection] = useState("")
  const [keyConnection, setKeyConnection] = useState("")
  const itemUnitSelected = useSelector((state: any) => state.lichtuan);
  const [isFirst, setIsFirst] = useState(true)
  const [flag, setFlag] = useState(1)
  const [isShowMonthCalendar, setIsShowMonthCalendar] = useState(false);
  const [dictLichhop, setdictLichhop] = useState({})
  const [isWeekView, setisWeekView] = useState(false)
  const [weeknum, setweeknum] = useState("")
  const [week, setweek] = useState(Number)
  const [dotCalendar, setdotCalendar] = useState([])
  const [isPreDate, setisPreDate] = useState(false)
  const [dateWeekLoad, setdateWeekLoad] = useState(new Date())
  const [isChangeUnit, setisChangeUnit] = useState(false)
  const datesBlacklistFunc = (date: { isoWeekday: () => number; }) => {
    return date.isoWeekday() === 6 || date.isoWeekday() === 7; // disable Saturdays
  };
  const tabs = [
    { title: "Lịch lãnh đạo" },
    { title: "Lịch ban" },
    { title: "Lịch của tôi" }
  ];

  const [indexTab, setIndexTab] = useState(0);
  const [isFullWeek, setIsFullWeek] = useState(false);

  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const getColorByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case 1:
          return "#FFF2EA"
        case 4:
          return '#A7FFA5'
        case 2:
          return '#ACB0EE';
        case 5:
          return '#FFF0F0';
        case 3:
          return '#FFFAEC';
        default:
          return '#E7F8FF';
      }
    }
    const getColorBorderByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case 1:
          return "#FF9E5E"
        case 4:
          return '#A7FFA5'
        case 2:
          return '#ACB0EE';
        case 5:
          return '#FF8685';
        case 3:
          return '#FFD770';
        default:
          return '#8ECFFF';
      }
    }

    const getStatusItem = (StatusItem: any) => {
      switch (StatusItem) {
        case 1:
          return "Bổ sung"
        case 2:
          return "Điều chỉnh";
        case 3:
          return "Hoãn";
        case 4:
          return "Dự kiến";
        case 5:
          return "Hủy";
        default:
          return '';
      }
    }

    const getParticipant = () => {
      var dataTxt = item.ParticipantsDetail
      var tPKhacTxt = item.AdditionIngredients ? item.AdditionIngredients : "";
      var tPCTXDTxt = item.OtherParticipants ? item.OtherParticipants : "";
      tPKhacTxt = tPKhacTxt.replace(/\n/g, ";$");
      var decodedDataTxt = decodeURIComponent(dataTxt);
      var dataToShow = decodedDataTxt + (tPKhacTxt || tPCTXDTxt ? "#Thành phần tại đơn vị;$" + tPCTXDTxt + ";$" + tPKhacTxt : "");
      return dataToShow
    }

    const ParticipantTxt = () => {
      let dataTxt = item.ParticipantsDetail || "";
      if (item.OtherParticipants || item.AdditionIngredients) {
        dataTxt += (dataTxt ? "#" : "") + "Thành phần tại đơn vị";
      }
      let data = decodeURIComponent(dataTxt);
      return formatParticipantsDetail(data)
    }

    const OpenMeetingLink = (item: any) => {
      if (item.IsView === 1) {
        Linking.canOpenURL(item.MeetingLink).then(supported => {
          if (!supported) {
            Alert.alert(
              'Thông báo',
              'Bạn chưa có phần mềm họp, vui lòng tải để sử dụng.',
            );
            return;
          } else {
            Linking.openURL(item.MeetingLink);
          }
        });
      } else {
        Alert.alert(
          'Thông báo',
          'Bạn không có quyền vào link này',
          [
            {
              text: 'Đóng',
              onPress: () => {
              },
            },
          ],
        );
      }
    }

    return <Pressable onPress={() => {
      // @ts-ignore
      navigation.navigate("DetailCalendarScreen", {
        item: item
      });
    }}
      style={{
        borderWidth: 1.5,
        borderRadius: 10,
        flexDirection: "row",
        alignItems: "center",
        alignContent: "center",
        justifyContent: "center",
        marginTop: 10,
        borderColor: getColorBorderByAppStatus(item.StatusItem)
      }}>
      <View style={{
        padding: 10,
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
        flexDirection: "column",
        flex: 3,
        height: "100%",
        backgroundColor: getColorByAppStatus(item.StatusItem),
        alignItems: "center"
      }}>

        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.StartTime)}</Text>
          <Text> - </Text>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.EndTime)}</Text>
        </View>

        <View style={{
          width: "100%",
          alignItems: "center"
        }}>
          <View style={{ justifyContent: 'center', display: item.StatusItem ? 'flex' : 'none', backgroundColor: getColorBorderByAppStatus(item.StatusItem), height: 20, width: 60, borderRadius: 7, marginTop: '6%' }}>
            <Text style={{ alignSelf: 'center' }}>{getStatusItem(item.StatusItem)}</Text>
          </View>
        </View>
        <TouchableOpacity style={{ marginTop: '15%' }} onPress={() => {
          Alert.alert('Địa điểm phòng họp', item.LocationTitle, [
            { text: 'OK', onPress: () => console.log('OK Pressed') },
          ]);
        }}>
          <Text numberOfLines={2} style={{ marginTop: '15%', textAlign: 'center' }}>{item.LocationTitle}</Text>
        </TouchableOpacity>
        {
          item.MeetingLink != "" ? (
            <View style={{ flexDirection: "row", marginTop: '45%' }}>
              <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
                source={require("../../assets/images/icon_meeting_call.png")} />
              <TouchableOpacity onPress={() => {
                OpenMeetingLink(item)
              }}>
                <Text style={{ marginLeft: '5%' }}>Vào link họp</Text>
              </TouchableOpacity>
            </View>) : <View></View>
        }
      </View>

      <View style={{
        flexDirection: "column",
        flex: 7,
        height: "100%",
        padding: 10,
        backgroundColor: "white",
        borderTopRightRadius: 9,
        borderBottomRightRadius: 9
      }}>
        <Text numberOfLines={2}>{item?.Title}</Text>
        <View style={{
          width: "100%",
          height: 1,
          borderWidth: 0.5,
          marginTop: '3%',
          borderColor: "#474747",
          borderStyle: "dashed"

        }} />
        <View style={{ flexDirection: "column", marginTop: 20 }}>
          <View style={{ flexDirection: "row", marginBottom: 10 }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_user_calendar.png")} />
            <Text style={{ marginLeft: '4%' }}>{item.HostTitle}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
              source={require("../../assets/images/icon_group_calendar.png")} />
            <TouchableOpacity onPress={() => {
              OnClickParticipant(getParticipant())
            }} style={{ width: '80%', marginLeft: '4%' }}>
              <Text>{(ParticipantTxt())}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Pressable>;


  };


  useEffect(() => {
    const fetchData = async () => {
      if (isFirst) {
        try {
          loadMyCalendar();
          const data = await getListDonVi();
          setIsFirst(false);

          if (data && data.length > 0) {
            const matchDepartment = data.find(d => subsiteStore.getSubsite() === (d.SiteConnection === 'Protal' ? "" : d.SiteConnection));
            const unitTitle = matchDepartment ? matchDepartment.Title : data[0].Title;
            const siteConnection = matchDepartment ? matchDepartment.SiteConnection : subsiteStore.getSubsite();

            setDonVi(data);
            setUnitTitle(unitTitle);
            setSiteConnection(siteConnection);
            calculateWeekBounds();

            const dataFirstLich = await loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 2, siteConnection);
            if (dataFirstLich) {
              setlichhHop(dataFirstLich);
            }
          } else {
            setUnitTitle("Tập đoàn xăng dầu Việt Nam");
            setSiteConnection("portal");
            setKeyConnection("portal");
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      } else {
        if (!isWeekView) {
          setUnitTitle(uniTitle);
          try {
            const dataLichHop = await loadListCalendarByWeek(selectedDate, selectedDate, flag, siteConnection);
            if (dataLichHop) {
              setlichhHop(dataLichHop);
            }
          } catch (error) {
            console.error("Error fetching data:", error);
          }
        }
      }
      LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
    };

    fetchData();
  }, [uniTitle, selectedDate, indexTab, dateWeekLoad]);

  useEffect(() => {
    if (isChangeUnit) {
      loadMyCalendar();
    }
  }, [isChangeUnit]);

  useEffect(() => {
    if (isWeekView) {
      LoadListCalendarByWeek(dateWeekLoad)
    }
    // setdateWeekLoad(!isPreDate ? new Date() : dateWeekLoad);
  }, [isWeekView, keyConnection, siteConnection, indexTab]);



  const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag: number, SiteConnection: any) => {
    const data = await getMeetingCalendars(fromDate, toDate, flag, SiteConnection);
    if (data != null) {
      return data;
    } else {
      return [];
    }
  };


  const OnClickUnit = (item: any) => {
    // @ts-ignore
    navigation.navigate("Calendar_unit", {
      item: donvi, title: uniTitle, flag: getFlag(indexTab),
      onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
        setUnitTitle(title)
        setisChangeUnit(true)
        setSiteConnection(SiteConnection)
        setKeyConnection(KeyConnection)
        setFlag(flag)
        console.log("KeyConnection - here " + KeyConnection)
      }
    })
  };

  const OnClickParticipant = (item: any) => {
    // @ts-ignore
    navigation.navigate("Participant_Screen", { item: item })
  };

  const onDateChanged = (date: any) => {
    setFlag(getFlag(indexTab) || 0)
    setIndexTab(0)
    setSelectedDate(date)
    setdateWeekLoad(date)
  };

  const changeTab = (index: any) => {
    setFlag(getFlag(index) || 0)
  }

  const LoadListCalendarByWeek = (date: any) => {
    const dateObject = new Date(date)
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate())
    lastDay.setDate(firstDay.getDate() + 6);
    let flagWeek = getFlag(indexTab) || 0
    setweek(getWeekOfYear(date));
    setweeknum(`(${formatDateNum(firstDay)} - ${formatDateNum(lastDay)})`);
    loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), flagWeek, siteConnection)
      .then(dataFirstLich => {
        if (dataFirstLich != null) {
          setLichTuan(dataFirstLich);
          const tempDict: Record<string, any[]> = {}
          dataFirstLich.forEach((item: { StartTime: string | number | Date; }) => {
            if (item.StartTime) {
              const key = formatDateToVietnamese(new Date(item.StartTime));
              tempDict[key] = tempDict[key] ? [...tempDict[key], item] : [item];
            }
          });
          setdictLichhop(tempDict);
        }
      });
  }

  const loadMyCalendar = () => {
    const dateObject = new Date(selectedDate);
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate() - 20)
    lastDay.setDate(firstDay.getDate() + 10);
    loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, siteConnection)
      .then(dataMyCalendar => {
        if (dataMyCalendar) {
          const tempDict = dataMyCalendar.reduce((acc: { [x: string]: any; }, item: { StartTime: moment.MomentInput; }) => {
            if (item.StartTime) {
              const key = moment(item.StartTime).format("YYYY-MM-DD");
              acc[key] = acc[key] ? [...acc[key], item] : [item];
            }
            return acc;
          }, {});
          const propertiesToAssign = {
            textColor: 'green',
            color: 'green',
            dotColor: 'red',
            marked: true
          };
          const markedDates = Object.keys(tempDict).reduce((acc, date) => {
            acc[date] = { ...propertiesToAssign };
            return acc;
          }, {});
          setdotCalendar(markedDates);
          setisChangeUnit(false)
        } else {
          console.error('No calendar data available');
        }
      })
      .catch(error => {
        console.error('Error loading calendar:', error);
      });
  };

  const calculateWeekBounds = () => {
    const firstDay = getStartOfWeek();
    const lastDay = new Date(firstDay);
    lastDay.setDate(firstDay.getDate() + 6);
    setfirstDayofWeek(firstDay);
    setlastDayOfWeek(lastDay);
  };

  const getFlag = (index: number) => {
    switch (index) {
      case 0:
        return 2
      case 1:
        return 1;
      case 2:
        return 3;
    }
  }

  const loadWeekCalendar = useCallback(() => {
    setIsFullWeek(!isFullWeek);
    setisWeekView(!isWeekView)
  }, [isWeekView, isFullWeek])


  const Btn_prevWeek_Click = () => {
    try {
      dateWeekLoad.setDate(dateWeekLoad.getDate() - 7)
      LoadListCalendarByWeek(dateWeekLoad)
    } catch (error) {
      console.log('Btn_prevWeek_Click - error: ' + error)
    }
  }

  const Btn_nextWeek_Click = () => {
    try
    {
      dateWeekLoad.setDate(dateWeekLoad.getDate() + 7)
      LoadListCalendarByWeek(dateWeekLoad)
      
    }catch(error)
    {
      console.log('Btn_nextWeek_Click - error: ' + error)
    }
 
  }



  LocaleConfig.locales["vn"] = {
    monthNames: [
      "Tháng 1",
      "Tháng 2",
      "Tháng 3",
      "Tháng 4",
      "Tháng 5",
      "Tháng 6",
      "Tháng 7",
      "Tháng 8",
      "Tháng 9",
      "Tháng 10",
      "Tháng 11",
      "Tháng 12"
    ],
    monthNamesShort: [
      "Th 1",
      "Th 2",
      "Th 3",
      "Th 4",
      "Th 5",
      "Th 6",
      "Th 7",
      "Th 8",
      "Th 9",
      "Th 10",
      "Th 11",
      "Th 12"
    ],
    dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
  };
  LocaleConfig.defaultLocale = "vn";

  function startOfWeek(dt: string | number | Date, startOfWeek = 1) {
    const diff = (7 + (dt.getDay() - startOfWeek)) % 7;
    const newDate = new Date(dt);
    newDate.setDate(dt.getDate() - diff);
    newDate.setHours(0, 0, 0, 0);
    return newDate;
  }

  return (
    <BaseScreen>
      {
        <View style={{ height: "100%", backgroundColor: "white" }}>

          <PetroAppBarCustom
            title={"Lịch tuần"}
            rightAction={
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={() => {
                  setIsShowMonthCalendar(!isShowMonthCalendar)
                }}>
                  <Text style={{ marginRight: 15, marginTop: '7%', color: '#0072C6', fontWeight: '600' }}>{getDisplayTxtFromDateString(selectedDate)}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => {
                  loadWeekCalendar()
                }}>
                  <Image style={{ height: 25, width: 25 }} source={
                    !isFullWeek ?
                      require("../../assets/images/icon_change_type_date.png") :
                      require("../../assets/images/icon_change_type_week.png")
                  } />
                </TouchableOpacity>
              </View>
            }
            onPress={() => {
              dispatch(showLeftMenuCalendar());
              // @ts-ignore
              navigation.openDrawer();
            }} />

          <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

          <TouchableOpacity
            style={{
              paddingVertical: 15,
              paddingHorizontal: 15, flexDirection: "row", backgroundColor: "white"
            }}
            onPress={(item) => {
              OnClickUnit(item);
            }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
              source={require("../../assets/images/icon_focus_contact.png")} />
            <Text style={{ color: "black", fontWeight: "bold", fontSize: 15, width: '95%', backgroundColor: "white" }}>{uniTitle}</Text>
          </TouchableOpacity>

          <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />


          <View style={{ height: 80, backgroundColor: "cyan" }}>
            {
              isWeekView ? (
                <View>
                  <View style={{ width: '100%', height: 80, backgroundColor: '#FAFAFA', flexDirection: 'row' }}>
                    <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
                      onPress={() => {
                        Btn_prevWeek_Click()
                        setisPreDate(
                          !isPreDate)
                      }}
                    >
                      <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                        source={require("../../assets/images/icon_preWeek.png")} />
                    </TouchableOpacity>
                    <View style={{ width: '70%', justifyContent: 'center', flexDirection: 'row' }}>
                      <Text style={{ marginRight: '2%', alignSelf: 'center', fontSize: 16, fontWeight: '600' }}>Tuần {week}</Text>
                      <Text numberOfLines={1} style={{ alignSelf: 'center', fontSize: 16 }}>
                        {weeknum}
                      </Text>
                    </View>
                    <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
                      onPress={() => {
                        Btn_nextWeek_Click()
                      }}
                    >
                      <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                        source={require("../../assets/images/icon_nextWeek.png")} />
                    </TouchableOpacity>
                  </View>
                </View>
              ) :
                (
                  null
                )
            }
            <CalendarProvider
              date={selectedDate} // date={"2024-01-01"}
              //@ts-ignore
              onDateChanged={(date) => { onDateChanged(date) }}
              disabledOpacity={1}
              showTodayButton={false}
              markedDates={dotCalendar}
            >
              <WeekCalendar testID={'weekCalendar'}
                firstDay={1}
                theme={{
                  backgroundColor: '#F3F9FF',
                  calendarBackground: '#F3F9FF',//#ffffff
                  textSectionTitleColor: 'black',
                  selectedDayBackgroundColor: appMainBlueColor,//'#00adf5'
                  selectedDayTextColor: '#ffffff',
                  todayTextColor: appMainBlueColor,// '#00adf5'
                  dayTextColor: 'black',
                }}
                disableOnPageChange={true}
                markedDates={dotCalendar}
              />

            </CalendarProvider>

          </View>

          <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

          {/* <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} /> */}
          <Tab
            value={indexTab}
            onChange={(index) => {
              setIndexTab(index);
              // setFlag(index)
              console.log("Index here " + index)
              changeTab(index)
            }}
            indicatorStyle={{ backgroundColor: "#0072C6", height: 3, borderRadius: 100, marginHorizontal: 4 }}
          >
            {tabs.map((tab, index) => (
              <Tab.Item key={index} title={tab.title} containerStyle={{ backgroundColor: "white" }} titleStyle={{
                fontSize: 12,
                color: "#000000",
                height: 30,
                width: '100%'
              }} />
            ))}
          </Tab>
          {/* <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA", marginTop: 5 }} /> */}

          {
            isShowMonthCalendar ? (
              <Animatable.View
                animation={"fadeInDown"}
                duration={500}
                delay={0.2 * 300}
                style={{
                  height: "55%",
                  marginTop: '-50%',
                  zIndex: 99,
                  width: '97%',
                  alignSelf: 'center',
                  backgroundColor: 'transparent',
                  borderRadius: 10,

                }}
              >

                <View >


                  <Calendar
                    date={selectedDate}
                    onDayPress={day => {
                      setSelectedDate(day.dateString);
                      setIsShowMonthCalendar(false)
                      onDateChanged(day.dateString)
                      setisWeekView(false)
                    }}
                    markedDates={dotCalendar}
                    theme={{
                      backgroundColor: '#F3F9FF',
                      calendarBackground: '#F3F9FF',
                      textSectionTitleColor: '#b6c1cd',
                      selectedDayBackgroundColor: '#00adf5',
                      selectedDayTextColor: '#ffffff',
                      todayTextColor: '#0A78C8',
                      dayTextColor: '#2d4150',
                      textDayHeaderFontWeight: '600',
                    }}
                    style={{
                      borderColor: 'gray',
                      height: '100%',
                      borderRadius: 15,
                      marginTop: '6%',
                      shadowColor: 'lughtgray',
                      shadowOffset: { width: 0, height: 2 },
                      shadowOpacity: 0.2,
                      shadowRadius: 4,
                    }}
                  />
                </View>

              </Animatable.View>
            ) : null
          }


          <ScrollView style={{ alignContent: 'center' }} >
            {
              isWeekView && dictLichhop != undefined && Object.keys(dictLichhop).length > 0 ? (
                <FlatList
                  style={{ padding: 10 }}
                  data={Object.keys(dictLichhop)}
                  renderItem={({ item }) => (
                    <View>
                      <View style={styles.headerWeekCalendar}>
                        <Image style={{ height: 20, width: 20, marginRight: 10 }}
                          source={require("../../assets/images/icon_week_header.png")} />

                        <Text style={{ alignSelf: 'center', fontWeight: '600', color: '#0072C6' }}>{item}</Text></View>
                      <FlatList
                        style={{ marginTop: '2%' }}
                        data={dictLichhop[item]}
                        renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
                        keyExtractor={(item, index) => index.toString()}
                      />
                    </View>
                  )}
                  keyExtractor={(item, index) => index.toString()}
                />
              ) : isWeekView ? (<View style={styles.viewNoData}>
                <Text style={styles.textNoData}>Không có dữ liệu</Text>
              </View>) : null
            }
            {lichhHop != undefined && lichhHop.length > 0 && !isWeekView ? (
              <FlatList
                data={lichhHop}
                renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
                keyExtractor={item => item.id}
                scrollEnabled={false}
                style={{ padding: 10 }}
              />
            ) : !isWeekView ? (
              <View style={styles.viewNoData}>
                <Text style={styles.textNoData}>Không có dữ liệu</Text>
              </View>) : null}
          </ScrollView>
        </View>
      }
    </BaseScreen>
  );
};
const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    marginTop: '50%',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#5E5E5E',
    fontStyle: 'italic'
  },
  headerWeekCalendar: {
    backgroundColor: '#E7F5FF',
    height: 40,
    width: '60%',
    justifyContent: "center",
    flexDirection: 'row',
    borderRadius: 14,
    alignItems: 'center',
    marginTop: '2%'
  },
  absolute: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});






// import { FlatList, Image, Text, TouchableOpacity, View, StyleSheet, Alert, Pressable, LogBox, Linking } from "react-native";
// import ReactNativeCalendarStrip from "react-native-calendar-strip";
// import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
// import { showLeftMenuCalendar, showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
// import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigation } from "@react-navigation/native";
// import { Tab } from "react-native-elements";
// import React, { memo, useCallback, useEffect, useMemo, useState } from "react";
// import BaseScreen from "../../components/basescreen.tsx";
// import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
// import { formatDate, formatDateNum, formatDateToVietnamese, getDisplayTxtFromDateString, getDisplayTxtFromHourString, getStartOfWeek, getWeekOfYear, isNullOrEmpty } from "../../utils/functions.ts";
// import moment, { isDate } from "moment";
// import { appMainBlueColor } from "../../utils/color.ts";
// import { getListDonVi, getMeetingCalendars } from "../../services/api/api_calendar.ts";
// import Empty_view from "../../components/empty_view.tsx";
// import { ScrollView } from "react-native-gesture-handler";
// import { formatParticipantsDetail } from '../../utils/functions'
// import { subsiteStore } from "../../config/constants.ts";

// export const CalendarScreen = () => {
//   moment.locale("en");
//   const dispatch = useDispatch();
//   const onLoading = useSelector((state: any) => state.loading.onLoading);
//   const navigation = useNavigation();
//   const [selectedDate, setSelectedDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
//   const [donvi, setDonVi] = useState();
//   const [lichhHop, setlichhHop] = useState([])
//   const [lichtuan, setLichTuan] = useState([])
//   const [firstDayofWeek, setfirstDayofWeek] = useState(new Date());
//   const [lastDayOfWeek, setlastDayOfWeek] = useState(new Date())
//   const [uniTitle, setUnitTitle] = useState("")
//   const [siteConnection, setSiteConnection] = useState("")
//   const [keyConnection, setKeyConnection] = useState("")
//   const itemUnitSelected = useSelector((state: any) => state.lichtuan);
//   const [isFirst, setIsFirst] = useState(true)
//   const [flag, setFlag] = useState(1)
//   const [isShowMonthCalendar, setIsShowMonthCalendar] = useState(false);
//   const [dictLichhop, setdictLichhop] = useState({})
//   const [isWeekView, setisWeekView] = useState(false)
//   const [weeknum, setweeknum] = useState("")
//   const [week, setweek] = useState(Number)
//   const [dotCalendar, setdotCalendar] = useState([])
//   const [isPreDate, setisPreDate] = useState(false)
//   const [dateWeekLoad, setdateWeekLoad] = useState(new Date())

//   const datesBlacklistFunc = (date: { isoWeekday: () => number; }) => {
//     return date.isoWeekday() === 6 || date.isoWeekday() === 7; // disable Saturdays
//   };
//   const tabs = [
//     { title: "Lịch lãnh đạo" },
//     { title: "Lịch ban" },
//     { title: "Lịch của tôi" }
//   ];

//   const [indexTab, setIndexTab] = useState(0);
//   const [isFullWeek, setIsFullWeek] = useState(false);

//   // @ts-ignore
//   const RenderItem = ({ item, index }) => {
//     const getColorByAppStatus = (AppStatus: any) => {
//       switch (AppStatus) {
//         case 1:
//           return "#FFF2EA"
//         case 4:
//           return '#A7FFA5'
//         case 2:
//           return '#ACB0EE';
//         case 5:
//           return '#FFF0F0';
//         case 3:
//           return '#FFFAEC';
//         default:
//           return '#E7F8FF';
//       }
//     }
//     const getColorBorderByAppStatus = (AppStatus: any) => {
//       switch (AppStatus) {
//         case 1:
//           return "#FF9E5E"
//         case 4:
//           return '#A7FFA5'
//         case 2:
//           return '#ACB0EE';
//         case 5:
//           return '#FF8685';
//         case 3:
//           return '#FFD770';
//         default:
//           return '#8ECFFF';
//       }
//     }

//     const getStatusItem = (StatusItem: any) => {
//       switch (StatusItem) {
//         case 1:
//           return "Bổ sung"
//         case 2:
//           return "Điều chỉnh";
//         case 3:
//           return "Hoãn";
//         case 4:
//           return "Dự kiến";
//         case 5:
//           return "Hủy";
//         default:
//           return '';
//       }
//     }

//     const getParticipant = () => {
//       var dataTxt = item.ParticipantsDetail
//       var tPKhacTxt = item.AdditionIngredients ? item.AdditionIngredients : "";
//       var tPCTXDTxt = item.OtherParticipants ? item.OtherParticipants : "";
//       tPKhacTxt = tPKhacTxt.replace(/\n/g, ";$");
//       var decodedDataTxt = decodeURIComponent(dataTxt);
//       var dataToShow = decodedDataTxt + (tPKhacTxt || tPCTXDTxt ? "#Thành phần tại đơn vị;$" + tPCTXDTxt + ";$" + tPKhacTxt : "");
//       return dataToShow
//     }

//     const ParticipantTxt = () => {
//       let dataTxt = item.ParticipantsDetail || "";
//       if (item.OtherParticipants || item.AdditionIngredients) {
//         dataTxt += (dataTxt ? "#" : "") + "Thành phần tại đơn vị";
//       }
//       let data = decodeURIComponent(dataTxt);
//       return formatParticipantsDetail(data)
//     }

//     const OpenMeetingLink = (item: any) => {
//       if (item.IsView === 1) {
//         Linking.canOpenURL(item.MeetingLink).then(supported => {
//           if (!supported) {
//             Alert.alert(
//               'Thông báo',
//               'Bạn chưa có phần mềm họp, vui lòng tải để sử dụng.',
//             );
//             return;
//           } else {
//             Linking.openURL(item.MeetingLink);
//           }
//         });
//       } else {
//         Alert.alert(
//           'Thông báo',
//           'Bạn không có quyền vào link này',
//           [
//             {
//               text: 'Đóng',
//               onPress: () => {
//               },
//             },
//           ],
//         );
//       }
//     }

//     return <Pressable onPress={() => {
//       // @ts-ignore
//       navigation.navigate("DetailCalendarScreen", {
//         item: item
//       });
//     }}
//       style={{
//         borderWidth: 1.5,
//         borderRadius: 10,
//         flexDirection: "row",
//         alignItems: "center",
//         alignContent: "center",
//         justifyContent: "center",
//         marginTop: 10,
//         borderColor: getColorBorderByAppStatus(item.StatusItem)
//       }}>
//       <View style={{
//         padding: 10,
//         borderTopLeftRadius: 10,
//         borderBottomLeftRadius: 10,
//         flexDirection: "column",
//         flex: 3,
//         height: "100%",
//         backgroundColor: getColorByAppStatus(item.StatusItem),
//         alignItems: "center"
//       }}>

//         <View style={{ flexDirection: 'row' }}>
//           <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.StartTime)}</Text>
//           <Text> - </Text>
//           <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.EndTime)}</Text>
//         </View>

//         <View style={{
//           width: "100%",
//           alignItems: "center"
//         }}>
//           <View style={{ justifyContent: 'center', display: item.StatusItem ? 'flex' : 'none', backgroundColor: getColorBorderByAppStatus(item.StatusItem), height: 20, width: 60, borderRadius: 7, marginTop: '6%' }}>
//             <Text style={{ alignSelf: 'center' }}>{getStatusItem(item.StatusItem)}</Text>
//           </View>
//         </View>
//         <TouchableOpacity style={{ marginTop: '15%' }} onPress={() => {
//           Alert.alert('Địa điểm phòng họp', item.LocationTitle, [
//             { text: 'OK', onPress: () => console.log('OK Pressed') },
//           ]);
//         }}>
//           <Text numberOfLines={2} style={{ marginTop: '15%', textAlign: 'center' }}>{item.LocationTitle}</Text>
//         </TouchableOpacity>
//         {
//           item.MeetingLink != "" ? (
//             <View style={{ flexDirection: "row", marginTop: '45%' }}>
//               <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
//                 source={require("../../assets/images/icon_meeting_call.png")} />
//               <TouchableOpacity onPress={() => {
//                 OpenMeetingLink(item)
//               }}>
//                 <Text style={{ marginLeft: '5%' }}>Vào link họp</Text>
//               </TouchableOpacity>
//             </View>) : <View></View>
//         }
//       </View>

//       <View style={{
//         flexDirection: "column",
//         flex: 7,
//         height: "100%",
//         padding: 10,
//         backgroundColor: "white",
//         borderTopRightRadius: 9,
//         borderBottomRightRadius: 9
//       }}>
//         <Text numberOfLines={2}>{item?.Title}</Text>
//         <View style={{
//           width: "100%",
//           height: 1,
//           borderWidth: 0.5,
//           marginTop: '3%',
//           borderColor: "#474747",
//           borderStyle: "dashed"

//         }} />
//         <View style={{ flexDirection: "column", marginTop: 20 }}>
//           <View style={{ flexDirection: "row", marginBottom: 10 }}>
//             <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
//               source={require("../../assets/images/icon_user_calendar.png")} />
//             <Text>{item.HostTitle}</Text>
//           </View>
//           <View style={{ flexDirection: "row" }}>
//             <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
//               source={require("../../assets/images/icon_group_calendar.png")} />
//             <TouchableOpacity onPress={() => {
//               OnClickParticipant(getParticipant())
//             }} style={{ width: '80%', marginLeft: '2%' }}>
//               <Text>{(ParticipantTxt())}</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </View>
//     </Pressable>;


//   };


//   useEffect(() => {
//     if (isFirst) {
//       // loadMyCalendar()
//       getListDonVi().then(data => {
//         if (data != null) {
//           const matchDepartment = data.find((d: { SiteConnection: string; }) => subsiteStore.getSubsite() == (d.SiteConnection == 'Protal' ? "" : d.SiteConnection))
//           if (matchDepartment != undefined) {
//             setDonVi(data)
//             setUnitTitle(matchDepartment.Title)
//             setSiteConnection(matchDepartment.SiteConnection)
//           }
//           else {
//             setDonVi(data)
//             setUnitTitle(data[0].Title)
//             setSiteConnection(subsiteStore.getSubsite())
//           }
//           setIsFirst(false)
//           calculateWeekBounds();
//           loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 2, siteConnection).then(dataFirstLich => {
//             if (dataFirstLich != null) {
//               setlichhHop(dataFirstLich)
//             }
//           })
//         }
//         else {
//           setUnitTitle("Tập đoàn xăng dầu Việt Nam")
//           setSiteConnection("portal")
//           setKeyConnection("portal")
//         }
//       })
//     }
//     else {
//       setUnitTitle(uniTitle)
//       loadListCalendarByWeek(selectedDate, selectedDate, flag, siteConnection).then(dataLichHop => {
//         if (dataLichHop != null) {
//           setlichhHop(dataLichHop)
//         }
//       })
//     }
//     LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
//   }, [uniTitle])


//   const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag: number, keyConnection: any) => {
//     const data = await getMeetingCalendars(fromDate, toDate, flag, siteConnection);
//     if (data != null) {
//       return data;
//     } else {
//       return [];
//     }
//   };

//   const OnClickUnit = (item: any) => {
//     // @ts-ignore
//     navigation.navigate("Calendar_unit", {
//       item: donvi, title: uniTitle, flag: getFlag(indexTab),
//       onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
//         setUnitTitle(title)
//         setSiteConnection(SiteConnection)
//         setKeyConnection(KeyConnection)
//         setFlag(flag)
//         console.log("KeyConnection - here " + KeyConnection)

//       }
//     })
//   };

//   const OnClickParticipant = (item: any) => {
//     // @ts-ignore
//     navigation.navigate("Participant_Screen", {
//       item: item, title: item, flag: getFlag(indexTab),
//       onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
//         setUnitTitle(title)
//         setSiteConnection(SiteConnection)
//         setKeyConnection(KeyConnection)
//         setFlag(flag)
//         console.log("KeyConnection - here " + KeyConnection)
//       }
//     })
//   };

//   const onDateChanged = (date: any) => {
//     setIndexTab(0)
//     loadListCalendarByWeek(date, date, 2, siteConnection).then(data => {
//       if (data != null) {
//         setlichhHop(data)
//         const selectedDateChange = new Date(selectedDate);
//         setdateWeekLoad(selectedDateChange)
//         setSelectedDate(date)
//       }
//     })
//   };

//   // function startOfWeek(dt: string | number | Date, startOfWeek = 1) {
//   //   const diff = (7 + (dt.getDay() - startOfWeek)) % 7;
//   //   const newDate = new Date(dt);
//   //   newDate.setDate(dt.getDate() - diff);
//   //   newDate.setHours(0, 0, 0, 0);
//   //   return newDate;
//   // }


//   function startOfWeek(dt: string | number | Date, startOfWeek = 1) {
//     let inputDate: Date;
//     if (typeof dt === 'string' || typeof dt === 'number') {
//       inputDate = new Date(dt);
//     } else {
//       inputDate = dt as Date;
//     }
//     const diff = (7 + (inputDate.getDay() - startOfWeek)) % 7;
//     const newDate = new Date(inputDate);
//     newDate.setDate(inputDate.getDate() - diff);
//     newDate.setHours(0, 0, 0, 0);
//     return newDate;
//   }

//   useEffect(() => {
//     LoadListData()
//     setdateWeekLoad(!isPreDate ? new Date() : dateWeekLoad)
//   }, [isWeekView, keyConnection, flag]);//



//   const changeTab = (index: any) => {
//     setFlag(getFlag(index) || 0)
//     loadListCalendarByWeek(selectedDate, selectedDate, (getFlag(index) || 0), siteConnection).then(data => {
//       if (data != null) {
//         setlichhHop(data)
//       }
//     })
//   }

//   const LoadListData = () => {
//     if (isWeekView) {
//       LoadListCalendarByWeek(selectedDate)
//     }
//     else {
//       loadMyCalendar()
//     }
//   }

//   const LoadListCalendarByWeek = (date: any) => {
//     const dateObject = new Date(date)
//     const firstDay = startOfWeek(dateObject);
//     const lastDay = new Date(firstDay);
//     firstDay.setDate(firstDay.getDate())
//     lastDay.setDate(firstDay.getDate() + 6);
//     let flagWeek = getFlag(indexTab) || 0

//     setweek(getWeekOfYear(date));
//     setweeknum(`(${formatDateNum(firstDay)} - ${formatDateNum(lastDay)})`);

//     loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), flagWeek, siteConnection)
//       .then(dataFirstLich => {
//         if (dataFirstLich != null) {
//           setLichTuan(dataFirstLich);
//           console.log("From Date - To Date - v3: ", formatDate(firstDay), "/", formatDate(lastDay));
//           console.log("dictLichhop - here: ", Object.keys(dictLichhop));
//           console.log("dataFirstLich - here - count: ", dataFirstLich.length);
//           const tempDict: Record<string, any[]> = {}
//           dataFirstLich.forEach((item: { StartTime: string | number | Date; }) => {
//             if (item.StartTime) {
//               const key = formatDateToVietnamese(new Date(item.StartTime));
//               tempDict[key] = tempDict[key] ? [...tempDict[key], item] : [item];
//             }
//           });
//           setdictLichhop(tempDict);
//         }
//       });

//   }

//   const loadMyCalendar = () => {
//     const dateObject = new Date(selectedDate);
//     const firstDay = startOfWeek(dateObject);
//     const lastDay = new Date(firstDay);
//     firstDay.setDate(firstDay.getDate() - 20)
//     lastDay.setDate(firstDay.getDate() + 10);

//     loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, siteConnection)
//       .then(dataMyCalendar => {
//         if (dataMyCalendar) {

//           // const tempDictMyCalendar: Record<string, any[]> = {}
//           // dataMyCalendar.foreach((item: {StartTime: string | number | Date;}) =>{
//           //     if(item.StartTime)
//           //     { 
//           //         const key = formatDateToVietnamese(new Date(item.StartTime))
//           //         tempDictMyCalendar[key] = tempDictMyCalendar[key] ? [...tempDictMyCalendar[key],item] : [item];
//           //     }
//           // })

//           const tempDict = dataMyCalendar.reduce((acc: { [x: string]: any; }, item: { StartTime: moment.MomentInput; }) => {
//             if (item.StartTime) {
//               const key = moment(item.StartTime).format("YYYY-MM-DD");
//               acc[key] = acc[key] ? [...acc[key], item] : [item];
//             }
//             return acc;
//           }, {});
//           const propertiesToAssign = {
//             textColor: 'green',
//             color: 'green',
//             dotColor: 'red',
//             marked: true
//           };
//           const markedDates = Object.keys(tempDict).reduce((acc, date) => {
//             acc[date] = { ...propertiesToAssign };
//             return acc;
//           }, {});
//           setdotCalendar(markedDates);

//         } else {
//           console.error('No calendar data available');
//         }
//       })
//       .catch(error => {
//         console.error('Error loading calendar:', error);
//       });
//   };

//   const calculateWeekBounds = () => {
//     const firstDay = getStartOfWeek();
//     const lastDay = new Date(firstDay);
//     lastDay.setDate(firstDay.getDate() + 6);
//     setfirstDayofWeek(firstDay);
//     setlastDayOfWeek(lastDay);
//   };

//   const getFlag = (index: number) => {
//     switch (index) {
//       case 0:
//         return 2
//       case 1:
//         return 1;
//       case 2:
//         return 3;
//     }
//   }

//   const loadWeekCalendar = useCallback(() => {
//     setIsFullWeek(!isFullWeek);
//     setisWeekView(!isWeekView)
//   }, [isWeekView, isFullWeek])


//   const Btn_prevWeek_Click = () => {
//     dateWeekLoad.setDate(dateWeekLoad.getDate() - 7)
//     LoadListCalendarByWeek(dateWeekLoad)
//   }

//   const Btn_nextWeek_Click = () => {
//     dateWeekLoad.setDate(dateWeekLoad.getDate() + 7)
//     LoadListCalendarByWeek(dateWeekLoad)
//   }


//   LocaleConfig.locales["vn"] = {
//     monthNames: [
//       "Tháng 1",
//       "Tháng 2",
//       "Tháng 3",
//       "Tháng 4",
//       "Tháng 5",
//       "Tháng 6",
//       "Tháng 7",
//       "Tháng 8",
//       "Tháng 9",
//       "Tháng 10",
//       "Tháng 11",
//       "Tháng 12"
//     ],
//     monthNamesShort: [
//       "Th 1",
//       "Th 2",
//       "Th 3",
//       "Th 4",
//       "Th 5",
//       "Th 6",
//       "Th 7",
//       "Th 8",
//       "Th 9",
//       "Th 10",
//       "Th 11",
//       "Th 12"
//     ],
//     dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
//     dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
//   };
//   LocaleConfig.defaultLocale = "vn";

//   return (
//     <BaseScreen>
//       {
//         <View style={{ height: "100%", backgroundColor: "white" }}>

//           <PetroAppBarCustom
//             title={"Lịch tuần"}
//             rightAction={
//               <View style={{ flexDirection: 'row' }}>
//                 <TouchableOpacity onPress={() => {
//                   setIsShowMonthCalendar(!isShowMonthCalendar)
//                 }}>
//                   <Text style={{ marginRight: 15, marginTop: '7%', color: '#0072C6', fontWeight: '600' }}>{getDisplayTxtFromDateString(selectedDate)}</Text>
//                 </TouchableOpacity>

//                 <TouchableOpacity onPress={() => {
//                   loadWeekCalendar()
//                 }}>
//                   <Image style={{ height: 25, width: 25 }} source={
//                     !isFullWeek ?
//                       require("../../assets/images/icon_change_type_date.png") :
//                       require("../../assets/images/icon_change_type_week.png")
//                   } />
//                 </TouchableOpacity>
//               </View>
//             }
//             onPress={() => {
//               dispatch(showLeftMenuCalendar());
//               // @ts-ignore
//               navigation.openDrawer();
//             }} />
//           <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />


//           {/* <ReactNativeCalendarStrip
//        locale={{
//          name: "vi",
//          config: {
//            months: [
//              "Tháng 1",
//              "Tháng 2",
//              "Tháng 3",
//              "Tháng 4",
//              "Tháng 5",
//              "Tháng 6",
//              "Tháng 7",
//              "Tháng 8",
//              "Tháng 9",
//              "Tháng 10",
//              "Tháng 11",
//              "Tháng 12"
//            ],
//            weekdaysShort: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
//            weekdays: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"]
//          }
//        }}
//        datesBlacklist={datesBlacklistFunc}
//        highlightDateNameStyle={{ color: "#0072C6" }}
//        highlightDateNumberStyle={{ color: "#0072C6" }}
//        scrollable
//        // @ts-ignore
//        selectedDate={Date.now()}
//        style={{
//          width: "100%",
//          height: 60
//        }} /> */}

//           <View style={{ height: 80, backgroundColor: "cyan" }}>
//             {
//               isWeekView ? (
//                 <View>
//                   <View style={{ width: '100%', height: 80, backgroundColor: '#FAFAFA', flexDirection: 'row' }}>
//                     <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
//                       onPress={() => {
//                         Btn_prevWeek_Click()
//                         setisPreDate(
//                           !isPreDate)
//                       }}
//                     >
//                       <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
//                         source={require("../../assets/images/icon_preWeek.png")} />
//                     </TouchableOpacity>
//                     <View style={{ width: '70%', justifyContent: 'center', flexDirection: 'row' }}>
//                       <Text style={{ marginRight: '2%', alignSelf: 'center', fontSize: 16, fontWeight: '600' }}>Tuần {week}</Text>
//                       <Text numberOfLines={1} style={{ alignSelf: 'center', fontSize: 16 }}>
//                         {weeknum}
//                       </Text>
//                     </View>
//                     <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
//                       onPress={() => {
//                         Btn_nextWeek_Click()
//                       }}
//                     >
//                       <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
//                         source={require("../../assets/images/icon_nextWeek.png")} />
//                     </TouchableOpacity>
//                   </View>
//                 </View>
//               ) :
//                 (
//                   null
//                 )
//             }
//             <CalendarProvider
//               date={selectedDate} // date={"2024-01-01"}
//               //@ts-ignore
//               onDateChanged={(date) => { onDateChanged(date) }}
//               disabledOpacity={1}
//               showTodayButton={true}
//               markedDates={dotCalendar}
//             >
//               <WeekCalendar testID={'weekCalendar'}
//                 firstDay={1}
//                 theme={{
//                   backgroundColor: '#F3F9FF',
//                   calendarBackground: '#F3F9FF',//#ffffff
//                   textSectionTitleColor: 'black',
//                   selectedDayBackgroundColor: appMainBlueColor,//'#00adf5'
//                   selectedDayTextColor: '#ffffff',
//                   todayTextColor: appMainBlueColor,// '#00adf5'
//                   dayTextColor: 'black',
//                 }}
//                 disableOnPageChange={true}
//                 markedDates={dotCalendar}
//               />

//             </CalendarProvider>

//           </View>

//           <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

//           <TouchableOpacity
//             style={{ paddingVertical: 10, paddingHorizontal: 15, flexDirection: "row", backgroundColor: "white" }}
//             onPress={(item) => {
//               OnClickUnit(item);
//             }}>
//             <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
//               source={require("../../assets/images/icon_focus_contact.png")} />
//             <Text style={{ color: "black", fontWeight: "bold", fontSize: 15, width: '95%', backgroundColor: "white" }}>{uniTitle}</Text>
//           </TouchableOpacity>
//           <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />
//           <Tab
//             value={indexTab}
//             onChange={(index) => {
//               setIndexTab(index);
//               // setFlag(index)
//               console.log("Index here " + index)
//               changeTab(index)
//             }}
//             indicatorStyle={{ backgroundColor: "#0072C6", height: 3, borderRadius: 100, marginHorizontal: 4 }}
//           >
//             {tabs.map((tab, index) => (
//               <Tab.Item key={index} title={tab.title} containerStyle={{ backgroundColor: "white" }} titleStyle={{
//                 fontSize: 12,
//                 color: "#000000",
//                 height: 30,
//                 width: '100%'
//               }} />
//             ))}
//           </Tab>
//           <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA", marginTop: 5 }} />

//           <View style={{
//             height: "55%",
//             marginTop: '-50%',
//             zIndex: 99,
//             width: '95%',
//             alignSelf: 'center',
//             backgroundColor: 'transparent',
//             borderRadius: 15,
//             display: !isShowMonthCalendar ? 'none' : 'flex'
//           }}>
//             <Calendar
//               date={selectedDate}
//               onDayPress={day => {
//                 setSelectedDate(day.dateString);
//                 setIsShowMonthCalendar(false)
//                 onDateChanged(day.dateString)
//                 setisWeekView(false)
//               }}
//               markedDates={dotCalendar}
//               theme={{
//                 backgroundColor: '#F3F9FF',
//                 calendarBackground: '#F3F9FF',
//                 textSectionTitleColor: '#b6c1cd',
//                 selectedDayBackgroundColor: '#00adf5',
//                 selectedDayTextColor: '#ffffff',
//                 todayTextColor: '#0A78C8',
//                 dayTextColor: '#2d4150',
//                 textDayHeaderFontWeight: '600',
//               }}
//               style={{
//                 borderColor: 'gray',
//                 height: '100%',
//                 borderRadius: 15,
//                 marginTop: '6%',
//                 shadowColor: '#000',
//                 shadowOffset: { width: 0, height: 2 },
//                 shadowOpacity: 0.5, // Set the shadow opacity here
//                 shadowRadius: 4,
//               }}
//             />
//           </View>
//           <ScrollView style={{ alignContent: 'center' }} >
//             {
//               isWeekView && dictLichhop != undefined && Object.keys(dictLichhop).length > 0 ? (
//                 <FlatList
//                   style={{ padding: 10 }}
//                   data={Object.keys(dictLichhop)}
//                   renderItem={({ item }) => (
//                     <View>
//                       <View style={styles.headerWeekCalendar}>
//                         <Image style={{ height: 20, width: 20, marginRight: 10 }}
//                           source={require("../../assets/images/icon_week_header.png")} />

//                         <Text style={{ alignSelf: 'center', fontWeight: '600', color: '#0072C6' }}>{item}</Text></View>
//                       <FlatList
//                         style={{ marginTop: '2%' }}
//                         data={dictLichhop[item]}
//                         renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
//                         keyExtractor={(item, index) => index.toString()}
//                       />
//                     </View>
//                   )}
//                   keyExtractor={(item, index) => index.toString()}
//                 />
//               ) : isWeekView ? (<View style={styles.viewNoData}>
//                 <Text style={styles.textNoData}>Không có dữ liệu</Text>
//               </View>) : null
//             }
//             {lichhHop != undefined && lichhHop.length > 0 && !isWeekView ? (
//               <FlatList
//                 data={lichhHop}
//                 renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
//                 keyExtractor={item => item.id}
//                 scrollEnabled={false}
//                 style={{ padding: 10 }}
//               />
//             ) : !isWeekView ? (
//               <View style={styles.viewNoData}>
//                 <Text style={styles.textNoData}>Không có dữ liệu</Text>
//               </View>) : null}
//           </ScrollView>
//         </View>
//       }


//     </BaseScreen>
//   );
// };
// const styles = StyleSheet.create({
//   viewNoData: {
//     flex: 1,
//     justifyContent: 'center',
//     marginTop: '50%',
//     alignItems: 'center',
//   },
//   textNoData: {
//     fontSize: 15,
//     color: '#5E5E5E',
//     fontStyle: 'italic'
//   },
//   headerWeekCalendar: {
//     backgroundColor: '#E7F5FF',
//     height: 40,
//     width: '60%',
//     justifyContent: "center",
//     flexDirection: 'row',
//     borderRadius: 14,
//     alignItems: 'center',
//     marginTop: '2%'
//   },
//   absolute: {
//     position: 'absolute',
//     top: 0,
//     left: 0,
//     bottom: 0,
//     right: 0,
//   },
// });

