import { FlatList, Text } from "react-native";
import { Image } from "react-native-elements";

// @ts-ignore
export const DotBellowComponent=({currentIndex,numDot})=>{
  const data = Array.from({ length: numDot }, (_, index) => `Item ${index + 1}`);
  return  <FlatList
    horizontal={true}
    data={data}
    renderItem={({ index }) =>
      <Image style={{height:5,width:5, marginHorizontal:2}}
             source={currentIndex==index?
               require('../../../../assets/images/icon_dot_selected.png'):
               require('../../../../assets/images/icon_dot.png')}
      />}
    keyExtractor={(item, index) => index.toString()}
  />
}
