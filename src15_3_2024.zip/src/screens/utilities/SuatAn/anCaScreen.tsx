import { Text, View } from "react-native";
import { showLeftMenuDangKyXuatAn } from "../../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../../components/petro_appbar_custom.tsx";
import React from "react";
import { useDispatch } from "react-redux";
import { WebView } from "react-native-webview";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
import { useNavigation } from "@react-navigation/native";

export const AnCaScreen=()=>{
  const dispatch= useDispatch();
  const navigation=useNavigation();
  return <View style={{flex:1}}>
    <PetroAppBarCustom
      title={"Quản lý ăn ca"}
      onPress={() => {
        dispatch(showLeftMenuDangKyXuatAn());
        // @ts-ignore
        navigation.openDrawer();
      }} />
    <WebView
      style={{ flex: 1, }}
      originWhitelist={['*']}
      source={{ uri: getFullLink()+"/QLSuatAn/SitePages/MealRegistration_ListByDate.aspx?IsMobile=1"}}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
    />
  </View>
}
