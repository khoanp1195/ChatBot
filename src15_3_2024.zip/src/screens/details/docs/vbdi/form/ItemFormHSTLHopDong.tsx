import { View } from "react-native"
import { HeaderValueTextView } from "../../../../../components/headerValueTextView"
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { FC } from "react"
interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLHopDong: FC<Props> = ({ dataForm }) => {
    return <View>
        <HeaderValueTextView headerText={"Số hợp đồng"}
            valueText={isNullOrEmpty(dataForm.DocumentName) ?
                "" :
                dataForm.DocumentName}
        />
        <HeaderValueTextView headerText={"Đơn vị soạn thảo"}
            valueText={isNullOrEmpty(dataForm.DepartmentTitle) ?
                "" :
                dataForm.DepartmentTitle} />
        <HeaderValueTextView headerText={"Nội dung hợp đồng"}
            valueText={isNullOrEmpty(dataForm.Subject) ? ""
                : dataForm.Subject} />
        <HeaderValueTextView headerText={"Ngày ký"}
            valueText={dataForm.ReceivedDate != null ?
                convertStringToMoment(dataForm.ReceivedDate).format("DD/MM/YY") :
                ""} />
        <HeaderValueTextView headerText={"Người ký"} valueText={isNullOrEmpty(dataForm.UserSigned) ? "" : dataForm.UserSigned} />
        <HeaderValueTextView headerText={"Ngày hiệu lực"} valueText={dataForm.EffectiveDate != null ?
            convertStringToMoment(dataForm.EffectiveDate).format("DD/MM/YY") :
            ""} />
        <HeaderValueTextView headerText={"Nơi lưu"} valueText={isNullOrEmpty(dataForm.NoiLuu) ? "" : dataForm.NoiLuu} />
        <HeaderValueTextView headerText={"Lĩnh vực"} valueText={isNullOrEmpty(dataForm.CodeFieldTitle) ? "" : dataForm.CodeFieldTitle} />
        <HeaderValueTextView headerText={"Hồ sơ"} valueText={isNullOrEmpty(dataForm.HoSoTitle) ? "" : dataForm.HoSoTitle} />
    </View>
}