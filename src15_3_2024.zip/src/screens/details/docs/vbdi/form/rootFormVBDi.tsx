import { FC } from "react";
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi";
import { View } from "react-native";
import { Text } from "react-native-elements";
import { FormHoSoTaiLieu } from "../../../../../config/enum";
import { ItemFormVanBanDi } from "./itemFormVanBanDi";
import { ItemFormHSTLToTrinh } from "./ItemFormHSTLToTrinh";
import { ItemFormHSTLBienBanNoiBo } from "./ItemFormHSTLBienBanNoiBo";
import { ItemFormHSTLHopDong } from "./ItemFormHSTLHopDong";
import { ItemFormHSTLBaoCaoNoiBo } from "./ItemFormHSTLBaoCaoNoiBo";
import { ItemFormHSTLKhac } from "./ItemFormHSTLKhac";
import { ItemFormHSTLBienBanThanhToan } from "./ItemFormHSTLBienBanThanhToan";

interface Props {
    dataForm: BeanVBDi
}
export const RootFormVBDi: FC<Props> = ({ dataForm }) => {
    const CurrentForm = () => {
        switch (dataForm.CodeCategoryId) {
            case 0:
            case FormHoSoTaiLieu.VanBan:
                return <ItemFormVanBanDi dataForm={dataForm}/>
            case FormHoSoTaiLieu.ToTrinhNoiBo:
                return <ItemFormHSTLToTrinh dataForm={dataForm}/>
            case FormHoSoTaiLieu.BienBanNoiBo:
                return <ItemFormHSTLBienBanNoiBo dataForm={dataForm}/>
            case FormHoSoTaiLieu.HopDong:
                return<ItemFormHSTLHopDong  dataForm={dataForm} />
            case FormHoSoTaiLieu.BaoCaoNoiBo:
                return <ItemFormHSTLBaoCaoNoiBo dataForm={dataForm}/>
            case FormHoSoTaiLieu.HoSoTaiLieuKhac:
                return <ItemFormHSTLKhac dataForm={dataForm}/>
            case FormHoSoTaiLieu.BienBanThanhToan:
                return <ItemFormHSTLBienBanThanhToan dataForm={dataForm}/>
                default:
                    return <View/>
        }
    }



    return <CurrentForm/>
}