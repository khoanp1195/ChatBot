import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../../components/modalTopBar";
import { Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useEffect, useState } from "react";
import { getAttachmentHoSoluuTru, getDetailHoSoluuTru, getDetailVanBanHoSoluuTru } from "../../../../services/api/apiDetailHSLT";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { useSelector } from "react-redux";
import EmptyView from "../../../../components/empty_view.tsx";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { List_noidung_hslt } from "../../docDetail/List_noidung_hslt.jsx";
import { getDisplayTxtFromDateString } from "../../../../utils/functions.ts";
import { ListAttachment } from "../../../../screens/details/docDetail/listAttachment.jsx";
import { downloadFile } from "../../../../services/api/api_client.ts";
// import { openFile } from "../../../../utils/fileUtil.ts";
import { BeanHSLT } from "../../../../services/database/models/beanHSLT.ts";

export const DetailHSTLScreen = () => {
  const route = useRoute();
  // @ts-ignore
  const item = route.params["item"];
  const navigation = useNavigation();
  const [detailHSLT, setdetailHSLT] = useState<BeanHSLT[]>();
  const [detailVanBan, setdetailVanBan] = useState<[]>();
  const [attachment, setAttachment] = useState<[]>();
  const onLoading = useSelector((state: any) => state.loading.onLoading);

  useEffect(() => {
    getDetailHoSoluuTru(item.ID, true).then(detail => {
      if (detail != null) {
        setdetailHSLT(detail)
      }
    })
    getDetailVanBanHoSoluuTru(item.ID).then(detailVanBan => {
      if (detailVanBan != null) {
        setdetailVanBan(detailVanBan)
      }
    })
    getAttachmentHoSoluuTru(item.ID).then(attachment => {
      if (attachment != null) {
        setAttachment(attachment)
      }
    })
  }, [onLoading,item])

  //@ts-ignore
  const onClickAttachment = (item) => {
    if (__DEV__)
      console.log("onClickAttachment", item);
    if (Platform.OS == "ios") {
      //@ts-ignore
      navigation.navigate('AttachmentDetailView', { item })
    }
    else {
      downloadFile(item.Url).then(filePath => {
        openFile(filePath);
      })
    }
  };

  //@ts-ignore
  const navigateToDetailVanban = (item) => {
    switch (item.ModuleId) {
      case 3:
        //@ts-ignore
        navigation.navigate("VBDenDetailScreen", { item });
        break;
      case 7:
      case 9:
        //@ts-ignore
        navigation.navigate("VBDiDetailScreen", { item });
        break;
      case 8:
        //@ts-ignore
        navigation.navigate("VBBHDetailScreen", { item });
        break;
      default:
        if (__DEV__)
          console.log("Role tào lao gòi")
        break;
    }
  }

  const Item = ({ item, index }: any) => {
    return (
      //      backgroundColor: index % 2 != 0 ? "white" : "#F3F9FF"
      <TouchableOpacity onPress={() => {
        navigateToDetailVanban(item)
      }} style={{ backgroundColor: index % 2 != 0 ? "white" : '#DFF1FF', height: 50, width: '100%' }}>
        <View style={{ flexDirection: 'row' }}>
          <Text style={styles.titleItemTxt}>{item.Title}</Text>
          <Text style={styles.NgayTrenVBTxt}>{getDisplayTxtFromDateString(item.Created)}</Text>
        </View>

      </TouchableOpacity>
    );
  };

  return <View style={{ flex: 1 }}>
    <View style={{ flex: 1 }}>
      <ModalTopBar
        title={""}
        rightAction={undefined}
        onPress={() => {
          navigation.goBack()
        }}
      />
      {
        detailHSLT != undefined  && detailHSLT.length>0? <View style={{ flex: 1 }}>
          <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row" }}>
            <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>
              {detailHSLT[0].TenHoSo }
            </Text>
          </View>
          <ScrollView style={{ flex: 1, backgroundColor: 'white' }}>
            <List_noidung_hslt hslt={detailHSLT[0]} />
            {
              detailVanBan != undefined && detailVanBan.length > 0 ?
                (<View style={{ marginTop: '7%' }}>
                  <Text style={{ marginLeft: '4%', color: 'black', fontWeight: '600' }}>Hồ sơ tài liệu</Text>
                  <FlatList
                    data={detailVanBan}
                    renderItem={({ item, index }) => <Item item={item} index={index} />}
                    scrollEnabled={false}
                    style={styles.flatList}
                  />
                </View>) : <View></View>
            }
            {
              attachment != undefined && attachment.length > 0 ?
                (
                  <ListAttachment data={attachment} onClick={(item: any) => onClickAttachment(item)} />
                ) : <View></View>
            }
          </ScrollView>
        </View> : <EmptyView />
      }

      {onLoading && <LoadingScreen />}
    </View>
  </View>
};
const styles = StyleSheet.create({
  flatList: {
    backgroundColor: 'white',
    paddingVertical: 10,
  },
  titleItemTxt: {
    color: '#0072C6'
    , marginLeft: 10,
    marginTop: 10,
    width: '80%'
  },
  NgayTrenVBTxt: {
    marginTop: 8,
    color: 'gray'
  }
})
