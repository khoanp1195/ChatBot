import { FlatList, Image, Pressable, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { getListItemBackground } from "../../../utils/functions.ts";
import { CustomImageButton } from "../../../components/customImageButton.tsx";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import strings from "../../../assets/strings.ts";
import { getStringDataFromDept, getKeyStringFromDept } from "./assignHelper.tsx";
import { isNullOrEmpty, } from "../../../utils/functions.ts";
import { ScrollView } from "react-native-gesture-handler";

export const AssignTreeView = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const [expandedSections, setExpandedSections] = useState(new Set());
  const [isCheckAllThucHien, setIsCheckAllThucHien] = useState(false);
  const [isCheckAllPhoiHop, setIsCheckAllPhoiHop] = useState(false);
  // @ts-ignore
  const [lstPhanCong, setLstPhanCong] = useState(route.params["dataSelected"]);
  // @ts-ignore
  let data = route.params["data"];
  // @ts-ignore
  const onSubmit = route.params["onSubmit"];

  // @ts-ignore
  // const expandedSectionTitle = route.params["expandedSectionTitle"] ?? "";
  const isTask = route.params["isTask"] ?? false;

  // useEffect(() => {
  //   if (!isNullOrEmpty(expandedSectionTitle)) { handleToggle(expandedSectionTitle) }
  // }, []);

  useEffect(() => {
    if (isTask && data != undefined && data.length > 0) {
      handleToggle(data[0].ID + strings.SplitSignal + data[0].Title)
    }
  }, []);

  //@ts-ignore
  const handleToggle = (title) => {
    console.log("mở " + title)
    setExpandedSections((expandedSections) => {
      // Using Set here but you can use an array too
      const next = new Set(expandedSections);
      if (next.has(title)) {
        next.delete(title);
      } else {
        next.add(title);
      }
      return next;
    });
  };

  const addOrRemoveLstPhanCong = (info: any) => {
    if (info != undefined) {
      setLstPhanCong((lstPhanCong: Iterable<unknown> | null | undefined) => {
        // Using Set here but you can use an array too
        const next = new Set(lstPhanCong);
        if (next.has(info)) {
          next.delete(info);
        } else {
          next.add(info);
        }
        return next;
      });
    }
  };

  // @ts-ignore
  const getImageCheck = (isCheck) => {
    return isCheck ? require("../../../assets/images/icon_CheckEvalution.png") : require("../../../assets/images/icon_unCheckEvaluntion_Tint.png");
  };
  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    if (__DEV__) 
    console.log("vẽ item",item);
    // const isExpand = expandedSections.has(item.ID + ";@" + item.Title);
    const isExpand = expandedSections.has(getKeyStringFromDept(item));
    let itemSelected: any;
    let isPhoiHop = false;
    let isThucHien = false;
    const doHideRootItem = (index == 0 && isTask )?  (item.IsUser&&isTask ): true;

    if (lstPhanCong != undefined) {
      // // @ts-ignore
      // itemSelected = Array.from(lstPhanCong).find(itemFind => itemFind != undefined && itemFind.includes(item.ID + ";@" + item.Title));
      // @ts-ignore
      itemSelected = Array.from(lstPhanCong).find(itemFind => itemFind != undefined && itemFind.includes(getKeyStringFromDept(item)));
      if (__DEV__ && itemSelected != undefined)
        console.log(" lstPhanCong nè", JSON.stringify(itemSelected));
    }

    if (itemSelected != undefined) {
      // @ts-ignore
      // const data = itemSelected.split(';@');
      const data = itemSelected.split(strings.SplitSignal)
      isThucHien = JSON.parse(data[2]);
      isPhoiHop = JSON.parse(data[3]);
      console.log("data nè " + JSON.stringify(data), "ThucHien nè " + JSON.stringify(data[2]), isThucHien, "PhoiHop nè " + JSON.stringify(data[3]), isPhoiHop)
    }
    return <View style={[{ backgroundColor: getListItemBackground(index % 2 != 0), flex: 1 }]}>
      {
        doHideRootItem && <Pressable
          style={{
            flexDirection: "row",
            alignItems: "center"
          }}
          onPress={() => {
            // handleToggle(item.ID + ";@" + item.Title);
            handleToggle(item.ID + strings.SplitSignal + item.Title);
          }}>
          {item.IsUser == undefined && <Image style={{ height: 20, width: 20, marginRight: 10 }}
            resizeMode={"contain"}
            source={isExpand ? require("../../../assets/images/icon_unPlus.png") : require("../../../assets/images/icon_plus.png")} />
          }
          <Text
            style={{ marginHorizontal: item.IsUser != undefined && item.IsUser ? 20 : 0, flex: 6 }}>{item.Title}</Text>
          <View style={{ width: 60, height: 30, flex: 1, flexDirection: "row" }}>
            <CustomImageButton
              imgPath={getImageCheck(isThucHien)}
              onClickHandle={() => {
                setIsCheckAllThucHien(false);
                addOrRemoveLstPhanCong(itemSelected);
                // addOrRemoveLstPhanCong(item.ID + ";@" + item.Title + ";@" + !isThucHien + ";@" + false + ";@" + (item.IsUser != undefined) + ";@" + item.DepartmentTitle + ";@" + item.GroupManager);
                var selectedItem = item;
                selectedItem.IsThucHien = !isThucHien//!selectedItem.isThucHien//
                selectedItem.IsPhoiHop = false
                // item.IsUser = item.IsUser != undefined
                addOrRemoveLstPhanCong(getStringDataFromDept(selectedItem));
              }}
            />
            <CustomImageButton
              imgPath={getImageCheck(isPhoiHop)}
              onClickHandle={() => {
                setIsCheckAllPhoiHop(false);
                addOrRemoveLstPhanCong(itemSelected);
                // addOrRemoveLstPhanCong(item.ID + ";@" + item.Title + ";@" + false + ";@" + !isPhoiHop + ";@" + (item.IsUser != undefined) + ";@" + item.DepartmentTitle + ";@" + item.GroupManager);
                var selectedItem = item;
                selectedItem.IsThucHien = false
                selectedItem.IsPhoiHop = !isPhoiHop//!selectedItem.isPhoiHop//
                // item.IsUser = item.IsUser != undefined
                addOrRemoveLstPhanCong(getStringDataFromDept(selectedItem));
              }}
            />
          </View>

        </Pressable>}
      {
        (isExpand &&
          item.ListChildDepartment != undefined) ?
          <View>
            {
              item.ListChildDepartment.map((item: any, index: any) => (
                <RenderItem
                  key={
                    getKeyStringFromDept(item)//item.ID + ";#" + item.Title
                  }
                  item={item}
                  index={index}
                />
              ))
            }
          </View> :
          <View />
      }
      {
        (
          isExpand &&
          item.ListChildUser != undefined) ?
          <View style={{ flex: 1}}>
            {
              item.ListChildUser.map((item: any, index: any) => (
                <RenderItem item={item} index={index} />
              ))
            }
          </View> :
          <View />
      }
    </View>;
  };

  const onClickAllThucHien = () => {
    if(data!=undefined)
    {
      if (!isCheckAllThucHien)
      setLstPhanCong(new Set());
    setIsCheckAllPhoiHop(false);
    setIsCheckAllThucHien(!isCheckAllThucHien);
    for (const item of data) {
      const index: number = data.indexOf(item);
      data[index] = checkAll(data[index], true);
    }
    }
  };

  const onClickAllPhoiHop = () => {
    if(data!=undefined)
    {
      if (!isCheckAllPhoiHop)
      setLstPhanCong(new Set());
    setIsCheckAllPhoiHop(!isCheckAllPhoiHop);
    setIsCheckAllThucHien(false);
    for (const item of data) {
      const index: number = data.indexOf(item);
      data[index] = checkAll(data[index], false);
    }
    }
  };

  const checkAll = (departmentParent: any, isThucHien: boolean) => {
    departmentParent.IsThucHien = isThucHien;
    departmentParent.IsPhoiHop = !isThucHien;
    // addOrRemoveLstPhanCong(departmentParent.ID + ";@" + departmentParent.Title + ";@" + departmentParent.IsThucHien + ";@" + departmentParent.IsPhoiHop + ";@" + (departmentParent.IsUser != undefined) + ";@" + departmentParent.DepartmentTitle + ";@" + departmentParent.GroupManager);
    addOrRemoveLstPhanCong(getStringDataFromDept(departmentParent));
    if (departmentParent.ListChildDepartment != undefined && departmentParent.ListChildDepartment.length > 0) {
      for (const item of departmentParent.ListChildDepartment) {
        const index: any = departmentParent.ListChildDepartment.indexOf(item);
        departmentParent.ListChildDepartment[index] = checkAll(departmentParent.ListChildDepartment[index], isThucHien);
      }
    } else {
      if (departmentParent.ListChildUser != undefined && departmentParent.ListChildUser.length > 0) {
        for (const item of departmentParent.ListChildUser) {
          const index: any = departmentParent.ListChildUser.indexOf(item);
          departmentParent.ListChildUser[index] = checkAll(departmentParent.ListChildUser[index], isThucHien);
        }
      }
    }
    return departmentParent;
  };

  const submitSelect = () => {
    if (lstPhanCong != undefined) {

      const data = Array.from(lstPhanCong)
        .filter(item => item != undefined
          // @ts-ignore
          && (JSON.parse(item.split(strings.SplitSignal)[2]) || JSON.parse(item.split(strings.SplitSignal)[3]))
        );// const data = Array.from(lstPhanCong).filter(item => item != undefined && (JSON.parse(item.split(";@")[2]) || JSON.parse(item.split(";@")[3])));

      if (data != undefined && data.length > 0) {
        onSubmit(data);
      } else {
        showAlert("Vui lòng chọn Phòng/Ban hoặc Đơn vị");
      }
    } else {
      showAlert("Vui lòng chọn Phòng/Ban hoặc Đơn vị");
    }
  };

  return <View style={{ backgroundColor: "white", flex: 1, flexDirection: "column" }}>
    <ModalTopBar
      title={"Các phòng/ban nghiệp vụ Công ty"}
      onPress={() => {
        navigation.goBack();
      }} />
    <View style={{ flexDirection: "row" }}>
      <View style={{ flex: 8 }} />
      <Text style={{ flex: 1 }}>Thực hiện</Text>
      <CustomImageButton
        imgPath={getImageCheck(isCheckAllThucHien)}
        onClickHandle={() => onClickAllThucHien()}
      />
      <Text style={{ flex: 1 }}>Phối hợp</Text>
      <CustomImageButton
        imgPath={getImageCheck(isCheckAllPhoiHop)}
        onClickHandle={() => onClickAllPhoiHop()}
      />

    </View>
    <View style={{flex:1}}>
    {
      (data != undefined && data.length > 0) && <FlatList
        data={data}
        renderItem={RenderItem}
        keyExtractor={
          item => getKeyStringFromDept(item)//item.ID + ";#" + item.Title
        }
      />
    }
    </View>

    <View style={{ flexDirection: "row", padding: 10 }}>
      <View style={{ flex: 1 }} />
      <View style={{ flex: 1, flexDirection: "row" }}>
        <Pressable onPress={() => {
          navigation.goBack();
        }} style={{ flex: 1 }}><Text
          style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
        <Pressable
          onPress={() => {
            submitSelect();
            navigation.goBack();
          }}
          style={{
            flex: 1,
            backgroundColor: "#0072C6",
            padding: 10,
            borderRadius: 6
          }}>
          <Text style={{
            textAlign: "center",
            backgroundColor: "#0072C6",
            color: "white",
            borderRadius: 6
          }}>Đồng ý</Text>
        </Pressable>
      </View>
    </View>
  </View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 40
  },
  item: {
    padding: 10,
    flex: 1
  }
});
