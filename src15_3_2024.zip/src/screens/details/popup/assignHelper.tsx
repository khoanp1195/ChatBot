import { isNullOrEmpty } from "../../../utils/functions";
import { DbServices } from "../../../services/database/db_service";
import { BeanBanLanhDao } from "../../../services/database/models/bean_ban_lanh_dao";
import { BeanDepartment } from "../../../services/database/models/bean_department";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants";
import strings from "../../../assets/strings";

const CloneListMultipleDepartment = async (departmentParent: any, isTask: boolean = false) => {
    try {
        let departmentsNextLV = await DbServices.getInstance().getBeanDepartmentRepository()
            .getDepartmentByParentIDURLEmpty("ID,Title,MultipleManager,Url,GroupManager", departmentParent.ID, 1);

        if (departmentsNextLV != null && departmentsNextLV.length > 0) {
            departmentParent.ListChildDepartment = departmentsNextLV;
            for (const item of departmentParent.ListChildDepartment) {
                const index: any = departmentParent.ListChildDepartment.indexOf(item);
                //@ts-ignore
                departmentParent.ListChildDepartment[index] = await CloneListMultipleDepartment(departmentParent.ListChildDepartment[index], isTask);
            }
        } else {
            departmentParent.ListChildUser = [];
            ///Không còn phòng ban thì kiểm tra còn user không và lấy DS user nếu có
            ///Lấy theo API (VB đến thì dùng MultipleManager; Task VB đến thì dùng MultipleManagerGroup), nếu không có thì Query trong DB
            let _lstUserInfo = undefined;
            ///Nếu là Văn bản đến thì dùng MultipleManager
            if (!isTask && !isNullOrEmpty(departmentParent.MultipleManager)) {
                _lstUserInfo = departmentParent.MultipleManager.split(";#");
            }
            ///Nếu là Task VB Đến thì dùng SPNhomUserId
            else if (isTask && !isNullOrEmpty(departmentParent.SPNhomUserId)) {
                _lstUserInfo = departmentParent.SPNhomUserId.split(";#");
            }

            if (_lstUserInfo != undefined && _lstUserInfo.length > 0)
                for (let i = 0; i < _lstUserInfo.length; i += 2) {
                    let objDeparment = {
                        ID: parseInt(_lstUserInfo[i]),
                        Title: _lstUserInfo[i + 1],
                        DepartmentTitle: departmentParent.ID + ";#" + departmentParent.Title,
                        IsUser: true
                    };

                    if (departmentParent.ListChildUser == undefined)
                        departmentParent.ListChildUser = [objDeparment];
                    else
                        departmentParent.ListChildUser.push(objDeparment);
                }
        }
        return departmentParent;
    } catch (ex) {
    }
};

export const getDataAssignTree = async (_beanVanBanDen: any) => {
    let lv_1_departments: any
    let banlanhdaos: BeanBanLanhDao[] = []

    if (!isNullOrEmpty(_beanVanBanDen.BanLanhDao)) {
        banlanhdaos = await DbServices
            .getInstance()
            .getBanLanhDaoRepository()
            .findLanhDaoByID("DonVi", _beanVanBanDen.BanLanhDao.split(";#")[0]);
    }

    if (banlanhdaos != null && banlanhdaos.length > 0) {
        if (!isNullOrEmpty(banlanhdaos[0].DonVi)) {
            console.log('Lấy đơn vị từ lãnh đạo trong văn bản đến')
            ///Lấy đơn vị từ lãnh đạo trong văn bản đến
            lv_1_departments = await DbServices
                .getInstance()
                .getBeanDepartmentRepository()
                .findDepartmentByIDAndDeptStatus("ID,Title,MultipleManager,Url,GroupManager", parseInt(banlanhdaos[0].DonVi.split(";#")[0]), 1);

            if (lv_1_departments != null && lv_1_departments.length > 0) {
                for (const item of lv_1_departments) {
                    const index: number = lv_1_departments.indexOf(item);
                    console.log("item", item);
                    //@ts-ignore
                    lv_1_departments[index].IsCanExpand = true;
                    lv_1_departments[index] = await CloneListMultipleDepartment(item);
                }
            }
        } else {
            var url = getFullLink();
            console.log('Tài khoản lãnh đạo là tài khoản root => Lấy root department theo URL ', url)
            ///Tài khoản lãnh đạo là tài khoản root => Lấy root department theo URL - Anh VuPA confirm theo kiểu hiện trên android, không hiện tổng cty
            let lv_parent = await DbServices
                .getInstance()
                .getBeanDepartmentRepository()
                .findDepartmentByUrl("ID,Title,MultipleManager,Url,GroupManager", url);

            if (lv_parent != null && lv_parent.length > 0) {
                console.log("Parent nè: " + JSON.stringify(lv_parent))
                ///Lấy danh sách phòng ban từ đơn vị ban lãnh đạo
                lv_1_departments = await DbServices
                    .getInstance()
                    .getBeanDepartmentRepository()
                    .getDepartmentByParentIDURLEmpty("ID,Title,MultipleManager,Url,GroupManager", lv_parent[0].ID, 1);
                if (lv_1_departments != null && lv_1_departments.length > 0) {
                    console.log("lv_1_departments", lv_1_departments);
                    for (const item of lv_1_departments) {
                        const index: number = lv_1_departments.indexOf(item);
                        console.log("item", item);
                        //@ts-ignore
                        lv_1_departments[index].IsCanExpand = true;
                        lv_1_departments[index] = await CloneListMultipleDepartment(item);
                    }
                }
            }
        }
    }
    else {
        ///Tài khoản lãnh đạo là tài khoản root => Lấy root department theo URL
        // let donVi = await DbServices.getInstance().getBeanDepartmentRepository().findDepartmentByRootID();
        if(banlanhdaos!=undefined)
        {
            lv_1_departments = await DbServices
            .getInstance()
            .getBeanDepartmentRepository()
            .findDepartmentByIDAndDeptStatus("ID,Title,MultipleManager,Url,GroupManager", parseInt(banlanhdaos[0].DonVi.split(";#")[0]), 1);

        if (lv_1_departments != null && lv_1_departments.length > 0) {
            for (const item of lv_1_departments) {
                const index: number = lv_1_departments.indexOf(item);
                console.log("item", item);
                //@ts-ignore
                lv_1_departments[index].IsCanExpand = true;
                lv_1_departments[index] = await CloneListMultipleDepartment(item);
            }
        }
        }
    }
    return lv_1_departments;
};

export const getDataTaskAssignTree = async (_taskVBDen: any) => {
    let departments: any = await DbServices
        .getInstance()
        .getBeanDepartmentRepository()
        .findDepartmentByIDAndDeptStatus("ID,Title,MultipleManager,Url,GroupManager,SPNhomUserId", parseInt(_taskVBDen.DepartmentId), 1);

    if (departments != null && departments.length > 0) {
        const dept = departments[0];
        if (__DEV__) console.log("Item nè", JSON.stringify(dept));
        if (dept != undefined)
            for (const item of departments) {
                const index: number = departments.indexOf(item);
                console.log("item", item);
                //@ts-ignore
                departments[index].IsCanExpand = true;
                departments[index] = await CloneListMultipleDepartment(item, true);
            }
        // if (__DEV__) console.log("Item trc khi xóa nè", JSON.stringify(departments));
        // if (departments.length > 1) {
        //     departments.splice(0, 1);
        // }
        if (__DEV__) console.log("Item xong xuôi òi nè", JSON.stringify(departments));
    }
    // var _queryPhanCong = "SELECT * FROM BeanDepartment WHERE ID = ? ORDER BY [Order]";
    // var dept = conn.Query<BeanDepartment>(_queryPhanCong, beanVanBanDen.ID).FirstOrDefault();
    // if (dept != null) {
    //     rootID = dept.ID.Value;
    //     beanDepartments = new List < BeanDepartment > { dept };

    //     var lst_ChildDep = new List<BeanDepartment>();
    //     if (beanDepartments != null && beanDepartments.Count > 0) {
    //         foreach(var parentNode in beanDepartments)
    //         {
    //             List < BeanDepartment > lstChildObjs = GetChildItems(parentNode, false);
    //             if (lstChildObjs != null && lstChildObjs.Count > 0)
    //                 lst_ChildDep.AddRange(lstChildObjs);
    //         }

    //         if (lst_ChildDep != null && lst_ChildDep.Count > 0)
    //             beanDepartments.AddRange(lst_ChildDep);
    //     }
    // }
    return departments;
};

export const getStringDataFromDept = (_beanDepartment: any) => {

    var txt = [_beanDepartment.ID,
    _beanDepartment.Title,
    _beanDepartment.IsThucHien != undefined && Boolean(_beanDepartment.IsThucHien) ? "true" : "false",//
    _beanDepartment.IsPhoiHop != undefined && _beanDepartment.IsPhoiHop ? "true" : "false",//
    _beanDepartment.IsUser != undefined && _beanDepartment.IsUser ? "true" : "false",//
    _beanDepartment.DepartmentTitle,
    _beanDepartment.GroupManager,
    _beanDepartment.HanXuLy
    ].join(strings.SplitSignal);

    if (__DEV__)
        console.log("txt nè", txt, "isThucHien nè", _beanDepartment.IsThucHien)

    return txt;
}

export const getKeyStringFromDept = (_beanDepartment: any) => {
    return _beanDepartment.ID + strings.SplitSignal + _beanDepartment.Title
}