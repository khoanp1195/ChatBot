import { useNavigation, useRoute } from "@react-navigation/native";
import { ActivityIndicator, FlatList, Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import React, { useEffect, useState } from "react";
import { appMainBlueColor } from "../../../utils/color.ts";
import EmptyView from "../../../components/empty_view.tsx";
import {
  getInitials,
  getListItemBackground,
  getRandomColor,
  isNullOrEmpty,
  removeSignVietnamese
} from "../../../utils/functions.ts";
import { DbServices } from "../../../services/database/db_service.ts";
import { TypeSelectUser, EnumTaskAction } from "../../../config/enum.ts";
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";

export const SelectUserScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  // @ts-ignore
  const typeSelect = route.params["typeSelect"];
  // @ts-ignore
  const isSingleChoose = typeSelect == TypeSelectUser.Single;
  // @ts-ignore
  const usersSelected = route.params["usersSelected"] ?? [];
  // @ts-ignore
  const onSelectApply = route.params["onSelectApply"];
  // @ts-ignore
  const beanTask = route.params["beanTask"];
  // @ts-ignore
  const result = route.params["result"];
  const [searchKey, setSearchKey] = useState("");
  const [data, setData] = useState();
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState("");
  const [selected, setSelected] = useState(usersSelected);

  useEffect(() => {
    if (beanTask == null) {
      setTitle("Chọn người dùng để phân công");
    } else {
      if (!isNullOrEmpty(result)) // Văn bản đi
      {
        if (result == "Chuyển xử lý")
          setTitle("Chọn người dùng");
        else
          setTitle("Chọn người được yêu cầu bổ sung");
      }
    }
  }, []);

  useEffect(() => {
    getData();
  }, [searchKey]);

  const getData = async () => {
    setLoading(true);
    let dataQuery;
    if (beanTask != undefined && beanTask != null) {
      let usersDefault = await DbServices.getInstance().getBeanUserRepository().executeQuery(
        "SELECT ID_SQL,AccountID, Title,ImagePath,Name,Position FROM BeanUser ORDER BY Title"
      );
      if (usersDefault != null && usersDefault.length > 0) {
        const lstGroup = await DbServices.getInstance().getBeanGroupRepository().executeQuery("SELECT ID,Title,Name FROM BeanGroup ");
        const lstMapGroupToUSer = lstGroup.map(item => ({
          Title: item.Title,
          Name: item.Name,
          UserType: 1,
          AccountID: item.ID
        }));
        // @ts-ignore
        dataQuery = usersDefault.concat(lstMapGroupToUSer);
      }
    } else {
      if (!isNullOrEmpty(result))// Văn bản đi
      {
        if (result == "Chuyển xử lý") {
          // @ts-ignore
          dataQuery = await DbServices.getInstance().getBeanUserRepository().executeQuery(
            "SELECT ID_SQL,AccountID, Title,ImagePath,Name,Position FROM BeanUser ORDER BY Title "
          );
        } else // Bổ sung thông tin
        {
          // @ts-ignore
          dataQuery = await DbServices.getInstance().getBeanUserRepository().executeQuery(
            `SELECT ID_SQL, AccountID, Title, ImagePath, Name, Position
             FROM BeanUser
             WHERE Name IN (${result})
             ORDER BY Title`
          );
        }
      } else {
        let usersDefault = await DbServices.getInstance().getBeanUserRepository().executeQuery(
          "SELECT ID_SQL,AccountID,Title,ImagePath,Name,Position FROM BeanUser ORDER BY Title "
        );
        if (usersDefault != null && usersDefault.length > 0) {
          const lstGroup = await DbServices.getInstance().getBeanGroupRepository().executeQuery(
            "SELECT ID,Title,Name FROM BeanGroup ");
          const lstMapGroupToUSer = lstGroup.map(item => ({
            Title: item.Title,
            Name: item.Name,
            UserType: 1,
            AccountID: item.ID
          }));
          // @ts-ignore
          dataQuery = usersDefault.concat(lstMapGroupToUSer);
        }
      }
    }

    if (dataQuery != undefined && !isNullOrEmpty(searchKey))
      dataQuery = dataQuery.filter(item =>
        (item.Title != undefined && removeSignVietnamese(item.Title.toLowerCase()).includes(removeSignVietnamese(searchKey.toLowerCase()))) ||
        (item.Name != undefined && removeSignVietnamese(item.Name.toLowerCase()).includes(removeSignVietnamese(searchKey.toLowerCase()))) ||
        (item.Email != undefined && removeSignVietnamese(item.Email.toLowerCase()).includes(removeSignVietnamese(searchKey.toLowerCase()))) ||
        (item.AccountName != undefined && removeSignVietnamese(item.AccountName.toLowerCase()).includes(removeSignVietnamese(searchKey.toLowerCase())))
      );
    // @ts-ignore
    setData(dataQuery);
    setLoading(false);
  };

  // @ts-ignore
  const submitAction = () => {
    onSelectApply(selected);
    navigation.goBack();
  };

  // @ts-ignore
  const renderItem = ({ item, index }) => {
    const checkSelect = () => {
      return selected.find((itemDatta: { Title: any; }) => itemDatta.Title == item.Title) == undefined;
    };
    return <Pressable
      onPress={() => {
        if (isSingleChoose) {
          console.log("Chọn item nè", JSON.stringify(item))
          onSelectApply(item)
          navigation.goBack();
        }
        else {
          if (selected != undefined) {
            // @ts-ignore
            if (selected.find((itemDatta: { Title: any; }) => itemDatta.Title == item.Title) == undefined) {
              // @ts-ignore
              setSelected((prevData) => [...prevData, item]);
            } else {
              // @ts-ignore
              const difItem = selected.filter(itemDatta => itemDatta.Title != item.Title);
              setSelected(difItem);
            }
          } else { // @ts-ignore
            setSelected([item]);
          }
        }
      }}
      style={{ padding: 16, backgroundColor: getListItemBackground(index % 2 != 0), flexDirection: "row" }}>
      {
        item.UserType != 1 ? <CustomFastImage
          urlOnline={getFullLink() + item.ImagePath}
          defaultImage={require("../../../assets/images/avatar80.jpg")}
          styleImg={{ height: 50, width: 50, borderRadius: 100, marginRight: 10 }}
          resizeMode={"contain"} /> :
          <View style={{
            borderRadius: 100,
            backgroundColor: getRandomColor(),
            height: 50,
            width: 50,
            alignItems: "center",
            justifyContent: "center",
            marginRight: 10
          }}>
            <Text style={{ color: 'white' }}>{getInitials(item.Title)}</Text>
          </View>
      }
      <View style={{ flex: 1 }}>
        <Text style={{ flex: 1, color: "black" }}>{item.Title}</Text>
        {
          !isNullOrEmpty(item.Position) &&
          <Text style={{ flex: 1 }}>{item.Position.includes(";#") ? item.Position.split(";#")[1] : item.Position}</Text>
        }
      </View>
      {
        typeSelect == TypeSelectUser.Multiple && <Image style={{ height: 20, width: 20, marginRight: 10 }}
          source={checkSelect() ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />

      }
    </Pressable>;
  };
  // console.log("item", selected);

  return <View style={{ flex: 1 }}>
    <ModalTopBar
      title={title}
      onPress={() => {
        navigation.goBack();
      }} />
    <View style={{ flex: 1 }}>
      <TextInput
        placeholder={"Tìm kiếm"}
        value={searchKey}
        onChangeText={setSearchKey}
      />
      {
        data != undefined ?
          <FlatList
            data={data}
            renderItem={renderItem}
          /> :
          loading ?
            <ActivityIndicator size="large" color={appMainBlueColor} /> :
            <EmptyView />
      }
    </View>
    {
      !isSingleChoose && <View style={{ height: 50, flexDirection: "row" }}>
        <View style={{ flex: 1 }}></View>
        <View style={{ flex: 1, padding: 5 }}>
          <Pressable
            onPress={() => {
              submitAction();
            }}
            style={{
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: appMainBlueColor,
              padding: 10,
              borderRadius: 5
            }}>
            <Text style={{ color: "white" }}>Chọn</Text>
          </Pressable>
        </View>
      </View>
    }

  </View>;
};
