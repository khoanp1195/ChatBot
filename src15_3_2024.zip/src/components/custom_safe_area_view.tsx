import { SafeAreaView, View } from "react-native";

// @ts-ignore
const CustomSafeAreaView = ({ children = <View /> }) => {
  return <SafeAreaView style={{ marginBottom: 120 }}>
    {children}
  </SafeAreaView>
}
export default CustomSafeAreaView;
