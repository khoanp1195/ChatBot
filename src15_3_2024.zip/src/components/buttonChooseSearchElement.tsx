import { Image, Pressable, StyleSheet, Text, View } from "react-native"
import moment from 'moment';
import { CircleButton } from "./circleButton";
import React from "react";

// @ts-ignore
export const BtnChooseEle = ({ title, onClickHandle, valueText, imgPath, imgColor = 'grey' }) => {
    moment.locale('en');

    return (
        <View style={[styles.rootContainer]}>
            <Text style={[styles.title]} lineBreakMode={'tail'}>{title}</Text>
            <Pressable
                style={[styles.parentContainer]}
                onPress={() => {
                    onClickHandle()
                }}>
                <View style={[styles.button]}>
                    <Text style={[styles.text]} lineBreakMode={'tail'}>{valueText}</Text>

                    {
                      imgPath != null && <Image
                        source={imgPath}
                        style={[styles.circle]}
                        resizeMode='contain'
                        tintColor={imgColor}
                      />
                    }
                </View>
            </Pressable >
        </View>
    );
};

const styles = StyleSheet.create({
    rootContainer: {
        flex: 1,
    },
    title: {
        flex: 1,
        fontSize: 13,
        marginVertical:5
    },
    parentContainer: {
        height:40
    },
    button: {
        flex: 1,
        flexDirection: "row",
        paddingHorizontal: 5,
        borderWidth: 1,
        borderRadius: 6,
        borderColor: 'lightgrey',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5,
    },
    text: {
        flex: 1,
        fontSize: 13,
    },

    circle: {
        height: 15,
        width: 15,
        paddingVertical: 5,
    },
});
