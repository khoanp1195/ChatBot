import * as types from './action_types.ts';

export const showLeftMenuHome = () => ({
  type: types.HOME,
});

export const showLeftMenuCalendar = () => ({
  type: types.CALENDAR,
});


export const showLeftMenuUtilities = () => ({
  type: types.UTILITIES,
});

export const showLeftMenuTinNoiBo = () => ({
  type: types.LeftMenuTinNoiBo,
});
export const showLeftMenuVeMayBay = () => ({
  type: types.LeftMenuVeMayBay,
});
export const showLeftMenuDangKyXuatAn = () => ({
  type: types.LeftMenuDangKyXuatAn,
});
