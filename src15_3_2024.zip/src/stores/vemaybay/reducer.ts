import { CHANGEPAGE_VEMAYBAY } from "./action_types.ts";
import { TypeDatVeMayBay } from "../../config/enum.ts";

const initialState = {
  item: TypeDatVeMayBay.PhieuToiTao,
};

const typeVeMayBayReducer = (state = initialState, action: { type: any; payload: { id: any; }; }) => {
  switch (action.type) {
    case CHANGEPAGE_VEMAYBAY:
      return {
        ...state,
        item: action.payload,
      };
    default:
      return state;
  }
};

export default typeVeMayBayReducer;
