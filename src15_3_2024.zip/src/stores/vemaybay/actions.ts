import * as types from './action_types.ts';

export const changePageTypeVeMayBay = (item:any) => ({
  type: types.CHANGEPAGE_VEMAYBAY,
  payload: item
});

