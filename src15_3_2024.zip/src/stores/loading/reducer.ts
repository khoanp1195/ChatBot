import * as types from './action_types.ts';
const initialState = {
  onLoading: false,
};

const loadingReducer = (
  state = initialState,
  action: {type: any; payload: any},
) => {
  switch (action.type) {
    case types.START_CHANGE_SITE:
      return {...state, onLoading:true};
    case types.END_CHANGE_SITE:
      return {...state, onLoading:false};
    default:
      return state;
  }
};

export default loadingReducer;
