import { ActivityIndicator, Pressable, Text, View } from "react-native";
import { appMainBlueColor } from "../utils/color.ts";

export const LoadingScreen=()=>{
  return <Pressable style={{width:'100%',height:'100%',position:'absolute'}}>
    <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'#19191EB2'}}>
      <ActivityIndicator size="large" color={appMainBlueColor} />
    </View>
  </Pressable>
}
