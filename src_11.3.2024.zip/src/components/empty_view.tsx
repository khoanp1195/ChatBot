import React, {FC} from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';


interface Props {
  onRetryPress?: () => any;
}

const EmptyView: FC<Props> = (props: Props) => {
  return (
    <View style={styles.viewNoData}>
      <Text style={styles.textNoData}>Không có dữ liệu</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#5E5E5E',
    fontStyle:'italic'
  },
});

export default React.memo(EmptyView);
