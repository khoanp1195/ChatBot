import { Image, PixelRatio, Pressable, StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-elements";
import { ImageBackground } from "react-native";

// @ts-ignore
export const DashBoardButton = ({ path, title, countNum, countNumColor, handleClick }) => {

  return (
    <Pressable
      style={styles.container}
      onPress={() => {
        // handle
        if (__DEV__)
          console.log("btn is pressed.");
        handleClick();
      }}>
      <View
        style={{
          flexDirection: "column",
          flex: 1,
          width: "100%"

        }}>

        <View
          style={{
            flexDirection: "row",
            flex: 4,
            alignItems: "center",
          }}>

          <View style={{
            flex: 1,
            alignSelf: "flex-end",
          }}>
            <Text
            numberOfLines={1}
              style={{
                textAlign: "left",
                fontSize: 40,
                fontWeight: "bold",
                color: countNumColor,
                aspectRatio: 1,
                width: "80%",
                textAlignVertical:'bottom'
              }}>
              {countNum}
            </Text>
          </View>

          <Image
            source={path}
            style={styles.square}
            resizeMode='stretch'
          />
        </View>

        <Text
          style={{
            textAlign: "left",
            fontSize: 16,
            flex: 1,
            // marginLeft: 5,
            // marginRight:5,
            // marginTop: 0,
            // marginBottom: 10
          }}>
          {title}
        </Text>

      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    margin: 10
  },

  square: {
    width: "40%",
    aspectRatio: 1,
    // flex: 1,
    // alignItems: "center",
    // justifyContent: "center",
    marginTop: 5,
    // marginBottom: 10,
    alignSelf: "flex-start",
  }
});
