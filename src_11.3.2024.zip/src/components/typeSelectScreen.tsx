import { FlatList, Image, Text, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../components/modalTopBar.tsx";
import { getInitials, getRandomColor } from "../utils/functions.ts";
import { Index } from "typeorm";

// @ts-ignore
export const TypeSelectScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  // @ts-ignore
  const data = route.params["data"];
  // @ts-ignore
  const onSelected = route.params["onSelected"];
  // @ts-ignore
  const title = route.params["title"];
  // @ts-ignore
  const selectedTitle = route.params["selectedTitle"];

  // @ts-ignore
  const enableAvatar = route.params["enableAvatar"];
  // @ts-ignore
  const isSimpleSelection = route.params["isSimpleSelectView"] ?? false;
  if (__DEV__)
    console.log(isSimpleSelection ? "Hiện kiểu đơn giản" : "Hiện list user", "chuỗi data nè:", JSON.stringify(data), "Cần focus:", selectedTitle)

  const closeView = () => {
    navigation.goBack();
  }
  // @ts-ignore
  const RenderSimpleItem = ({ item, index }) => {

    return <TouchableOpacity style={{
      backgroundColor: index % 2 != 0 ? "white" : "#F3F9FF",
      flexDirection: "row",
      height: 40,
      alignItems: 'center',
      marginHorizontal: 10,
    }}
      onPress={() => {
        // @ts-ignore
        onSelected(item)
        closeView();
      }}
    >
      <Text style={{ color: "black", flex: 1, marginHorizontal: 10 }}
      >{item}</Text>
      {
        selectedTitle.toString().toLowerCase() == item.toString().toLowerCase() &&
        <Image style={{ height: 15, width: 15, marginRight: 10 }} source={require("../assets/images/icon_checkEvaluated.png")} />
      }
    </TouchableOpacity>;
  };

  // @ts-ignore
  const RenderUserItem = ({ info }) => {

    return <TouchableOpacity
      style={{
        padding: 10,
        backgroundColor: info.index % 2 == 0 ? "white" : "#F3F9FF",
        flexDirection: "row",
        alignItems: "center"
      }}
      onPress={() => {
        onSelected(info.item);
        closeView();
      }}
    >
      {
        enableAvatar && <View style={{
          borderRadius: 20,
          backgroundColor: getRandomColor(),
          height: 40,
          width: 40,
          alignItems: "center",
          justifyContent: "center"
        }}>
          <Text style={{ color: 'white' }}>{getInitials(info.item.Title)}</Text>
        </View>
      }

      <Text style={{ color: "black", flex: 1, paddingLeft: 10 }}>{info.item.Title}</Text>

      {
        selectedTitle.toString().toLowerCase() == info.item.Title.toString().toLowerCase() &&
        <Image style={{ height: 15, width: 15 }} source={require("../assets/images/icon_checkEvaluated.png")} />

      }

    </TouchableOpacity>
  }

  return <View style={{
    marginBottom: 15,
    flex: 1,
    backgroundColor: "white"
  }}>
    <ModalTopBar onPress={() => {
      navigation.goBack();
    }}
      title={title}
    />

    {
      isSimpleSelection ?
        <FlatList
          data={data}
          keyExtractor={({ item, index }) => index}
          renderItem={({ item, index }) => (
            <RenderSimpleItem item={item} index={index} />
          )}
        />
        :
        <FlatList
          data={data}
          keyExtractor={({ item, index }) => index}
          renderItem={(infor) => (
            <RenderUserItem info={infor} />
          )} />
    }
  </View>;
};