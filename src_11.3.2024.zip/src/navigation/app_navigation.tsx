import React, { useEffect } from "react";
import { createStackNavigator } from "@react-navigation/stack";
import { BottomNavigation } from "./bottom_navigation.tsx";
import { VBDenDetailScreen } from "../screens/details/docs/vbden/vbden_detail_screen.tsx";
import { VBDiDetailScreen } from "../screens/details/docs/vbdi/vbdi_detail_screen.tsx";
import { VBBHDetailScreen } from "../screens/details/docs/vbbh/vbbh_detail_screen.tsx";
import { ContactsScreen } from "../screens/utilities/contacts/contacts_screen.tsx";
import { ChooseContactUnitScreen } from "../screens/utilities/contacts/chooseContactUnit_screen.tsx";
import { DetailHSTLScreen } from "../screens/details/docs/hstl/detail_hstl_screen.tsx";
import { QRScreen } from "../screens/qrcode/qr_screen.tsx";
import { AttachmentDetailView } from "../screens/details/docs/attachmentDetailView.tsx";
import { DetailCalendarScreen } from "../screens/details/calendar/detailCalendarScreen.tsx";
import { TypeSelectScreen } from "../components/typeSelectScreen.tsx";
import { RootWorkflowHistory } from "../screens/details/docs/workflowHistory/rootWorkflowHistory.tsx";
import { WorkflowOtherDepartment } from "../screens/details/docs/workflowHistory/workflowOtherDepartment.tsx";
import { WorkflowHistoryVBDi } from "../screens/details/docs/workflowHistory/workflowHistoryVBDi.tsx";
import { SelectUserScreen } from "../screens/details/popup/selectUserScreen.tsx";
import { RecallOrForwardScreen } from "../screens/details/popup/recallOrForwardScreen.tsx";
import { SelectDepartmentScreen } from "../screens/details/popup/selectDepartmentScreen.tsx";
import { ReassignScreen } from "../screens/details/popup/reassignScreen.tsx";
import { AssignScreen } from "../screens/details/popup/assignScreen.tsx";
import { AssignTaskScreen } from "../screens/details/popup/assignTaskScreen.tsx";
import { AssignTreeView } from "../screens/details/popup/assignTreeView.tsx";
import { AnCaScreen } from "../screens/utilities/SuatAn/anCaScreen.tsx";
import { DetailXuatAnScreen } from "../screens/utilities/SuatAn/detailXuatAnScreen.tsx";
import { BaoCaoThongMinhScreen } from "../screens/utilities/BaoCaoThongMinh/baoCaoThongMinhScreen.tsx";
import { DetailTinNoiBoScreen } from "../screens/utilities/tinnoibo/detailTinNoiBoScreen.tsx";
import { DetailDatVeMayBayScreen } from "../screens/utilities/datvemaybay/detailDatVeMayBayScreen.tsx";
import { useNavigation } from "@react-navigation/native";
import { TaskDetailScreen } from "../screens/details/docs/task/taskDetailScreen.tsx";
import { NhiemVuDaPhanCongView } from "../screens/details/docs/task/nhiemVuDaPhanCongView.tsx";
import { UtilitiesScreen } from "../screens/utilities/utilities_screen.tsx"
import { DashboardHSSKScreen } from "../screens/utilities/hssk/dashboardHSSKScreen.tsx";
import { DetailHSSKScreen } from "../screens/utilities/hssk/detailHSSKScreen.tsx";
import { ShareScreen } from "../screens/details/popup/shareScreen.tsx";
import { RooTaskScreen } from "../screens/details/docs/task/rootTask.tsx";
import { Calendar_unit } from "../screens/calendar/calendar_unit.tsx";
import { Participant_Screen } from "../screens/calendar/participant_screen.tsx"

const Stack = createStackNavigator();
export const AppNavigation = () => {
  return (
    <Stack.Navigator initialRouteName="BottomNavigation">
      <Stack.Screen
        name="BottomNavigation"
        component={BottomNavigation}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="VBDenDetailScreen"
        // @ts-ignore
        component={VBDenDetailScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="VBDiDetailScreen"
        // @ts-ignore
        component={VBDiDetailScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="VBBHDetailScreen"
        // @ts-ignore
        component={VBBHDetailScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ContactsScreen"
        // @ts-ignore
        component={ContactsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ChooseContactUnitScreen"
        // @ts-ignore
        component={ChooseContactUnitScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DetailHSTLScreen"
        // @ts-ignore
        component={DetailHSTLScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="QRScreen"
        // @ts-ignore
        component={QRScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="AttachmentDetailView"
        // @ts-ignore
        component={AttachmentDetailView}
        options={{ headerShown: false }}
      />
        {/* <Stack.Screen
        name="DetailCalendarScreen"
        // @ts-ignore
        component={DetailCalendarScreen}
        options={{ headerShown: false }}
      /> */} 
      <Stack.Screen
        name="TypeSelectScreen"
        // @ts-ignore
        component={TypeSelectScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="RootWorkflowHistory"
        // @ts-ignore
        component={RootWorkflowHistory}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="WorkflowOtherDepartment"
        // @ts-ignore
        component={WorkflowOtherDepartment}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="WorkflowHistoryVBDi"
        // @ts-ignore
        component={WorkflowHistoryVBDi}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="SelectUserScreen"
        // @ts-ignore
        component={SelectUserScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="RecallOrForwardScreen"
        // @ts-ignore
        component={RecallOrForwardScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="SelectDepartmentScreen"
        // @ts-ignore
        component={SelectDepartmentScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ReassignScreen"
        // @ts-ignore
        component={ReassignScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="AssignScreen"
        // @ts-ignore
        component={AssignScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="AssignTreeView"
        // @ts-ignore
        component={AssignTreeView}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="AnCaScreen"
        // @ts-ignore
        component={AnCaScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DetailXuatAnScreen"
        // @ts-ignore
        component={DetailXuatAnScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="BaoCaoThongMinhScreen"
        // @ts-ignore
        component={BaoCaoThongMinhScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DetailTinNoiBoScreen"
        // @ts-ignore
        component={DetailTinNoiBoScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DetailDatVeMayBayScreen"
        // @ts-ignore
        component={DetailDatVeMayBayScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="TaskDetailScreen"
        // @ts-ignore
        component={TaskDetailScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="NhiemVuDaPhanCongView"
        // @ts-ignore
        component={NhiemVuDaPhanCongView}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DashboardHSSKScreen"
        // @ts-ignore
        component={DashboardHSSKScreen}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="AssignTaskScreen"
        // @ts-ignore
        component={AssignTaskScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="DetailHSSKScreen"
        // @ts-ignore
        component={DetailHSSKScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ShareScreen"
        // @ts-ignore
        component={ShareScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="RooTaskScreen"
        //@ts-ignore
        component={RooTaskScreen}
        options={{ headerShown: false }}
      />

      
         <Stack.Screen
        name="DetailCalendarScreen"
        //@ts-ignore
        component={DetailCalendarScreen}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="Calendar_unit"
        //@ts-ignore
        component={Calendar_unit}
        options={{ headerShown: false }}
      />
   <Stack.Screen
        name="Participant_Screen"
        //@ts-ignore
        component={Participant_Screen}
        options={{ headerShown: false }}
      />
      
    </Stack.Navigator>
  );
};

