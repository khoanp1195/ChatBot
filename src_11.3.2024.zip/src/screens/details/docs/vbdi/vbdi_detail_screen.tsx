import { Image, Platform, Pressable, Text, TouchableOpacity, View } from "react-native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import { useEffect, useState } from "react";
import { GetDetailHoSoluuTru, getAttFileVBDi, getDetailVBDi, getIdeaOfBODv2 } from "../../../../services/api/apiDetailVBDi.ts";
import { showAlert } from "../../../commonAlertView.jsx";
import { BeanVBDi } from "../../../../services/database/models/beanVBDi.ts";
import { RootFormVBDi } from "./form/rootFormVBDi.tsx";
import { HeaderValueTextView } from "../../../../components/headerValueTextView.tsx";
import { ClassActionTasks } from "../../../../services/database/models/classActionTasks.ts";
import { BottomAction } from "../../../../components/bottomAction.tsx";
import { isNullOrEmpty, mapActionVBDen, mapActionVBDi } from "../../../../utils/functions.ts";
import { ListAttachment } from "../../docDetail/listAttachment.jsx";
import { downloadFile } from "../../../../services/api/api_client.ts";
import { openFile } from "../../../../utils/fileUtil.ts";
import { EnumVanBanDenAction, WorkflowAction } from "../../../../config/enum.ts";
import { RootPopUpContainer } from "../../popup/rootPopUpContainer.tsx";
import { MoreAction } from "../../popup/moreAction.tsx";
import { ListIdea } from "../../docDetail/listIdea.jsx";
import { CustomImageButton } from "../../../../components/customImageButton.tsx";
import { appMainBlueColor } from "../../../../utils/color.ts";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { BeanHSLT } from "../../../../services/database/models/beanHSLT.ts";

// @ts-ignore
export const VBDiDetailScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const [detailVBDI, setDetailVBDI] = useState<BeanVBDi>();
  const [lstAction, setListAction] = useState<ClassActionTasks[] | null>([new ClassActionTasks(2048, "Chia sẻ", 999, "", true, 2048, "VBDi")]);
  const [attFile, setAttFile] = useState<[]>();
  const [iDeaOfBOD, setIDeaOfBOD] = useState<[]>();
  const [isShowMoreAction, setShowMoreAction] = useState(false);
  const [isShowPopup, setShowPopup] = useState(false);
  const [indexAction, setIndexAction] = useState(0);
  const [isViewDetail, setIsViewDetail] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [HSLT,setHSLT]=useState<BeanHSLT>();
  const handlePressShowAction = (index: number) => {
    switch (index) {
      case 0:
        setShowMoreAction(true);
        break;
      case WorkflowAction.Share:
        //@ts-ignore
        navigation.navigate("ShareScreen",
          {
            item: detailVBDI,
            type: "VBDi"
          });
        return;
      case WorkflowAction.Reject:
      case WorkflowAction.Next:
      case WorkflowAction.Approve:
      case WorkflowAction.Forward:
      case WorkflowAction.Return:
      case WorkflowAction.RequestInformation:
      case WorkflowAction.Recall:
        setIndexAction(index);
        setShowPopup(true);
        break;


    }
  };


  // @ts-ignore
  const item = route.params["item"];
  useEffect(() => {
    // @ts-ignore
    getDetailVBDi(item.DocumentID ?? item.ID).then(value => {
      setIsLoading(false);
      if (value != null) {
        setDetailVBDI(value);
        getIdeaOfBODv2(value.ID, value.SPItemId, value.SPListId).then(value => setIDeaOfBOD(value));
        const lstActionTemp = JSON.parse(value.ActionJson);
        if (lstAction && lstAction.length == 1) {
          setListAction(mapActionVBDi([...lstAction, ...lstActionTemp]));
        }
        if(value.HoSoKT!=undefined && !isNullOrEmpty(value.HoSoKT))
        {
          const idHSLT=parseInt(value.HoSoKT.includes(";#")?value.HoSoKT.split(";#")[0]:value.HoSoKT);
          GetDetailHoSoluuTru(idHSLT).then(value=>{
            if(value!=null &&value.length>0)
            {
              setHSLT(value[0]);
            }
          })
        }

      }
      else {
        showAlert("Bạn không có quyền truy cập phiếu này hoặc phiếu không tồn tại", true, () => {
          navigation.goBack();
        })
      }
    });
    getAttFileVBDi(item.DocumentID ?? item.ID).then(value => setAttFile(value));
  }, []);
  //@ts-ignore
  const onClickAttachment = (item) => {
    if (__DEV__)
      console.log("onClickAttachment", item);
    if (Platform.OS == "ios") {
      //@ts-ignore
      navigation.navigate('AttachmentDetailView', { item })
    }
    else {
      downloadFile(item.Path).then(filePath => {
        openFile(filePath);
      })
    }
  };
  const goToDetailHSLT=()=>{
    if(HSLT!=undefined && HSLT!=null)
    {
      const item=HSLT;
      //@ts-ignore
      navigation.navigate("DetailHSTLScreen", {item});
    }
  }
  return <View style={{ flex: 1, backgroundColor: 'white' }}>
    <ModalTopBar
      title={""}
      rightAction={<TouchableOpacity onPress={() => {
        // @ts-ignore
        navigation.navigate("WorkflowHistoryVBDi", {
          itemVB: detailVBDI
        });
      }}>
        <Image style={{ height: 25, width: 25 }} resizeMode={"stretch"}
          source={require("../../../../assets/images/icon_proce.png")} />
      </TouchableOpacity>}
      onPress={() => {
        navigation.goBack();
      }} />
    <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row", backgroundColor: '#F5F5F5' }}>
      <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>{detailVBDI?.Subject}</Text>
    </View>
    <ScrollView style={{ flex: 1 }}>
      <View style={{ padding: 10, flex: 1 }}>
        {
          (detailVBDI != undefined && isViewDetail) &&
          <View>
            <RootFormVBDi dataForm={detailVBDI} />
            <Pressable onPress={goToDetailHSLT}>
            {
              detailVBDI && <HeaderValueTextView headerText="Hồ sơ kèm theo" valueText={HSLT!=undefined ?HSLT.TenHoSo:""} />
            }
            </Pressable>
          </View>
        }
        {
          attFile != null && attFile.length > 0 ?
            <ListAttachment data={attFile} onClick={(item: any) => onClickAttachment(item)} doHideHeader={false} />
            : null
        }
        {
          iDeaOfBOD != null && iDeaOfBOD.length > 0 && <ListIdea data={iDeaOfBOD} doHideHeader={false} isBODIdea={false} />
        }
        <View style={{
          width: 50,
          height: 40,
          position: "absolute",
          top: 0,
          right: 0
          // justifyContent: 'flex-end',
        }}>
          <CustomImageButton imgPath={require("../../../../assets/images/icon_more_detail.png")}
            //@ts-ignore
            imgColor={isViewDetail ? appMainBlueColor : "black"} onClickHandle={() => {
              setIsViewDetail(!isViewDetail);
            }} />
        </View>
      </View>
    </ScrollView>
    {
      //@ts-ignore
      lstAction != undefined && lstAction.length > 0 &&
      <View style={{ width: "100%", height: 60 }}>
        <BottomAction data={lstAction} onPressAction={handlePressShowAction} />
      </View>
    }
    {
      isShowMoreAction && <MoreAction actionJson={lstAction} onPressAcion={handlePressShowAction}
        onPressCancel={() => setShowMoreAction(false)} />
    }
    {
      isShowPopup && <RootPopUpContainer
        type={"VBDi"}
        //@ts-ignore
        action={lstAction.find(item => item.ID == indexAction)}
        cancelPress={() => setShowPopup(false)}
        //@ts-ignore
        itemVB={detailVBDI}
      />
    }
    {
      isLoading && <LoadingScreen />
    }
  </View>
}
