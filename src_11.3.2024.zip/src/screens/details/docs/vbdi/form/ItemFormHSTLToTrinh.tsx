import { FC } from "react"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { Text,View } from "react-native";
import RowSpaceBetween from "../../../../../components/rowSpaceBetween";
import { HeaderValueTextView } from "../../../../../components/headerValueTextView";
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions";

interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLToTrinh:FC<Props>=({dataForm})=>{
    return <View>
        <RowSpaceBetween>
            <HeaderValueTextView headerText={"Số văn bản"} valueText={isNullOrEmpty(dataForm.DocumentName)?"":dataForm.DocumentName}/>
            <HeaderValueTextView headerText={"Loại văn bản"} valueText={isNullOrEmpty(dataForm.CodeDocumentTypeTitle)?"":dataForm.CodeDocumentTypeTitle}/>
        </RowSpaceBetween>
        <HeaderValueTextView headerText="Ngày trình duyệt" valueText={dataForm.EffectiveDate!=null?convertStringToMoment(dataForm.EffectiveDate).format("DD/MM/YY"):""}/>
        <HeaderValueTextView headerText="Đơn vị soạn thảo" valueText={isNullOrEmpty(dataForm.DepartmentTitle)?"":dataForm.DepartmentTitle}/>
    </View>

}