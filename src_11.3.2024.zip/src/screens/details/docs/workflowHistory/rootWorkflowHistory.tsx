import React, { useEffect, useState } from "react";
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import { mapLstDataIntoListSection } from "../../../../utils/functions.ts";
import { WorkflowHistoryScreen } from "../../../../screens/details/docs/workflowHistory/workflowHistoryScreen.tsx";
import EmptyView from "../../../../components/empty_view.tsx";
import {
  getVBDenWorkflowHistory,
  getViewerVBDen,
  getWorkflowHistoryOtherDepartment,
} from "services/api/apiDetailVBDen.ts";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { ViewerScreen } from "../workflowHistory/viewerScreen.tsx";
import { OtherDepartmentScreen } from "../../../../screens/details/docs/workflowHistory/otherDepartmentScreen.tsx";

export const RootWorkflowHistory = () => {
  const route = useRoute();
  const navigation = useNavigation();
  // @ts-ignore
  const getWorkflowHistory = route.params["getWorkflowHistory"];
  // @ts-ignore
  const getViewer = route.params["getViewer"];
  // @ts-ignore
  const getOtherDepartment = route.params["getOtherDepartment"];
  // @ts-ignore
  const isVBDen = route.params["isVBDen"];
  // @ts-ignore
  const itemVB = route.params["itemVB"];

  const tabs = [
    { title: "Thông tin luân chuyển" },
    { title: "Danh sách người xem" },
    { title: "Thông tin đơn vị nhận" },
  ];

  const [workflowHistory, setWorkflowHistory] = useState();
  const [viewer, setViewer] = useState();
  const [otherDepartment, setOtherDepartment] = useState<[]>();
  const [index, setIndex] = useState(0);

  useEffect(() => {
    getWorkflowHistory().then((value: any) => {
      const dataMap = mapLstDataIntoListSection(value, "Position");
      // @ts-ignore
      setWorkflowHistory(dataMap);
      console.log(JSON.stringify(workflowHistory));
    });
    getViewer().then((value: any) => {
      setViewer(value);
    });
    getOtherDepartment().then((value: any) => {
      setOtherDepartment(value);
    });
  }, []);

  const ContentView = () => {
    if (index === 0 && workflowHistory !== undefined) {
      return <WorkflowHistoryScreen data={workflowHistory} />;
    } else if (index === 1 && viewer !== undefined) {
      return <ViewerScreen data={viewer} />;
    } else {
      if (index === 2 && otherDepartment !== undefined && otherDepartment!=null && otherDepartment.length > 0) {
        return (
          <OtherDepartmentScreen
            data={otherDepartment}
            isVBDen={isVBDen}
            itemVB={itemVB}
          />
        );
      } else {
        return <EmptyView />;
      }
    }
  };

  return (
    <View style={styles.container}>
      <ModalTopBar
        title={""}
        onPress={() => {
          navigation.goBack();
        }}
      />
      <View style={styles.tabContainer}>
        <ScrollView     horizontal={true}>
          <Tab
            value={index}
            onChange={(index) => {
              setIndex(index);
            }}
            indicatorStyle={styles.tabIndicatorStyle}
          >
            {tabs.map((tab, index) => (
              <Tab.Item
                key={index}
                title={tab.title}
                containerStyle={{ backgroundColor: "white" }}
                titleStyle={{
                  fontSize: 12,
                  color: "#000000",
                }}
              />
            ))}
          </Tab>
        </ScrollView>
      </View>
      <View style={styles.container}>
        <ContentView />
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabContainer: {
    height: 50,
  },
  tabIndicatorStyle: {
    backgroundColor: "#0072C6",
    height: 3,
    borderRadius: 100,
    marginHorizontal: 4,
  },
});

