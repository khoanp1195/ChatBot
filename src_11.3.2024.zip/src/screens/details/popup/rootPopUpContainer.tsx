import { Image, Pressable, Text, TextInput, View } from "react-native";
import { getRequireImageAction, isNullOrEmpty } from "../../../utils/functions.ts";
import { EnumVanBanDenAction, TypeSelectUser, WorkflowAction } from "../../../config/enum.ts";
import { FC, useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { DbServices } from "../../../services/database/db_service.ts";
import { subsiteStore } from "../../../config/constants.ts";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { useDispatch, useSelector } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { redirectScreen } from "../../../stores/base_screen/actions.ts";
import { PopUpActionAceptVBDi } from "./popUpActionAceptVBDi.tsx";
import { FormOnlyComment } from "./formOnlyComment.tsx";
import { BeanUser } from "../../../services/database/models/bean_user.ts";
import { ActionHoSoTaiLieu } from "../../../services/api/apiDetailVBDi.ts";
import { PopupActionSelectUserAndComment } from "./PopupActionChuyenXuLy.tsx";
import { ClassActionTasks } from "../../../services/database/models/classActionTasks.ts";
import { BeanVanBanDen } from "../../../services/database/models/beanVanBanDen.ts";
import { BeanVBDi } from "../../../services/database/models/beanVBDi.ts";
import { BeanVBBH } from "../../../services/database/models/beanVBBH.ts";

interface Props {
  action: ClassActionTasks;
  cancelPress: any;
  itemVB: BeanVanBanDen | BeanVBDi | BeanVBBH;
  type: string
}
export const RootPopUpContainer: FC<Props> = ({ action, cancelPress, itemVB, type }) => {
  // const screen = useSelector((state: any) => state.baseScreen.screen.toString());

  const dispatch = useDispatch();
  const navigation = useNavigation();
  let yKien = "";

  const [isCheckBOD, setIsCheckBOD] = useState(false);
  const [isUuTienCheckBOD, setIsUuTienCheckBOD] = useState(false);
  const [bodSelectTed, setBODSelected] = useState();
  const [bodCCSelectTed, setBODCCSelected] = useState<[]>();

  const [isCheckCVPTPTH, setIsCheckCVPTPTH] = useState(false);
  const [isUuTienCheckCVPTPTH, setIsUuTienCheckCVPTPTH] = useState(false);
  const [CVPTPTHSelectTed, setCVPTPTHSelected] = useState();
  const [CVPTPTHCCSelectTed, setCVPTPTHCCSelectTed] = useState<[]>();

  const [selectNDB, setSelectNDB] = useState<BeanUser[]>();
  const [selectUserCXL, setSelectUserCXL] = useState<BeanUser>();
  const ContentOnlyEditText = () => {
    if (type == 'VBDi') {
      switch (action.ID) {
        case WorkflowAction.Recall:
          return <FormOnlyComment isRequire={false} onChangeText={(text: string) => {
            yKien = text;
          }}
            isForce={false}
          />;
        case WorkflowAction.Reject:
        case WorkflowAction.Next:
        case WorkflowAction.Approve:
          return <PopUpActionAceptVBDi onChangeText={(text: string) => {
            yKien = text;
          }}
            //@ts-ignore
            selectedUser={selectNDB}
            //@ts-ignore
            setSelectedUser={setSelectNDB}
            isRequire={false}
          />;
        case WorkflowAction.Forward:
          return <PopupActionSelectUserAndComment onChangeText={(text: string) => {
            yKien = text;
          }}
            //@ts-ignore
            selectedUser={selectUserCXL}
            setSelectedUser={setSelectUserCXL}
            isBSTT={false}
          />
        case WorkflowAction.Return:
          return <PopUpActionAceptVBDi onChangeText={(text: string) => {
            yKien = text;
          }}
            //@ts-ignore
            selectedUser={selectNDB}
            //@ts-ignore
            setSelectedUser={setSelectNDB}
            isRequire={true}
          />;
        case WorkflowAction.RequestInformation:
          return <PopupActionSelectUserAndComment onChangeText={(text: string) => {
            yKien = text;
          }}
            //@ts-ignore
            selectedUser={selectUserCXL}
            setSelectedUser={setSelectUserCXL}
            isBSTT={true}
          />;
      }
    }
    else {
      switch (action.ID) {
        case EnumVanBanDenAction.RecallBOD:
        case EnumVanBanDenAction.Recall:
        case EnumVanBanDenAction.Priority:
          return <View />;
        case EnumVanBanDenAction.Comment:
        case EnumVanBanDenAction.CommentBOD:
        case EnumVanBanDenAction.Forward:
        case EnumVanBanDenAction.FowardArchives:
        case EnumVanBanDenAction.Completed:
          return <FormOnlyComment isRequire={false} onChangeText={(text: string) => {
            yKien = text;
          }}
            isForce={false}
          />;
        case EnumVanBanDenAction.SubmitBOD:
          return <FormSubmitBOD />;
        default:
          return <View />;
      }
    }
  };

  const FormSubmitBOD = () => {
    // @ts-ignore
    const SelectForm = ({ isUuTien, onPressUutien, onBODPress, lanhDaoSelected, onSelectUserCC, userCC }) => {
      return <View style={{ marginLeft: 20, marginTop: 10 }}>
        <Text>Lãnh đạo Công ty</Text>
        <Pressable onPress={() => {
          onBODPress();
        }} style={{
          borderWidth: 1,
          padding: 5,
          marginTop: 10,
          flexDirection: "row",
          borderColor: "#E5E5E5",
          borderRadius: 5
        }}>
          <Text style={{ flex: 1 }}>{lanhDaoSelected}</Text>
          <Image style={{ height: 20, width: 20 }} resizeMode={"contain"}
            source={require("../../../assets/images/icon_user_dropdown.png")} />
        </Pressable>
        <Text style={{ marginTop: 10 }}>CC</Text>
        <Pressable onPress={() => {
          onSelectUserCC();
        }} style={{
          borderWidth: 1,
          padding: 5,
          marginTop: 10,
          flexDirection: "row",
          borderColor: "#E5E5E5",
          borderRadius: 5
        }}>
          <Text style={{ flex: 1 }}>{userCC}</Text>
        </Pressable>
        <Pressable onPress={() => {
          onPressUutien();
        }} style={{ flexDirection: "row", marginTop: 10 }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }}
            source={!isUuTien ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
          <Text>Ưu tiên</Text>
        </Pressable>
      </View>;
    };
    const handlePressCPVSelect = async () => {

      let type = "'" + "Chánh văn phòng" + "'" + "," + "'" + "Trưởng phòng Tổng hợp - HĐQT" + "'";
      // get data by type
      let banLanhDaos = [];
      if (!isNullOrEmpty(subsiteStore.getSubsite())) {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllDifLanhDao(type);
      } else {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllLanhDao(type);
      }
      console.log("type", banLanhDaos);


      // @ts-ignore
      navigation.navigate("TypeSelectScreen",
        {
          title: "Lãnh đạo Công ty",
          data: banLanhDaos,
          enableAvatar: true,
          selectedTitle: CVPTPTHSelectTed != undefined ? CVPTPTHSelectTed["Title"] : "",
          onSelected: (item: any) => {
            setCVPTPTHSelected(item);
          }
        });
    };
    const handlePressBODSelect = async () => {
      let _banLanhDao = (itemVB as BeanVanBanDen).BanLanhDao;
      let type = "";
      if (_banLanhDao.includes(";#")) {
        _banLanhDao = _banLanhDao.split(";#")[0];
      }
      const data = await DbServices.getInstance().getBanLanhDaoRepository().findByLanhDaoID(_banLanhDao);

      if (data != null) {
        // @ts-ignore
        if (data[0].LanhDao == "Chánh văn phòng" || data[0].LanhDao == "Ban TGĐ") {
          type = "'" + "Ban TGĐ" + "'";
        } else
          type = "'" + "HĐQT" + "'";
      }

      // get data by type
      let banLanhDaos = [];
      if (!isNullOrEmpty(subsiteStore.getSubsite())) {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllDifLanhDao(type);
      } else {
        banLanhDaos = await DbServices.getInstance().getBanLanhDaoRepository().findAllLanhDao(type);
      }
      console.log("type", banLanhDaos);


      // @ts-ignore
      navigation.navigate("TypeSelectScreen",
        {
          title: "Lãnh đạo Công ty",
          data: banLanhDaos,
          enableAvatar: true,
          selectedTitle: bodSelectTed != undefined ? bodSelectTed["Title"] : "",
          onSelected: (item: any) => {
            setBODSelected(item);
          }
        });
    };

    return <View>
      <FormOnlyComment isRequire={false} onChangeText={(text: string) => {
        yKien = text;
      }}
        isForce={false}
      />
      <Pressable
        onPress={() => {
          setIsCheckBOD(!isCheckBOD);
          setIsCheckCVPTPTH(false);
          setIsUuTienCheckCVPTPTH(false);
          setCVPTPTHSelected(undefined);
          setCVPTPTHCCSelectTed(undefined);
        }}
        style={{ flexDirection: "row", marginTop: 10 }}
      >
        <Image style={{ height: 20, width: 20, marginRight: 10 }}
          source={!isCheckBOD ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
        <Text>Chuyển đến lãnh đạo Tập đoàn</Text>
      </Pressable>
      {
        isCheckBOD && <SelectForm
          // @ts-ignore
          userCC={bodCCSelectTed == undefined ? "" : bodCCSelectTed.map(item => item.Title).join(";")}
          onSelectUserCC={() => {
            // @ts-ignore
            navigation.navigate("SelectUserScreen",
              {
                typeSelect: TypeSelectUser.Multiple,
                usersSelected: bodCCSelectTed,
                onSelectApply: (users: any) => {
                  setBODCCSelected(users);
                },
                beanTask: null,
                result: null
              });
          }}
          lanhDaoSelected={bodSelectTed != undefined ? bodSelectTed["Title"] : ""}
          isUuTien={isUuTienCheckBOD}
          onBODPress={handlePressBODSelect}
          onPressUutien={() => {
            setIsUuTienCheckBOD(!isUuTienCheckBOD);
          }} />
      }
      <Pressable onPress={() => {
        setIsCheckCVPTPTH(!isCheckCVPTPTH);
        setIsCheckBOD(false);
        setIsUuTienCheckBOD(false);
        setBODSelected(undefined);
        setBODCCSelected(undefined);

      }} style={{ flexDirection: "row", marginTop: 10 }}>
        <Image style={{ height: 20, width: 20, marginRight: 10 }}
          source={!isCheckCVPTPTH ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
        <Text>Chuyển đến CVP/TPTH</Text>
      </Pressable>
      {
        isCheckCVPTPTH && <SelectForm
          // @ts-ignore
          userCC={CVPTPTHCCSelectTed == undefined ? "" : CVPTPTHCCSelectTed.map(item => item.Title).join(";")}
          onSelectUserCC={() => {
            // @ts-ignore
            navigation.navigate("SelectUserScreen",
              {
                typeSelect: TypeSelectUser.Multiple,
                usersSelected: CVPTPTHCCSelectTed,
                onSelectApply: (users: any) => {
                  setCVPTPTHCCSelectTed(users);
                },
                beanTask: null,
                result: null
              });
          }}
          lanhDaoSelected={CVPTPTHSelectTed != undefined ? CVPTPTHSelectTed["Title"] : ""}
          onBODPress={handlePressCPVSelect}
          isUuTien={isUuTienCheckCVPTPTH}
          onPressUutien={() => {
            setIsUuTienCheckCVPTPTH(!isUuTienCheckCVPTPTH);
          }} />
      }
    </View>;
  };

  const submitAction = () => {
    dispatch(startLoading());
    if (type == "VBDen") {
      itemVB = itemVB as BeanVanBanDen;
      itemVB.YKien = yKien;
      if (action.ID == EnumVanBanDenAction.SubmitBOD) {
        if (isCheckBOD) {
          itemVB.chkLanhDao = "true";
          itemVB.chkCVP_TPTH = "false";
          itemVB.chkPhanCong = "false";
          if(bodCCSelectTed!=undefined)
          {
            itemVB.UserCC=bodCCSelectTed.map((r:any) => `${r.AccountID.toString()};#${r.Title}`).join(";#");
          }
          if (bodSelectTed != undefined) {
            // @ts-ignore
            itemVB.chkLanhDaoValue = bodSelectTed.ID + ";#" + bodSelectTed.Title;
          }
          else {
            dispatch(endLoading());
            showAlert("Vui lòng chọn lãnh đạo");
            return;
          }
        } else if (isCheckCVPTPTH) {
          itemVB.chkCVP_TPTH = "true";
          itemVB.chkLanhDao = "false";
          itemVB.chkPhanCong = "false";
          if(CVPTPTHCCSelectTed!=undefined)
          {
            itemVB.UserCC=CVPTPTHCCSelectTed.map((r:any) => `${r.AccountID.toString()};#${r.Title}`).join(";#");
          }
          if (CVPTPTHSelectTed != undefined) {
            // @ts-ignore
            itemVB.chkCVP_TPTHValue = CVPTPTHSelectTed.ID + ";#" + CVPTPTHSelectTed.Title;
          }
          else {
            dispatch(endLoading());
            showAlert("Vui lòng chọn lãnh đạo");
            return;
          }

        } else {
          dispatch(endLoading());
          showAlert("Vui lòng chọn user");
          return;
        }
        itemVB.UuTien = (isUuTienCheckBOD || isUuTienCheckCVPTPTH).toString();
      }
      cancelPress();
      sendActionVanBanDen(action.ID, itemVB).then(
        value => {
          dispatch(endLoading());
          if (value) {
            //ToDO reload list
            navigation.goBack();
          } else {
            showAlert("Thao tác không thực hiện được!");
          }
        }
      );
    }
    else {
      itemVB = itemVB as BeanVBDi;
      if (action.ID == WorkflowAction.Return) {
        if (isNullOrEmpty(yKien)) {
          showAlert("Vui lòng nhập ý kiến");
          return;
        }
      }
      itemVB.CommentValue = yKien;
      switch (action.ID) {
        case WorkflowAction.Reject:
        case WorkflowAction.Next:
        case WorkflowAction.Approve:
        case WorkflowAction.Return:
          if (selectNDB != undefined)
            itemVB.CCForm = selectNDB.map(r => `${r.AccountID.toString()};#${r.Name}`).join(";#");
          break;
        case WorkflowAction.RequestInformation:
        case WorkflowAction.Forward:
          if (selectUserCXL != undefined)
            itemVB.ChooseUserValue = `${selectUserCXL?.AccountID};#${selectUserCXL?.Name}`;
          break;

      }
      ActionHoSoTaiLieu(action.ID, itemVB).then(value => {
        dispatch(endLoading());
        if (value) {
          //ToDO reload list
          navigation.goBack();
        } else {
          showAlert("Thao tác không thực hiện được!");
        }
      })
    }
  };

  return <Pressable
    onPress={() => {
      cancelPress();
    }}
    style={{
      position: "absolute",
      height: "100%",
      width: "100%",
      backgroundColor: "#19191EB2",
      alignItems: "center",
      justifyContent: "center"
    }}>
    <Pressable style={{ backgroundColor: "white", width: "90%", borderRadius: 10 }}>
      <View style={{ flexDirection: "row", borderBottomWidth: 0.7, borderBottomColor: "#f4f4f4", padding: 10 }}>
        <Image
          style={{ height: 25, width: 25, marginRight: 10 }}
          resizeMode={"contain"}
          source={getRequireImageAction(action.ID, action.Class)}
        />
        <Text style={{ color: "#0072c6", fontSize: 15 }}>{action.Title}</Text>
      </View>
      <View style={{ padding: 10 }}>
        <ContentOnlyEditText />
      </View>
      <View style={{ flexDirection: "row", padding: 10 }}>
        <View style={{ flex: 1 }} />
        <View style={{ flex: 1, flexDirection: "row" }}>
          <Pressable onPress={() => {
            cancelPress();
          }} style={{ flex: 1 }}><Text
            style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
          <Pressable
            onPress={() => {
              submitAction();
            }}
            style={{
              flex: 1,
              backgroundColor: "#0072C6",
              padding: 10,
              borderRadius: 6
            }}>
            <Text style={{
              textAlign: "center",
              backgroundColor: "#0072C6",
              color: "white",
              borderRadius: 6
            }}>Đồng ý</Text>
          </Pressable>
        </View>
      </View>
    </Pressable>
  </Pressable>;
};
