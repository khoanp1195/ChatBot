import { useNavigation, useRoute } from "@react-navigation/native";
import { Image, Keyboard, Pressable, StyleSheet, Text, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { TextEditorWithBorder } from "../../../components/customTextEditor.tsx";
import React, { useEffect, useState } from "react";
import { appMainBlueColor } from "../../../utils/color.ts";
import { getDisplayTxtFromDate, getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import { AssignmentHeaderView } from "../../../components/assignmentHeaderView.tsx";
import { BtnChooseEle } from "../../../components/buttonChooseSearchElement.tsx";
import { AssignItem } from "../../../components/assignItem.tsx";
import { CustomCalendarView } from "../../../components/customCalendarView.tsx";
import { useDispatch, useSelector } from "react-redux";
import { currentUserStore, subsiteStore } from "../../../config/constants.ts";
import { DbServices } from "../../../services/database/db_service.ts";
import { TypeSelectUser } from "../../../config/enum.ts";
import { LoadingScreen } from "../../../components/loadingScreen.tsx";
import { showAlert } from "../../commonAlertView.jsx";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { getDataAssignTree, getDataTaskAssignTree } from "./assignHelper.tsx";
import strings from "../../../assets/strings.ts";
import { EnumTaskAction } from "../../../config/enum.ts";
import { sendActionTaskVBBH, sendActionTaskVBDen } from "../../../services/api/apiTaskVB.ts";
import { IsGroupAssignmentAll } from "../../../services/api/api_doc.ts";
import { BeanDepartment } from "../../../services/database/models/bean_department.ts";

export const AssignTaskScreen = () => {
    const navigation = useNavigation()
    const dispatch = useDispatch();
    const route = useRoute();
    const onLoading = useSelector((state: any) => state.loading.onLoading);

    const [departments, setDepartments] = useState<BeanDepartment[]>();
    const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
    const [indexItemSetDueDate, setIndexItemSetDueDate] = useState(-1);
    const [dataTreeView, setDataTreeView] = useState();
    const [dataPhanCong, setDataPhanCong] = useState<BeanDepartment[]>();
    const [isShowFullAssigment, setIsShowFullAssigment] = useState();///GroupAssignmentFull
    const [isShowAssignUnit, setIsShowAssignUnit] = useState();//GroupAssignDeptInTask

    let [isCalendarDonViPhongBan, setIsCalendarDonViPhongBan] = useState(false);

    let ykien = "";
    // @ts-ignore
    let taskVB = route.params["taskVB"];
    // @ts-ignore
    const VB = route.params["VB"];
    // @ts-ignore
    const isVBDen = route.params["isVBDen"];
    useEffect(() => {
        DbServices.getInstance().getBeanSettingRepository().findByKey("GroupAssignmentFull").then(value => {
            IsGroupAssignmentAll(value[0].VALUE).then(value => setIsShowFullAssigment(value));
        });
        DbServices.getInstance().getBeanSettingRepository().findByKey("GroupAssignDeptInTask").then(value => {

            IsGroupAssignmentAll(value[0].VALUE).then(value => setIsShowAssignUnit(value));

        });
    }, [])

    useEffect(() => {
        console.log("isShowFullAssigment", isShowFullAssigment)
        if (isShowFullAssigment)
            //@ts-ignore
            getDataAssignTree(VB)
                .then(value => {
                    console.log("cây nè:", JSON.stringify(value))
                    setDataTreeView(value)
                });
        else
            //@ts-ignore
            getDataTaskAssignTree(taskVB)
                .then(value => {
                    console.log("cây task nè:", JSON.stringify(value))
                    setDataTreeView(value)
                });
    }, [isShowFullAssigment, isShowAssignUnit]);

    const didFinishedEditting = (text: any) => {
        ykien = text;
    }

    const onChooseDepartment = () => {
        // @ts-ignore
        navigation.navigate("AssignTreeView",
            {
                // @ts-ignore
                dataSelected: dataPhanCong != undefined ? new Set(dataPhanCong.map(item => {
                    var text = [item.ID, item.Title, item.IsThucHien, item.IsPhoiHop, item.IsUser, item.DepartmentTitle, item.GroupManager, item.GroupManager, item.HanXuLy].join(strings.SplitSignal);
                    if (__DEV__)
                        console.log("Chọn nè: ", text)
                    return text;
                })) : new Set(),
                data: dataTreeView,
                onSubmit: (departments: any) => {
                    setDataPhanCong(departments.map((item: string) => ({
                        ID: item.split(strings.SplitSignal)[0],
                        Title: item.split(strings.SplitSignal)[1],
                        IsThucHien: JSON.parse(item.split(strings.SplitSignal)[2]),
                        IsPhoiHop: JSON.parse(item.split(strings.SplitSignal)[3]),
                        IsUser: JSON.parse(item.split(strings.SplitSignal)[4]),
                        DepartmentTitle: item.split(strings.SplitSignal)[5],
                        GroupManager: item.split(strings.SplitSignal)[6],
                        HanXuLy: "",
                        Comment: ""
                    })));
                },
                // @ts-ignore
                // expandedSectionTitle: dataPhanCong != undefined && dataPhanCong.length > 0 ? dataPhanCong[0].ID + strings.SplitSignal + dataPhanCong[0].Title : "",
                isTask: true
            });
    };

    const onChooseUnit = () => {
        // @ts-ignore
        navigation.navigate("SelectDepartmentScreen",
            {
                beanTasks_Donvi: [],
                selectedTemp: departments,
                onSelectApply: (departments: any) => {
                    console.log("departments", departments);
                    setDepartments(departments);
                }
            });
    };

    const submitAction = () => {
        console.log("Item nè trc khi phân công nè dataPhancong", JSON.stringify(dataPhanCong))
        if (dataPhanCong == undefined && (isShowAssignUnit ? departments == undefined : false)) {
            showAlert("Vui lòng chọn thông tin phân công");
            return;
        } else {
            console.log("Item nè trc khi phân công nè", JSON.stringify(taskVB))
            taskVB.NguoiChuyen = currentUserStore.getCurrentUser().AccountID + ";#" + currentUserStore.getCurrentUser().Title;
            taskVB.YKien = ykien;

            //Phòng ban
            // @ts-ignore
            if (dataPhanCong != undefined && dataPhanCong.length > 0) {
                // @ts-ignore
                taskVB.ListAssignmentUsers = dataPhanCong.map((department:BeanDepartment) => {
                    if (!department.IsUser) // Phòng
                    {
                        department.DepartmentTitle = department.ID + ";#" + department.Title;
                        console.log("Ngày nè", department.HanXuLy)
                        return department.GroupManager
                            + (department.IsThucHien ? "&&1&&0&&0&&" : "&&0&&0&&1&&")
                            + (!isNullOrEmpty(department.HanXuLy) ? getDisplayTxtFromDate(new Date(department.HanXuLy), strings.SubmitFormatDate) : "")
                            + "&&"
                            + department.DepartmentTitle
                            + "&&"
                            + department.Comment
                            ;
                    } else // Người
                    {
                        console.log("Ngày nè", department.HanXuLy)
                        return department.ID
                            + ";#" + department.Title
                            + (department.IsThucHien ? "&&1&&0&&0&&" : "&&0&&0&&1&&")
                            + (!isNullOrEmpty(department.HanXuLy) ? getDisplayTxtFromDate(new Date(department.HanXuLy), strings.SubmitFormatDate) : "")
                            + "&&"
                            + department.DepartmentTitle
                            + "&&"
                            + department.Comment
                            ;
                    }
                }).join("&&@@");
                if (__DEV__) console.log("Chuỗi phân công nè", taskVB.ListAssignmentUsers)
            }

            // @ts-ignore
            if (departments != null && departments.length > 0) {
                // @ts-ignore
                taskVB.ListAssignmentDept = departments.map(lv2 => {
                    return lv2.ID + ";#" + lv2.Title + "&&" + lv2.Url + "&&" + (isNullOrEmpty(lv2.HanXuLy) ? "" : lv2.HanXuLy);
                }).join("&&@@");
                if (__DEV__) console.log("Chuỗi Đơn vị nè", taskVB.ListAssignmentDept)
            }

            console.log("Item nè trc khi phân công nè", JSON.stringify(taskVB))

            dispatch(startLoading());
            if (isVBDen) {
                sendActionTaskVBDen(EnumTaskAction.Assignment, taskVB).then(value => {
                    dispatch(endLoading());
                    if (value) {
                        navigation.goBack();
                        navigation.goBack();
                    }
                    else {
                        showAlert("Thao tác không thực hiện được");
                    }
                });
            }
            else {
                sendActionTaskVBBH(EnumTaskAction.Assignment, taskVB).then(value => {
                    dispatch(endLoading());
                    if (value) {
                        navigation.goBack();
                        navigation.goBack();
                    }
                    else {
                        showAlert("Thao tác không thực hiện được");
                    }
                });
            }

        }
    };

    // @ts-ignore
    const renderItem = ({ item, index }) => <AssignItem
        item={item}
        index={index}
        onDelete={() => {
            // @ts-ignore
            setDepartments((prevData) => prevData.filter((_, _index) => _index !== _index));
        }}
        onShowCalendar={() => {
            setIsCalendarDonViPhongBan(false);
            setIndexItemSetDueDate(index);
            setIsVisibleCalendar(true);
        }}
    />;

    // @ts-ignore
    const renderItemPhongBan = ({ item, index }) => <AssignItem
        item={item}
        index={index}

        onDelete={() => {
            // @ts-ignore
            setDataPhanCong((prevData) => prevData.filter((_, _index) => _index !== index));
        }}

        onShowCalendar={() => {
            setIsCalendarDonViPhongBan(true);
            setIndexItemSetDueDate(index);
            setIsVisibleCalendar(true);
        }}
        textLabelBellowTitle={item.IsThucHien ? "Thực hiện" : "Phối hợp"}
    />;

    return (
        <Pressable style={{ flex: 1, backgroundColor: "white" }} onPress={() => {
            Keyboard.dismiss();
        }}>
            <ModalTopBar
                title={"Phân công"}
                isTitleCenter={true}

                onPress={() => {
                    navigation.goBack();
                }} />

            <ScrollView style={{ flex: 1, paddingHorizontal: 10 }}>
                <View style={{ flex: 1, height: 20 }}><Text style={styles.titleStyle}>Ý kiến lãnh đạo</Text></View>
                <View style={{ flex: 1, height: 100 }}>
                    <TextEditorWithBorder
                        didFinishedEditting={(text: any) => {
                            didFinishedEditting(text);
                        }} />
                </View>

                <View style={{ flex: 1 }}>
                    <AssignmentHeaderView titleHeader={"Chọn người dùng để phân công"}
                        titleButton={"Người dùng"}
                        onPress={() => {
                            onChooseDepartment();
                        }}
                        placeHolder={"Vui lòng bấm vào nút để chọn người dùng"}
                        imageButton={require("../../../assets/images/icon_tick_phong_ban.png")} />

                    <View style={{ marginTop: 10 }}>
                        {
                            // @ts-ignore
                            dataPhanCong != undefined &&
                            <FlatList
                                style={{ marginTop: 10 }}
                                data={dataPhanCong}
                                renderItem={renderItemPhongBan}
                                scrollEnabled={false}
                            />
                        }
                    </View>
                </View>

                {isShowAssignUnit && <View style={{ flex: 1 }}>
                    <AssignmentHeaderView titleHeader={"Chuyển đến Tập đoàn, các đơn vị thành viên"}
                        titleButton={"Công ty thành viên"}
                        onPress={() => {
                            // @ts-ignore
                            onChooseUnit();
                        }}
                        placeHolder={"Vui lòng bấm vào nút để chọn công ty thành viên"}
                        imageButton={require("../../../assets/images/icon_tick_thanh_vien.png")} />
                    <View>
                        {
                            // @ts-ignore
                            departments != undefined &&
                            <FlatList
                                style={{ marginTop: 10 }}
                                data={departments}
                                renderItem={renderItem}
                                scrollEnabled={false}
                            />
                        }
                    </View>
                </View>}
            </ScrollView>

            <View style={{ flexDirection: "row", padding: 10 }}>
                <View style={{ flex: 1 }} />
                <View style={{ flex: 1, flexDirection: "row" }}>
                    <Pressable onPress={() => {
                        navigation.goBack();
                    }} style={{ flex: 1 }}><Text
                        style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
                    <Pressable
                        onPress={() => {
                            submitAction();
                        }}
                        style={{
                            flex: 1,
                            backgroundColor: "#0072C6",
                            padding: 10,
                            borderRadius: 6
                        }}>
                        <Text style={{
                            textAlign: "center",
                            backgroundColor: "#0072C6",
                            color: "white",
                            borderRadius: 6
                        }}>Phân công</Text>
                    </Pressable>
                </View>
            </View>

            {isVisibleCalendar &&
                <CustomCalendarView
                dateFocus={!isCalendarDonViPhongBan?departments![indexItemSetDueDate].HanXuLy:dataPhanCong![indexItemSetDueDate].HanXuLy}
                onTouchOutSite={() => {
                        setIndexItemSetDueDate(-1);
                        setIsVisibleCalendar(!isVisibleCalendar);
                    }}
                    onPressDate={(date: any) => {
                        if (!isCalendarDonViPhongBan) {
                            // @ts-ignore
                            departments[indexItemSetDueDate].HanXuLy = date.dateString;
                        } else {
                            if (dataPhanCong != undefined) {
                                // @ts-ignore
                                dataPhanCong[indexItemSetDueDate].HanXuLy = date.dateString;
                            }
                        }
                        setIsVisibleCalendar(false);
                    }}
                />}
            {onLoading && <LoadingScreen />}
        </Pressable>
    );
};

const styles = StyleSheet.create({
    root: {
        height: "100%"
    },
    mainTitleStyle: {
        flex: 1,
        fontWeight: "bold"
    },
    titleStyle: {
        flex: 1
    }
});