import moment from "moment";
import { View, FlatList, StyleSheet, Text } from "react-native"
import { appMainBlueColor } from "../../../utils/color";
import { getListItemBackground, isNullOrEmpty } from "../../../utils/functions"
import { TaskState } from "./listDepartmentTask";
import { customStyles } from "../../../utils/customStyles.ts";
import { getDisplayTxtFromDateString } from "../../../utils/functions"
import { useState } from "react";
import { BeanDepartment } from "../../../services/database/models/bean_department.ts";
import { DbServices } from "../../../services/database/db_service.ts";
//@ts-ignore
export const ListUnitTask = ({ doHideHeader, data }) => {
    moment.locale('en');
    //@ts-ignore
    const Item = ({ item, index }) => {
        
        return <View
        style={[
            customStyles.tableContentItemContainer,
            {
                backgroundColor: getListItemBackground(index % 2 != 0),
            },
        ]}>

        <View
            style={{
                flex: 1,
                flexDirection: 'row',
            }}
        >
            <View style={{
                flex: 1,
                justifyContent: 'center',
                alignSelf: 'center',
                flexDirection: 'row',
            }}>
                <Text style={[{ flex: 1, fontSize: 15, }]} >{item.DepartmentName}</Text>
            </View>

            <View style={{
                // flex: 1,
                width: 140,
            }}>
                {!isNullOrEmpty(item.DueDate) &&
                    <View style={{ flex: 1 }}>
                        <Text style={[{
                            flex: 1,
                            fontSize: 12,
                            //@ts-ignore
                            color: !isNullOrEmpty(item.DueDate) && moment(item.DueDate) <= new Date() ? 'red' : 'darkgrey',
                            textAlign: 'right',
                            paddingBottom: 5,
                        }]} >{getDisplayTxtFromDateString(item.DueDate)}</Text>
                    </View>}
                <TaskState state={item.TrangThai} />
            </View>
        </View>
    </View >
    };

    return <View>
        {!doHideHeader && <Text style={customStyles.tableContentHeader}>
            Đơn vị
        </Text>}
        <FlatList
            data={data}
            renderItem={({ item, index }) => <Item item={item} index={index} />}
            keyExtractor={item => item.id}
            scrollEnabled={false}
        />
    </View>
}

const styles = StyleSheet.create({
})
