import moment from "moment";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native"
import { Image } from "react-native-elements";
import { appMainBlueColor } from "../../../utils/color";
import { getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import { customStyles } from "../../../utils/customStyles.ts";
import { getDisplayTxtFromDateString, getFileSize, getFileIcon } from "../../../utils/functions"
import { getTextSplit } from "../../../utils/textHelper.ts";

export const ListAttachment = ({ doHideHeader = false, data, onClick }) => {
    moment.locale('en');

    const Item = ({ item, index }) => {
        return (
            <Pressable
                style={[
                    customStyles.tableContentItemContainer,
                    { backgroundColor: getListItemBackground(index % 2 != 0) }]
                }
                onPress={() => { onClick(item) }}
            >

                <Image
                    style={{
                        height: 20,
                        width: 20,
                        alignItems: 'flex-start',
                        justifyContent: 'center',
                    }}
                    source={getFileIcon(!isNullOrEmpty(item.Url) ? item.Url.split(".").pop() : item.Path.split(".").pop())}
                    resizeMode="contain"
                />
                <View
                    style={{
                        flex: 4,
                        flexDirection: 'column',
                        paddingLeft: 5,
                    }}
                >
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Text style={[{ flex: 1, fontSize: 15, color: '#335FB3' }]}>{item.Title.includes(";#") ? item.Title.split(";#")[0] : item.Title}</Text>
                        <Text style={{ textAlign: 'right', color: 'black' }}>{getTextSplit(item.Author,";#",1)}</Text>
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Text style={[{ flex: 1, fontSize: 13, color: 'darkgrey' }]}>{getFileSize(item.Size)}</Text>
                        <Text style={[{ flex: 3, fontSize: 13, marginHorizontal: 5, color: 'darkgrey' }]}>{item.Category}</Text>
                        <Text style={{ flex: 1, fontSize: 13, color: 'darkgrey', textAlign: 'right', }}>{getDisplayTxtFromDateString(item.Created)}</Text>
                    </View>
                </View>
            </Pressable>
        )
    };

    return <View>
        {!doHideHeader && <Text style={customStyles.tableContentHeader}>
            Tài liệu đính kèm
        </Text>}

        <FlatList
            data={data}
            renderItem={({ item, index }) => <Item item={item} index={index} />}
            keyExtractor={item => item.id}
            scrollEnabled={false}
        />
    </View>
}

const styles = StyleSheet.create({
})