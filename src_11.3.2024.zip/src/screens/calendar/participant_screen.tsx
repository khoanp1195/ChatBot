import { View, Text, StyleSheet, TouchableOpacity, Pressable, Keyboard, Image, TextInput, ActivityIndicator } from 'react-native'
import React, { useEffect, useState } from 'react'
import { useNavigation, useRoute } from '@react-navigation/native'
import { FlatList } from 'react-native-gesture-handler';
import { ModalTopBar } from '../../components/modalTopBar';
import { useDispatch } from 'react-redux';
import { changeDataDonvi } from '../../stores/lichtuan/actions';
import { appMainBlueColor } from '../../utils/color';
import { convertListUser } from '../../utils/functions'

export const Participant_Screen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  // @ts-ignore
  const item = route.params["item"];
  const [isLoading, setIsLoading] = useState(true)
  const [lstUser, setlstUser] = useState([])
  const [dictUser, setdictUser] = useState({})
  const closeScreen = () => {
    // @ts-ignore
    if (navigation.canGoBack())
      navigation.goBack();
  }
  //@ts-ignore
  const onClickUnit = (item) => {
    if (__DEV__) console.log(item.Title, item.KeyConnection, item.SiteConnection)
    closeScreen()
  }


  useEffect(() => {
    setlstUser(convertListUser(item))
  }, [item])

  // Hàm để tải dữ liệu vào đối tượng
  function loadDictData(users: any[]) {
    let dictUser = {}; // Khởi tạo một đối tượng để lưu trữ dữ liệu
    // Tạo một mảng chứa các key của GroupBy
    let lst_keys = [...new Set(users.map(user => user.DepartmentTitle))];
    // Lặp qua từng key và thêm các mục của nhóm vào từ điển
    lst_keys.forEach(key => {
      dictUser[key] = users.filter(user => user.DepartmentTitle === key);
    });

    return dictUser
  }

  const Item = ({ item, index }: any) => {
    return (
      <TouchableOpacity style={{
        backgroundColor: '#E7F5FF',
        flex: 1,
        flexDirection: 'row',
        padding: 10,
      }} onPress={() => {
        onClickUnit(item)
      }
      }>
        <Text>{item.Title}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <Pressable
      style={{ flex: 1, backgroundColor: 'white' }}
      onPress={Keyboard.dismiss}
    >
      {/*  <View style={{ flex: 1, backgroundColor: 'white' }} > */}
      <ModalTopBar
        title={"Thành phần tham gia"}
        onPress={() => {
          closeScreen()
        }} />
      {
        item != null && item.length > 0 ?
          <View style={{
            flex: 1,
          }}>
            <FlatList
              data={Object.keys(loadDictData(lstUser))}
              renderItem={({ item }) => (
                <View>
                  <View style={styles.headerWeekCalendar}>
                    <Text style={{ marginLeft: '2%', fontWeight: '600', color: 'black' }}>{item}</Text></View>
                  <FlatList
                    style={{ backgroundColor: '#E7F5FF', }}
                    data={loadDictData(lstUser)[item]}
                    renderItem={({ item, index }) => <Item item={item} index={index} />}
                    keyExtractor={(item, index) => index.toString()}
                  />
                </View>
              )}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
          : isLoading ? <ActivityIndicator size="large" color={appMainBlueColor} /> : <EmptyView />
      }
      {/* </View> */}
    </Pressable>
  )
}

const styles = StyleSheet.create({
  flatList: {
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  rootContainer: {
    height: "100%",
    backgroundColor: "white"
  },

  headerWeekCalendar: {
    backgroundColor: '#EAEAEA',
    height: 40,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',

  },
  searchBar: {
    height: 40,
    backgroundColor: "#f5f5f5",
    marginHorizontal: 5,
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
  },
  input: {
    // height: 30,
    fontSize: 14,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    flex: 1,
    borderRadius: 6,
  },
  focusedText: { color: 'red', fontWeight: 'bold' },
  normalText: { color: 'black', fontWeight: 'normal' }
})

export default Participant_Screen

