import { FlatList, Image, Pressable, StyleSheet, Text, View } from "react-native"
import { ModalTopBar } from "../../../components/modalTopBar";
import { useNavigation } from "@react-navigation/native";
import { CustomFastImage } from "../../../components/custom_fast_image";
import { BASE_URL, currentUserStore, subsiteStore } from "../../../config/constants";
import { HealthType } from "../../../services/database/models/healthType";
import { useEffect, useState } from "react";
import { convertStringToMoment, isNullOrEmpty } from "../../../utils/functions";
import RowSpaceBetween from "../../../components/rowSpaceBetween";
import { getInfoHSSk } from "../../../services/api/apiHSSK";
import { useSelector } from "react-redux";

export const DashboardHSSKScreen = () => {
  const navigation = useNavigation();
  const [data, setData] = useState<Health>();
  const onLoading=useSelector((state: any) => state.loading.onLoading);

  const lstItem = [
    new HealthType(1, "Chiều cao", (data == null) ? "" : data.Height.toString(), "Cm", "", require('../../../assets/images/icon_hssk_1.png'), "Height"),
    new HealthType(2, "Cân nặng", (data == null) ? "" : data.Weight.toString(), "Kg", "", require('../../../assets/images/icon_hssk_2.png'), "Weight"),
    new HealthType(3, "Nhịp tim", (data == null) ? "" : data.HeartRate, "Lần/phút", "", require('../../../assets/images/icon_hssk_3.png'), "HeartRate"),
    new HealthType(4, "Huyết áp", (data == null || isNullOrEmpty(data.BloodPressure)) ? "" : data.BloodPressure, "mmHg", "", require('../../../assets/images/icon_hssk_4.png'), ""),
    new HealthType(5, "Chỉ số BMI", (data == null) ? "" : data.BMI.toString(), "", "", require('../../../assets/images/icon_hssk_5.png'), "BMI"),
    new HealthType(6, "Phân loại sức khỏe", (data == null || isNullOrEmpty(data.Classification)) ? "" : data.Classification, "", "", require('../../../assets/images/icon_hssk_6.png'), ""),
  ]

  useEffect(() => {
    getInfoHSSk().then(value => {
      if (value != null)
        setData(value);
    });
  }, [onLoading])
  const gotoChartTypeScreen = (item: HealthType) => {
    if (!isNullOrEmpty(item.KeyType)) {
      //@ts-ignore
      navigation.navigate("DetailHSSKScreen", {
        url: `/HealthRecords/SitePages/mobile/Statistics.aspx?Type=${item.KeyType}&IsMobile=1&IsDlg=1`,
        title: item.Name
      })
    }
  }
  const renderItem = ({ item }: { item: HealthType }) => (
    <Pressable style={styles.itemContainer} onPress={() => gotoChartTypeScreen(item)}>
      <RowSpaceBetween>
        <Image source={item.ImageResource} style={styles.iconImage} />
        <Text style={styles.itemValue}>{item.Value}</Text>
      </RowSpaceBetween>
      <View style={styles.separator} />
      <RowSpaceBetween>
        <Text style={styles.itemName}>{item.Name}</Text>
        <Text style={styles.itemValueType}>{item.ValueType}</Text>
      </RowSpaceBetween>
    </Pressable>
  );
  const onClicIconHistory = () => {
    //@ts-ignore
    navigation.navigate("DetailHSSKScreen", {
      url: `/HealthRecords/SitePages/mobile/Records_History.aspx?IsMobile=1&IsDlg=1`,
      title: "Hồ sơ sức khỏe"
    })
  }
  const IconHistory = () =>
    <Pressable onPress={() => onClicIconHistory()} style={{ marginRight: 10 }}>
      <Image style={{ height: 25, width: 25 }} source={require('../../../assets/images/btn_history.png')} resizeMode="contain" />
    </Pressable>

  const onCLickIconEdit = () => {
    //@ts-ignore
    navigation.navigate("DetailHSSKScreen", {
      url: `/HealthRecords/SitePages/mobile/Records_Form.aspx?IID=${data?.ID}&IsMobile=1&IsDlg=1`,
      title: "Hồ sơ sức khỏe"
    })
  }
  const IconEdit = () => <Pressable onPress={onCLickIconEdit}>
    <Image style={{ height: 25, width: 25 }} source={require('../../../assets/images/btn_edit.png')} resizeMode="contain" />
  </Pressable>

  const RightActionTopBar = () => {
    return (
      <View style={{ flexDirection: 'row' }}>
        <IconHistory />
        <IconEdit />
      </View>
    )
  }
  return (
    <View style={styles.container}>
      <ModalTopBar
        title={'Hồ sơ sức khỏe'}
        onPress={() => {
          navigation.goBack();
        }}
        rightAction={
          RightActionTopBar()
        }
      />
      <View style={styles.profileContainer}>
        <CustomFastImage
          defaultImage={require('../../../assets/images/avatar80.jpg')}
          urlOnline={BASE_URL + '/' + subsiteStore.getSubsite() + '/' + currentUserStore.getCurrentUser().ImagePath}
          styleImg={styles.profileImage}
        />
        <Text style={styles.profileName}>{currentUserStore.getCurrentUser().Title}</Text>
        <View style={styles.rowContainer}>
          <Text style={styles.label}>Ngày sinh:</Text>
          <Text style={styles.value}>{
            currentUserStore.getCurrentUser().Birthday != null ?
              convertStringToMoment(currentUserStore.getCurrentUser().Birthday).format("DD/MM/yyyy") :
              ""
          }</Text>
        </View>
      </View>
      <View>
        <FlatList
          data={lstItem}
          renderItem={renderItem}
          numColumns={2}
          style={styles.flatList}
        />
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flex: 1,
    height: 103,
    backgroundColor: 'white',
    margin: 5,
    padding: 20,
    borderRadius: 10,
    flexDirection: 'column',
  },
  iconImage: {
    height: 32,
    width: 32,
  },
  itemValue: {
    fontSize: 24,
    textAlign: 'justify',
    fontWeight: 'bold',
    color: '#0072C6',
  },
  separator: {
    flex: 1,
  },
  itemName: {
    fontSize: 14,
    textAlign: 'justify',
    color: 'black',
  },
  itemValueType: {
    fontSize: 14,
    textAlign: 'justify',
    fontWeight: 'bold',
    color: 'black',
  },
  profileContainer: {
    alignItems: 'center',
    padding: 15,
  },
  profileImage: {
    height: 125,
    width: 125,
    borderRadius: 100,
  },
  profileName: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    marginTop: 10,
  },
  rowContainer: {
    flexDirection: 'row',
  },
  label: {
    textAlign: 'center',
    fontSize: 14,
    color: 'black',
    marginTop: 10,
  },
  value: {
    textAlign: 'center',
    fontSize: 14,
    color: 'black',
    marginTop: 10,
  },
  flatList: {
    margin: 10,
  },
});

