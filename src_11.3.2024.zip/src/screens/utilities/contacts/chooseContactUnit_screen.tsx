import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../components/modalTopBar";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, Keyboard, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { appMainBlueColor } from "../../../utils/color";
// @ts-ignore
import EmptyView from "../../../components/empty_view.tsx";
import { isNullOrEmpty } from "../../../utils/functions.ts";
import { getListUnitData } from "../../../services/api/api_contacts.ts";
import { BASE_URL, subsiteStore } from "../../../config/constants.ts";

export const ChooseContactUnitScreen = (selectedsubSite: string, urlUnit: string) => {
    const navigation = useNavigation();
    const route = useRoute();


    const [DATA, setData] = useState([])
    const [isLoading, setIsLoading] = useState(true)
    const [searchKey, setSearchKey] = useState("")

    // @ts-ignore
    const selectedUrl = route.params["url"];
    console.log('site đang focused nè', selectedUrl)
    // @ts-ignore
    const onSelected = route.params["onSelected"];

    useEffect(() => {
        //@ts-ignore
        getListUnit().then(value => {
            // setData(value)
            setData(value)
        });
    }, []);

    const getListUnit = async () => {
        setIsLoading(true)
        const dataPost = {
            urlDonVi: urlUnit,
        };

        let newData = new FormData();
        newData.append("data", JSON.stringify(dataPost));

        const retData = await getListUnitData(newData, 1)
       // var url = BASE_URL + subsiteStore.getSubsite();

        try {
            if (retData !== null && retData.Data !== null) {
                setIsLoading(false)
                return retData.Data
            }
        }
        catch (ex) {
            console.error(ex);
        }

        setIsLoading(false)
        return [];
    }

    //@ts-ignore
    const onClickUnit = (item) => {
        if (__DEV__) console.log(item.TenToChucVN, item.Url)
        onSelected(item.TenToChucVN, item.Url)
        closeScreen()
    }

    //@ts-ignore
    const ItemContact = ({ item, index }) => {
        // if (__DEV__)
        //     console.log(item.Url)
        return (
            <Pressable style={{
                backgroundColor: 'white',
                flex: 1,
                flexDirection: 'row',
                padding: 10,
            }}
                //@ts-ignore
                onPress={() => { onClickUnit(item) }}
            >
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Text style={item.Url == selectedUrl ? styles.focusedText : styles.normalText}>{item.TenToChucVN}</Text>
                </View >
            </Pressable >
        )
    }

    const closeScreen = () => {
        // @ts-ignore
        if (navigation.canGoBack())
            navigation.goBack();
    }

    return (
        <Pressable
            style={{ flex: 1, backgroundColor: 'white' }}
            onPress={Keyboard.dismiss}
        >
            {/*  <View style={{ flex: 1, backgroundColor: 'white' }} > */}
            <ModalTopBar
                title={"Đơn vị"}
                onPress={() => {
                    closeScreen()
                }} />

            <View style={{
                height: 60,
                justifyContent: 'center',
                alignItems: 'center',
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: 'lightgrey'
            }}>
                <View style={styles.searchBar}>
                    <Image
                        style={{
                            // flex: 1,
                            height: '50%',
                            aspectRatio: 1,
                            marginLeft: 10,
                            justifyContent: 'center',
                            // backgroundColor: 'cyan'
                        }}
                        source={require('../../../assets/images/icon_search26.png')}
                        resizeMode="stretch"
                    />
                    < TextInput
                        style={styles.input}
                        placeholder="Tìm kiếm"
                        autoCapitalize="none"
                        value={searchKey}
                        onChangeText={(text) => setSearchKey(text)} />
                </View>

            </View>

            {
                DATA != null && DATA.length > 0 ?
                    <View style={{
                        flex: 1,
                    }}>
                        <FlatList
                            scrollEnabled={true}
                            // @ts-ignore
                            keyExtractor={(item, index) => item + index}
                            data={DATA}
                            numColumns={1}
                            // @ts-ignore
                            renderItem={({ item, index }) => {
                                return <ItemContact item={item} index={index} />;
                            }}
                        />
                    </View>
                    : isLoading ? <ActivityIndicator size="large" color={appMainBlueColor} /> : <EmptyView />
            }
            {/* </View> */}
        </Pressable>
    )

}
const styles = StyleSheet.create({
    rootContainer: {
        height: "100%",
        backgroundColor: "white"
    },
    searchBar: {
        flex:1,
        height: 40,
        backgroundColor: "#f5f5f5",
        flexDirection: 'row',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
    },
    input: {
        flex:1,
        height: 40,
        fontSize: 14,
        marginHorizontal: 5,
        paddingHorizontal: 5,
        borderRadius: 6,
    },
    focusedText: { color: 'red', fontWeight: 'bold' },
    normalText: { color: 'black', fontWeight: 'normal' }
});
