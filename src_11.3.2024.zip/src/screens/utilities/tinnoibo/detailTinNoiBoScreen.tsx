import { Text, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import { WebView } from "react-native-webview";
import { getFullLink } from "../../../config/constants.ts";
import React, { useRef, useState } from "react";
import { getScreenWidth } from "../../../utils/functions.ts";
import { useSelector } from "react-redux";

export const DetailTinNoiBoScreen=()=>{
  const navigation=useNavigation();
  const route= useRoute();
  const parent =useSelector((state: any) => state.tinNoiBo.item);
  const webViewRef = useRef(null);

  // @ts-ignore
  const item= route.params["item"];
  const [canGoBack, setCanGoBack] = useState(false);
  const handleNavigationStateChange = (navState:any) => {
    setCanGoBack(navState.canGoBack);
  };
  return <View style={{flex:1}}>
    <ModalTopBar title={`Tin nội bộ / ${parent!=undefined?parent.Title:""}`} onPress={()=>{
      console.log(webViewRef.current)
      if(webViewRef.current && canGoBack)
      {
        //@ts-ignore
        webViewRef.current.goBack();
      }
      else{
        navigation.goBack();
      }
    }}/>
    <WebView
      ref={webViewRef}
      style={{ height:'100%',width:getScreenWidth(), backgroundColor:'white' }}
      originWhitelist={['*']}
      source={{ uri: getFullLink()+`/news/SitePages/DetailNewsMobile.aspx?IID=${item.ID}&CID=${item.CategoryId}&Isdlg=1&IsMobile=1`}}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
      onNavigationStateChange={handleNavigationStateChange}
      onShouldStartLoadWithRequest={request => {
        console.log("request.url", request.url);
        return true;
      }}
    />
  </View>
}
