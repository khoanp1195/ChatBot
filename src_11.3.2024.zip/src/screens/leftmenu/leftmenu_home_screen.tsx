import React, { useEffect, useState } from "react";
import { Image, Text, TouchableOpacity, View, StyleSheet, Pressable, Alert } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  redirectHSLTCuaToi,
  redirectHSLTTatCa,
  redirectTBScreen,
  redirectVBDenChoChoYKien,
  redirectVBDenChoThucHien,
  redirectVBDenDaGiaiQuyet,
  redirectVBDenTatCa,
  redirectVBDenThongBao,
  redirectVBDenTitle,
  redirectVBDiChoPheDuyet,
  redirectVBDiDaPhatHanh,
  redirectVBDiDaPheDuyet, redirectVBDiTatCa,
  redirectVBDiThongBao,
  redirectVBDiTitle,
  redirectVBPHScreen,
  redirectVCXLScreen
} from "../../stores/base_screen/actions.ts";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import strings from "../../assets/strings.ts";
import { logout } from "../../stores/login/actions.ts";
import { DbServices } from "../../services/database/db_service.ts";
import { saveCookie, saveModified, saveSubSite } from "../../utils/async_storage.ts";
import { cookieStore, currentUserStore, modifiedStore, subsiteStore } from "../../config/constants.ts";
import {
  BaoCaoThongMinhUtil,
  DangKyXuatAn, DatVeMayBay,
  HSLTCuaToi,
  HSLTTatCa,
  TBScreen, TinNoiBo,
  VBDenChoChoYKien,
  VBDenChoThucHien,
  VBDenDaGiaiQuyet,
  VBDenTatCa,
  VBDenThongBao,
  VBDenTitle, VBDiChoPheDuyet, VBDiDaPhatHanh, VBDiDaPheDuyet, VBDiTatCa, VBDiThongBao, VBDiTitle,
  VBPHScreenState,
  VCXLHighScreen,
  VCXLScreen
} from "../../stores/base_screen/action_types.ts";

export const LeftMenuHomeScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [id, setID] = useState(0);
  const screen = useSelector((state: any) => state.baseScreen.screen.toString());
  const data = [
    {
      ID: 0,
      Title: "VB chờ xử lý",
      Enum: VCXLScreen,
      Icon: require("../../assets/images/icon_hom_vbcanxuly.png"),
      IsParent: false
    },
    {
      ID: 1,
      Title: "VB phối hợp",
      Enum: VBPHScreenState,
      Icon: require("../../assets/images/icon_hom_vbcanxuly.png"),
      IsParent: false
    },
    {
      ID: 2,
      Title: "Thông báo",
      Enum: TBScreen,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_thongbao.png"),
      IsParent: false
    },
    {
      ID: 3,
      Title: "VĂN BẢN ĐẾN",
      Enum: VBDenTitle,
      Icon: require("../../assets/images/icon_home_filetext.png"),
      IsParent: true
    },
    {
      ID: 4,
      Title: "Chờ cho ý kiến",
      Enum: VBDenChoChoYKien,
      Icon: require("../../assets/images/icon_leftmenu_vbden_chochoykien.png"),
      IsParent: false
    },
    {
      ID: 5,
      Title: "Chờ thực hiện",
      Enum: VBDenChoThucHien,
      Icon: require("../../assets/images/icon_history.png"),
      IsParent: false
    },
    {
      ID: 6,
      Title: "Đã xử lý",
      Enum: VBDenDaGiaiQuyet,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_dapheduyet.png"),
      IsParent: false
    },
    {
      ID: 7,
      Title: "Thông báo",
      Enum: VBDenThongBao,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_thongbao.png"),
      IsParent: false
    },
    {
      ID: 8,
      Title: "Tất cả",
      Enum: VBDenTatCa,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_tatca.png"),
      IsParent: false
    },
    {
      ID: 9,
      Title: "VĂN BẢN ĐI/ NỘI BỘ",
      Enum: VBDiTitle,
      Icon: require("../../assets/images/icon_home_vbdi.png"),
      IsParent: true
    },
    {
      ID: 10,
      Title: "Chờ phê duyệt",
      Enum: VBDiChoPheDuyet,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_chopheduyet.png"),
      IsParent: false
    },
    {
      ID: 11,
      Title: "Đã phê duyệt",
      Enum: VBDiDaPheDuyet,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_dapheduyet.png"),
      IsParent: false
    },
    {
      ID: 12,
      Title: "Đã phát hành",
      Enum: VBDiDaPhatHanh,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_bhvacbh.png"),
      IsParent: false
    },
    {
      ID: 13,
      Title: "Thông báo",
      Enum: VBDiThongBao,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_thongbao.png"),
      IsParent: false
    },
    {
      ID: 14,
      Title: "Tất cả",
      Enum: VBDiTatCa,
      Icon: require("../../assets/images/icon_leftmenu_vbdi_tatca.png"),
      IsParent: false
    },
    {
      ID: 15,
      Title: "HỒ SƠ LƯU TRỮ",
      Icon: require("../../assets/images/icon_home_hslt.png"),
      IsParent: true
    },
    {
      ID: 16,
      Title: "Tất cả",
      Enum: HSLTTatCa,
      Icon: require("../../assets/images/icon_search_hslt.png"),
      IsParent: false
    },
    {
      ID: 17,
      Title: "Hồ sơ của tôi",
      Enum: HSLTCuaToi,
      Icon: require("../../assets/images/icon_hsct_hslt.png"),
      IsParent: false
    },
    {
      ID: 18,
      Title: "Thiết lập App với link từ email",
      TintColor: "#0072C6",
      Enum: null,
      Icon: require("../../assets/images/icon_applink.png"),
      IsParent: false
    },
    {
      ID: 19,
      Title: "Đăng xuất",
      TintColor: "red",
      Enum: null,
      Icon: require("../../assets/images/icon_logout.png"),
      IsParent: false
    },
    {
      ID: 20,
      Title: "Phiên bản",
      Enum: null,
      Icon: require("../../assets/images/icon_rememberme.png"),
      IsParent: false
    }
  ];
  useEffect(() => {
    const item = data.find(r => r.Enum == screen);
    if (item != null && item != undefined) {
      console.log("screen nè", item != null && item != undefined)
      // @ts-ignore
      setID(item.ID);
    }
  }, [screen])
  const redirect = (item: any) => {
    if (item.ID < 18 || item.ID == 19) {
      if (item.ID < 18) {
        // @ts-ignore
        setID(item.ID);
      }
      switch (item.ID) {
        case 0:
          dispatch(redirectVCXLScreen());
          break;
        case 1:
          dispatch(redirectVBPHScreen());
          break;
        case 2:
          dispatch(redirectTBScreen());
          break;
        case 3:
          dispatch(redirectVBDenTitle());
          break;
        case 4:
          dispatch(redirectVBDenChoChoYKien());
          break;
        case 5:
          dispatch(redirectVBDenChoThucHien());
          break;
        case 6:
          dispatch(redirectVBDenDaGiaiQuyet());
          break;
        case 7:
          dispatch(redirectVBDenThongBao());
          break;
        case 8:
          dispatch(redirectVBDenTatCa());
          break;
        case 9:
          dispatch(redirectVBDiTitle());
          break;
        case 10:
          dispatch(redirectVBDiChoPheDuyet());
          break;
        case 11:
          dispatch(redirectVBDiDaPheDuyet());
          break;
        case 12:
          dispatch(redirectVBDiDaPhatHanh());
          break;
        case 13:
          dispatch(redirectVBDiThongBao());
          break;
        case 14:
          dispatch(redirectVBDiTatCa());
          break;
        case 15:
        case 16:
          dispatch(redirectHSLTTatCa());
          break;
        case 17:
          dispatch(redirectHSLTCuaToi());
          break;
        case 19:
          Alert.alert(
            strings.AlertTitle,
            "Bạn có muốn đăng xuất tài khoản",
            [
              {
                text: "Hủy",
                style: "cancel"
              },
              {
                text: "Đồng ý",
                onPress: async () => {
                  DbServices.getInstance().deleteAll();
                  await saveModified("");
                  await saveCookie("");
                  await saveSubSite("");
                  cookieStore.setCookie("");
                  modifiedStore.setModified("");
                  currentUserStore.setCurrentUser(null);
                  subsiteStore.setSubsite("");
                  dispatch(logout());
                }
              }
            ],
            { cancelable: false }
          );
          break;
      }
      navigation.dispatch(DrawerActions.closeDrawer());
    }
  };
  return (
    <View style={[styles.container]}>
      {data.map((item) => (
        <Pressable key={item.ID} onPress={() => {
          redirect(item);
        }}>
          <View style={styles.rowContainer}>
            <View style={[styles.indicator, { backgroundColor: id === item.ID ? "#0072C6" : "white" },
            (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]} />
            <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? "#E6F5FF80" : "white" },
            (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]}>
              <Image source={item.Icon} style={styles.icon}
                // @ts-ignore
                tintColor={item.TintColor !== undefined ? item.TintColor : null} />
              <Text style={[styles.title, item.IsParent && { fontWeight: "bold" },
              item.TintColor !== undefined && { color: item.TintColor }]}>{item.Title}</Text>
            </View>
          </View>
        </Pressable>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10
  },
  rowContainer: {
    flexDirection: "row"
  },
  indicator: {
    width: 10,
    height: 50
  },
  itemContainer: {
    flexDirection: "row",
    width: "96%",
    padding: 10,
    alignItems: "center"
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10
  },
  title: {
    color: "#000000"
  }
});
