export class BeanUtilities {
    title: string;
    imageSource: any;
    constructor(title: string, imageSource: any) {
        this.title = title;
        this.imageSource = imageSource;
    }
}