import { isNullOrEmpty } from "../../../utils/functions";
export class BeanVBBH {
    ID:string;
    Title: string;
    SoVanBan:string;
    NguoiKyVanBanText:string;
    ChucVu:string;
    NguoiSoanThaoText: string;
    DonViSoanThao: string;
    BanHanhThem: number;
    InfoVBDi: string;
    LoaiBanHanh: string;
    TenVanBan: string;
    CodeItemId: number;
    TrangThai: string;
    TrichYeu: string;
    ReceivedDate: string;
    Files: string;
    DocumentType: string;
    Modified: Date|null;
    Created: Date|null;
    ModifiedBy: string;
    CreatedBy: string;
    DoMat:string;
    PeopleText:string;
    DoKhan:string;
    DonVi:string;
    LTDonVi:string;
    CommentJson:string;
    ActionJson:string;
    ModuleId:number;
    YKien:string;
    TaskJson:string;
    constructor(data: any) {
        this.ID=data.ID;
        this.Title=data.Title,
        this.SoVanBan=data.SoVanBan,
        this.NguoiKyVanBanText=data.NguoiKyVanBanText;
        this.ChucVu=data.ChucVu;
        this.NguoiSoanThaoText = data.NguoiSoanThaoText;
        this.DonViSoanThao = data.DonViSoanThao;
        this.BanHanhThem = data.BanHanhThem;
        this.InfoVBDi = data.InfoVBDi;
        this.LoaiBanHanh = data.LoaiBanHanh;
        this.TenVanBan = data.TenVanBan;
        this.CodeItemId = data.CodeItemId;
        this.TrangThai = data.TrangThai;
        this.TrichYeu = data.TrichYeu;
        this.ReceivedDate = data.ReceivedDate;
        this.Files = data.Files;
        this.DocumentType = data.DocumentType;
        this.Modified =isNullOrEmpty(data.Modified)?null: new Date(data.Modified) ,
        this.Created = isNullOrEmpty(data.Created)?null: new Date(data.Created),
        this.ModifiedBy = data.ModifiedBy;
        this.CreatedBy = data.CreatedBy;
        this.DoMat=data.DoMat;
        this.PeopleText=data.PeopleText
        this.DoKhan=data.DoKhan;
        this.DonVi=data.DonVi;
        this.LTDonVi=data.LTDonVi;
        this.CommentJson=data.CommentJson;
        this.ActionJson=data.ActionJson;
        this.ModuleId=data.ModuleId;
        this.YKien=data.YKien;
        this.TaskJson=data.TaskJson;
    }
}
