import { Column, Entity, PrimaryColumn } from "typeorm";

// @ts-ignore
@Entity({name:'BeanSetting'})
export class BeanSetting {
  // @ts-ignore
  @PrimaryColumn({type: 'text'})
  public KEY:string="";
  // @ts-ignore
  @Column({type:'text'})
  public VALUE:string="";
  // @ts-ignore
  @Column({type:'text'})
  public DESC:string ="";
  // @ts-ignore
  @Column({type:'text'})
  public DEVICE:string="";
  // @ts-ignore
  @Column({type:'text'})
  public Modified:string="";
  constructor(data: any) {
    if (data) {
      this.KEY = data.KEY || 0;
      this.VALUE = data.VALUE || '';
      this.DESC = data.DESC || '';
      this.Modified = data.Modified || '';
      this.DEVICE = data.DEVICE || '';
      this.Modified = data.Modified || '';
    }
  }
  static fromJson(json: any): BeanSetting {
    return new BeanSetting(json);
  }

  static listFromJson(jsonArray: any[]): BeanSetting[] {
    return jsonArray.map((item) => new BeanSetting(item));
  }
}

