import {EntityRepository, Repository} from 'typeorm';
import { BeanBanLanhDao } from "../models/bean_ban_lanh_dao.ts";
import { BeanLoaiVanBan } from "../models/bean_loai_van_ban.ts";

// @ts-ignore
@EntityRepository(BeanLoaiVanBan)
export class BeanLoaiVanBanRepository extends Repository<BeanLoaiVanBan> {
  async insertAll(datas: BeanLoaiVanBan[]): Promise<void> {
    await this.manager.save(datas);
  }
  async findAll(): Promise<BeanBanLanhDao[]> {
    const queryString = `SELECT * FROM BeanLoaiVanBan`;
    return this.query(queryString);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanLoaiVanBan`;
    return this.query(queryString);
  }
}
