import { post } from "../api/api_client.ts";

export const getContactData = async (dataPost: FormData) => {
    const res = await post(
        '/_layouts/15/VuThao.Petrolimex.API/ApiDanhBa.ashx',
        {
            func: 'Search',
        },
        dataPost
    );
    if (res.data["status"] != "ERR") {
        return res.data["data"];
    }
    else {
        if (__DEV__)
            console.log('getContactData thất bại gòi')
        return null;
    }
};

export const getListUnitData = async (dataPost: FormData, type: number) => {
    const res = await post(
        '/_layouts/15/VuThao.Petrolimex.API/ApiDanhBa.ashx',
        {
            func: type === 1 ? 'GetListDonVi' : 'GetListPhongBan',
        },
        dataPost
    );
    if (res.data["status"] != "ERR") {
        console.log(res.data["data"])
        return res.data["data"];
    }
    else {
        if (__DEV__)
            console.log('getListUnitData thất bại gòi')
        return null;
    }
}
