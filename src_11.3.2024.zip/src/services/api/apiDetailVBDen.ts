import { get, post } from "./api_client.ts";
import { getCurrentTimeFormatted, isNullOrEmpty } from "../../utils/functions.ts";
import { EnumVanBanDenAction } from "../../config/enum.ts";
import { subsiteStore } from "../../config/constants.ts";
import { BeanVanBanDen } from "../database/models/beanVanBanDen.ts";
import { BeanComment } from "../database/models/beanComment.ts";

export const getDetailVBDenByID = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'get',
      rid: id,
      actionPer: 1,
      cmtv2: 1,
      department: 1,
      taskv2: 1,
      modified: getCurrentTimeFormatted()
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getAttFileVBDenByID = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'getAttachFiles',
      rid: id
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getTaskById = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'getTaskByIdv2',
      rid: id,
      modified: getCurrentTimeFormatted(),
      actionPer: 1
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getWorkflowHistoryOtherDepartment = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'getWorkflowHistoryOtherDepartment',
      rid: id
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getVBDenWorkflowHistory = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'VBDenGetWorkflowHistory',
      Params: 'ItemId',
      ItemId: id
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getViewerVBDen = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'VBGetViewer',
      Params: 'ItemId,ModuleId',
      ItemId: id,
      ModuleId: 3,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getVBDenWorkflowHistoryOtherDepartment = async (vbId: number, departmentId: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'expandThongTinLuanChuyenOtherDepartment',
      data: `{VBId:${vbId},LookupId:${departmentId}`
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getVBDenListTask = async (id: number, moduleID: number) => {
  const res = await get(
    '/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx',
    {
      func: 'getTasks',
      data: `{"ID":${id},"ModuleId":${moduleID}}`,//JSON.stringify({ ID: id, ModuleID: moduleID, }),
      rid: id,
    }
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const sendActionVanBanDen = async (action: number, _beanVanbanden: any) => {
  let obj;
  switch (action) {
    case EnumVanBanDenAction.RecallBOD:
    case EnumVanBanDenAction.CommentBOD:
    case EnumVanBanDenAction.Recall:
    case EnumVanBanDenAction.Completed:
    case EnumVanBanDenAction.Comment:
    case EnumVanBanDenAction.Forward:
    case EnumVanBanDenAction.FowardArchives: {
      obj = {
        ID: _beanVanbanden.ID,
        ModuleId: _beanVanbanden.ModuleId,
        YKien: _beanVanbanden.YKien
      };
      break;
    }
    case EnumVanBanDenAction.Assignment: {
      obj = {
        ID: _beanVanbanden.ID,
        ModuleId: _beanVanbanden.ModuleId,
        NguoiChuyen: _beanVanbanden.NguoiChuyen,
        YKien: _beanVanbanden.YKien,
        chkPhanCong: _beanVanbanden.chkPhanCong,
        chkCVP_TPTH: _beanVanbanden.chkCVP_TPTH,
        chkLanhDao: _beanVanbanden.chkLanhDao,
        NguoiNhan: _beanVanbanden.NguoiNhan,
        ListAssignmentUsers: _beanVanbanden.ListAssignmentUsers,
        ListAssignmentDept: _beanVanbanden.ListAssignmentDept,
        UserCC: _beanVanbanden.UserCC
      };
    }
      break;
    case EnumVanBanDenAction.SubmitBOD: {
      if (!isNullOrEmpty(subsiteStore.getSubsite())) {
        obj = {
          ID: _beanVanbanden.ID,
          ModuleId: _beanVanbanden.ModuleId,
          YKien: _beanVanbanden.YKien,
          chkLanhDaoValue: _beanVanbanden.chkCVP_TPTHValue,
          UserCC: _beanVanbanden.UserCC,
          UuTien: _beanVanbanden.UuTien
        };
      } else {
        obj = {
          ID: _beanVanbanden.ID,
          ModuleId: _beanVanbanden.ModuleId,
          YKien: _beanVanbanden.YKien,
          chkLanhDao: _beanVanbanden.chkLanhDao,
          chkCVP_TPTH: _beanVanbanden.chkCVP_TPTH,
          chkPhanCong: _beanVanbanden.chkPhanCong,
          chkLanhDaoValue: _beanVanbanden.chkLanhDaoValue,
          chkCVP_TPTHValue: _beanVanbanden.chkCVP_TPTHValue,
          UserCC: _beanVanbanden.UserCC,
          UuTien: _beanVanbanden.UuTien
        };
      }
    }
      break;
    case EnumVanBanDenAction.ReAssignment: {
      obj = {
        ID: _beanVanbanden.ID,
        ModuleId: _beanVanbanden.ModuleId,
        NguoiDanhGiaUserValue: _beanVanbanden.NguoiDanhGiaUserValue,
        YKien: _beanVanbanden.YKien,
        ListIDDelete: _beanVanbanden.ListIDDelete,
        ListAssignmentUsers: _beanVanbanden.ListAssignmentUsers
      };
    }
      break;
    case EnumVanBanDenAction.RecallOrForward: {
      obj = {
        ID: _beanVanbanden.ID,
        ModuleId: _beanVanbanden.ModuleId,
        YKien: _beanVanbanden.YKien,
        actionType: _beanVanbanden.actionType,
        ListAssignmentDept: _beanVanbanden.ListAssignmentDept,
        ListIDDelete: _beanVanbanden.ListIDDelete
      };
    }
      break;
    case EnumVanBanDenAction.Share: {
      obj = {
        ID: _beanVanbanden.ID,
        ModuleId: _beanVanbanden.ModuleId,
        YKien: _beanVanbanden.YKien,
        UserCC: _beanVanbanden.UserCC
      };
      break;
    }
  }
  let newData = new FormData();
  newData.append("data", JSON.stringify(obj));
  const res = await post(
    "/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanDenMobile.ashx",
    {
      func: "submit",
      action: action
    },
    newData
  );
  if (res.data["status"] != "ERR") {
    return true;
  } else {
    return false;
  }
};

export const getListShareVBDen = async (item: BeanVanBanDen) => {
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: 'Get',
      Action: 'VBDenUserShare',
      Params: "ModuleId,ItemId",
      ItemId: item.ID,
      ModuleId: item.ModuleId
    }
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanComment[];
  }
  else {
    if (__DEV__)
      console.log('getListShareVBDen thất bại gòi');
    return null;
  }

}