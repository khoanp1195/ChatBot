import { get, post } from './api_client.ts';
import { currentUserStore } from "config/constants.ts";

export const getDataListCalendar = async (limit: number, ofset: number, type: number) => {
  const res = await get('/_layouts/15/VuThao.Petrolimex.Calendar2023/API/ApiMobile.ashx',
    {
      tbl: 'ConfigGrid',
      func: 'GetData',
      byUser: true,
      data: `{"Parameters":{"Flag":${type}},"Options":{"skip":${ofset},"pageSize":${limit}}}`
    });
  if (res.data["status"] != "ERR") {
    return res.data['data']['DataItems'];
  } else {
    return null;
  }
}

export const getMeetingCalendars = async (fromDate: any, toDate: any, flag: number, keyConnection: any) => {
  
  let dataPost = new FormData()
  const obj = {
    FromDate : fromDate,
    ToDate: toDate,
    Flag: flag
  };

  dataPost.append("data",JSON.stringify(obj))
  const res = await post('/_layouts/15/VuThao.Petrolimex.Calendar2023/API/ApiHandler.ashx',
    {
      tbl: 'LichCongTacTuan',
      func: 'getMain',
      siteconnect: keyConnection,
    },
    dataPost
    );
  if (res.data["status"] != "ERR") {
    return res.data['data'];
  } else {
    return null;
  }
}
// https://petrolimex.vuthao.com/_layouts/15/VuThao.Petrolimex.Calendar2023/API/ApiHandler.ashx?tbl=LichCongTacTuan&func=getMain&siteconnect=Portal
//add 27.2.2024
export const getListDonVi = async () => {
  const res = await get('/_layouts/15/VuThao.Petrolimex.Calendar2023/API/ApiHandler.ashx'
    , {
      tbl: 'CD_SiteKeyConnection',
      func: 'GetAllData'
    });
  if (res.data["status"] != "ERR") {
    return res.data['data']
  }
  else {
    return null;
  }

}
