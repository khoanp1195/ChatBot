import { WorkflowAction } from "../../config/enum.ts";
import { get, post } from "../../services/api/api_client.ts";
import { getCurrentTimeFormatted } from "../../utils/functions.ts";
import { BeanComment } from "../database/models/beanComment.ts";
import { BeanHSLT } from "../database/models/beanHSLT.ts";
import { BeanVBDi } from "../database/models/beanVBDi.ts";

export const getDetailVBDi = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'get',
      rid: id,
      actionPer: 1,
      modified: getCurrentTimeFormatted()
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanVBDi;
  }
  else {
    return null;
  }
}

export const getAttFileVBDi = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getAttachFiles',
      rid: id,
      type: 1,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getIdeaOfBODv2 = async (id: number, SPItemId: number, SPListId: string) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getIdeaOfBODv2',
      rid: id,
      SPItemId: SPItemId,
      SPListId: SPListId,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getWorkflowHistoryVBDi = async (id: number, SPListId: string) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: 'getWorkflowHistoryv2',
      rid: id,
      SPListId: SPListId,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}
export const ActionHoSoTaiLieu = async (action: number, _beanCodeItem: BeanVBDi) => {
  let obj: any = {};
  obj.ID = _beanCodeItem.ID;
  obj.CodeItemId = _beanCodeItem.ID;
  switch (action) {
    case WorkflowAction.Reject:
    case WorkflowAction.Return:
    case WorkflowAction.Approve:
    case WorkflowAction.Next:
      obj.CommentValue = _beanCodeItem.CommentValue;
      obj.UserCC = _beanCodeItem.CCForm;
      break;
    case WorkflowAction.RequestInformation:
    case WorkflowAction.Forward:
      obj.CommentValue = _beanCodeItem.CommentValue;
      obj.ChooseUserValue = _beanCodeItem.ChooseUserValue;
      break;
    case WorkflowAction.Recall:
      obj.CommentValue = _beanCodeItem.CommentValue;
      break;
    case WorkflowAction.Share:
      obj.YKienTrinh = _beanCodeItem.YKienTrinh;
      obj.UserCC = _beanCodeItem.UserShared;
      break;
    default:
      break;
  }
  let dataPost = new FormData();
  dataPost.append("data", JSON.stringify(obj));
  const res = await post('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiDocMan.ashx',
    {
      func: "submit",
      action: action
    },
    dataPost
  );
  if (res.data["status"] != "ERR") {
    return true;
  } else {
    return false;
  }

}

export const getListShareVBDi = async (item: BeanVBDi) => {
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: 'Get',
      Action: 'VBDiUserShare',
      Params: "ModuleId,ItemId",
      ItemId: item.ID,
      ModuleId: item.ModuleId
    }
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanComment[];
  }
  else {
    if (__DEV__)
      console.log('getListShareVBDen thất bại gòi');
    return null;
  }
}

export const GetDetailHoSoluuTru=async(menuId:number)=>{
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: 'Get',
      Action: 'HSLTDetail',
      Params: "ID",
      ID: menuId,
    }
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"]["Data"] as BeanHSLT[];
  }
  else {
    if (__DEV__)
      console.log('GetDetailHoSoluuTru thất bại gòi');
    return null;
  }
}
