import * as types from './action_types.ts';
import { LOGIN_FAIL } from "./action_types.ts";

export const loginRequest = () => ({
  type: types.LOGIN_REQUEST,
});

export const loginSuccess = () => ({
  type: types.LOGIN_SUCCESS,
});
export const loginFail = () => ({
  type: types.LOGIN_FAIL,
});

export const logout = () => ({
  type: types.LOGOUT,
});
