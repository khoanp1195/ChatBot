export const HOME = 'HOME';
export const CALENDAR = 'CALENDAR';
export const UTILITIES = 'UTILITIES';
export const LeftMenuDangKyXuatAn = 'LeftMenuDangKyXuatAn';
export const LeftMenuTinNoiBo = 'LeftMenuTinNoiBo';
export const LeftMenuVeMayBay = 'LeftMenuVeMayBay';
