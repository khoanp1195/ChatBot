import { Dimensions, StyleSheet } from "react-native";

export const customStyles = StyleSheet.create({
    tableContentHeader: {
        flexDirection: 'row',
        fontWeight: 'bold',
        fontSize: 17,
        marginBottom:10
    },
    tableContentItemContainer: {
        flex: 1,
        flexDirection: 'row',
        padding: 10,
    }
})

let width = Dimensions.get('window').width
let height = Dimensions.get('window').height
export const menuOverlayStyle = StyleSheet.create({
    overlay: {
        backgroundColor: 'rgba(52, 52, 52, 0.8)',
        position: 'absolute',
        left: 0,
        top: 0,
        width: width,
        height: height,
        paddingTop: 10,
        paddingLeft: 10,
        paddingRight: 10,
        paddingBottom: 10
    }
});