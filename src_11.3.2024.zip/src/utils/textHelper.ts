import { isNullOrEmpty } from "./functions";

export const getTextSplit=(text:string,splitReg:string, positionTake:number)=>{
    if(!isNullOrEmpty(text)&& text.includes(splitReg))
    {
        return text.split(splitReg)[positionTake];
    }
    else
    {
        return text;
    }
}