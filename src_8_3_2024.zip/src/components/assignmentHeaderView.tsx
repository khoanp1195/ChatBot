import { Image, Pressable, Text, View } from "react-native";
import React from "react";

// @ts-ignore
export const AssignmentHeaderView = ({titleHeader,placeHolder,titleButton,imageButton ,onPress = () => {}}) => {

  return (<View>
    <Text
      style={{ fontWeight: "bold", fontSize: 15, color: "black", marginTop: 10 }}
    >{titleHeader}</Text>
    <Text style={{ textAlign: "center", color: "#999999", fontSize: 12, marginTop: 10 }}>
      {placeHolder}
    </Text>
    <View style={{ alignItems: "flex-end", marginTop: 10 }}>
      <Pressable
        onPress={() => onPress()}
        style={{ padding: 10, backgroundColor: "#0072C6", borderRadius: 2, flexDirection: "row" }}>
        <Image resizeMode={"contain"} style={{ height: 20, width: 20, marginRight: 10 }}
               source={imageButton} />
        <Text style={{ color: "white" }}>{titleButton}</Text>
      </Pressable>
    </View>
  </View>);
};
