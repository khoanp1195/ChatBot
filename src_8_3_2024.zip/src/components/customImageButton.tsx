import { Image, Pressable, StyleSheet, Text, View } from "react-native"

//@ts-ignore
export const CustomImageButton = ({ imgPath, imgColor=null, isCirle = false, onClickHandle = () => { } }) => {

    return <Pressable
        style={[styles.parentContainer]}
        onPress={() => {
            onClickHandle()
        }}>
        {
            imgColor==null?
              <Image
                source={imgPath}
                style={(isCirle ? styles.circle : styles.normal)}
                resizeMode='contain'
              />:
              <Image
                source={imgPath}
                style={(isCirle ? styles.circle : styles.normal)}
                resizeMode='contain'
                tintColor={imgColor}
              />
        }
    </Pressable >
}

const styles = StyleSheet.create({
    parentContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center',
        margin: 5,
    },
    circle: {
        flex: 1,
        aspectRatio: 1,
        borderRadius: 999,
    },
    normal: {
        flex: 1,
        aspectRatio: 1,
    },
})
