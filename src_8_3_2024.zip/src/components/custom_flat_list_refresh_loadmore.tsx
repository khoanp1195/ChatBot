import React, { useEffect, useState, useCallback } from "react";
import { ActivityIndicator, FlatList, RefreshControl, Text, View } from "react-native";
import { useSelector } from "react-redux";
import EmptyView from "../components/empty_view.tsx";
import { appMainBlueColor } from "../utils/color.ts";

// @ts-ignore
export const CustomFlatListRefreshLoadMore = ({ callData, ItemRenderFlatlist, limit, enableMoreData, numColumn }) => {
  const [data, setData] = useState([]);
  const [isLoadingMore, setIsLoadingMore] = useState(enableMoreData);
  const [isLoading, setIsLoading] = useState(true);
  const [offset, setOffset] = useState(0);
  const [hasMoreData, setHasMoreData] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false); // Trạng thái "refreshing"

  const onDeleteItem = (index: number) => {
    // Remove the item at the specified index
    const newData = [...data];
    newData.splice(index, 1);
    setData(newData);
  };

  useEffect(() => {
    fetchData();
  }, [isLoadingMore]);

  const fetchData = useCallback(async () => {
    try {
      const newData = await callData(limit, offset);
      if (newData == undefined || (newData.length === 0 || newData.length < limit)) {
        // Nếu số lượng item trả về ít hơn limit hoặc bằng 0
        if (data.length != 0) {
          // @ts-ignore
          setData((prevData) => [...prevData, ...newData]);
        } else {
          setData(newData);
        }
        setHasMoreData(false);
      } else {
        if (enableMoreData) {
          // @ts-ignore
          setData((prevData) => [...prevData, ...newData]);
          setOffset((prevOffset) => prevOffset + limit);
        } else {
          setData(newData);
          setHasMoreData(false);
        }
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoadingMore(false);
      setIsRefreshing(false); // Khi kết thúc "refresh", cần đặt lại trạng thái
    }
    setIsLoading(false);

  }, [offset]);

  const handleRefresh = useCallback(() => {
    setOffset(0); // Đặt lại offset để làm mới toàn bộ danh sách
    setIsLoading(true);
    setIsRefreshing(true);
    setHasMoreData(true); // Đặt lại trạng thái có thêm dữ liệu
    setData([]); // Xóa dữ liệu hiện tại
    fetchData(); // Gọi lại fetchData để tải dữ liệu mới
  }, []);

  return (
    <View style={{ height: '100%', backgroundColor: 'white' }}>
      {
        data != null && data.length > 0 && !isLoading ?
          <FlatList
            numColumns={numColumn}
            initialNumToRender={15}
            data={data}
            renderItem={({ item, index }) => (
              <ItemRenderFlatlist
                item={item}
                index={index}
                onDeleteItem={onDeleteItem}
              />
            )}
            onEndReachedThreshold={0.1}
            // @ts-ignore
            ListFooterComponent={isLoadingMore && (
              <ActivityIndicator size="large" color={appMainBlueColor} />
            )}
            onEndReached={() => {
              if (hasMoreData && !isLoadingMore) {
                setIsLoadingMore(true);
              }
            }}
            refreshControl={
              <RefreshControl
                refreshing={isRefreshing}
                onRefresh={handleRefresh}
                colors={[appMainBlueColor]} // Màu sắc của chỉ báo "refresh"
                tintColor={appMainBlueColor} // Màu sắc của chỉ báo "refresh"
              />
            }
          />
          : (isLoading ?
            enableMoreData && <ActivityIndicator size="large" color={appMainBlueColor} /> :
            <View style={{ marginTop: "50%", height: "40%" }}>
              <EmptyView />
            </View>)
      }
    </View>
  );
};
