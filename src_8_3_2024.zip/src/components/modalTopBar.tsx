import { Image, Text, TouchableOpacity, View } from "react-native";
import { appMainBlueColor } from "../utils/color";

// @ts-ignore
export const ModalTopBar = ({ title, onPress, rightAction = <View />, isTitleCenter = false }) => {
  return <View style={{ backgroundColor: 'white' }}>
    <View style={{ flexDirection: 'row', height: 60, alignItems: 'center' }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
        <TouchableOpacity onPress={() => {
          onPress();
        }}>
          <Image resizeMode={'contain'} source={require('../assets/images/icon_back30.png')} tintColor={"#0072C6"} style={{ height: 25, width: 25, marginLeft: 15 }} />
        </TouchableOpacity>
        <Text style={!isTitleCenter ? { color: appMainBlueColor, marginLeft: 15, fontSize: 18 } : { color: appMainBlueColor, textAlign: 'center', flex: 1, fontSize: 16 }}>{title}</Text>
      </View>
      <View style={{ marginRight: 15 }}>
        {rightAction}
      </View>
    </View>
    <View style={{ height: 1, width: '100%', backgroundColor: '#E9E9E9' }} />
  </View>
}
