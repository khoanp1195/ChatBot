import AsyncStorage from '@react-native-async-storage/async-storage';
import { isNullOrEmpty } from "./functions.ts";

export const saveCredentials = async (username: string, password: string) => {
  try {
    await AsyncStorage.setItem('username', username);
    await AsyncStorage.setItem('password', password);
    if (__DEV__) {
      console.log(`Lưu thông tin thành công.${username} / ${password}`);
    }
  } catch (error) {
    if (__DEV__) {
      console.error('Lỗi khi lưu thông tin:', error);
    }
  }
};
export const getUsername = async () => {
  try {
    return await AsyncStorage.getItem('username');
  } catch (error) {
    console.error('Lỗi khi lấy thông tin:', error);
    return null;
  }
};

export const getPassword = async () => {
  try {
    return await AsyncStorage.getItem('password');
  } catch (error) {
    console.error('Lỗi khi lấy thông tin:', error);
    return null;
  }
};

export const saveCookie = async (cookie: string) => {
  try {
    await AsyncStorage.setItem('cookie', cookie);
    if (__DEV__) {
      console.log('saveCookie thành công.');
    }
  } catch (error) {
    if (__DEV__) {
      console.error('saveCookie Error:', error);
    }
  }
};
export const getCookie = async () => {
  try {
    return await AsyncStorage.getItem('cookie');
  } catch (error) {
    console.error('getCookie error:', error);
    return null;
  }
};

export const saveModified=async (modified:string) => {
  try {
    await AsyncStorage.setItem('Modified',modified);
    console.log('saveModified thành công.');
  } catch (error) {
    console.error(' saveModified error', error);
  }
}

export const getModified = async () => {
  try {
    const data=await AsyncStorage.getItem('Modified');
    return isNullOrEmpty(data)?"":data!;
  } catch (error) {
    console.error('getModified Error:', error);
    return "";
  }
};

export const saveSubSite=async (subSite:string) => {
  try {
    await AsyncStorage.setItem('subSite',subSite);
    console.log(`saveSubSite thành công. ${subSite}`);
  } catch (error) {
    console.error(' saveSubSite error', error);
  }
}

export const getSubSite = async () => {
  try {
    const data=await AsyncStorage.getItem('subSite');
    return isNullOrEmpty(data)?"":data!;
  } catch (error) {
    console.error('getSubSite Error:', error);
    return "";
  }
};
