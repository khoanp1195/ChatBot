// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { isNullOrEmpty } from "../utils/functions.ts";

const DEV_URL = 'https://petrolimex.vuthao.com';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const UAT_URL = 'https://daotaoeoffice.petrolimex.com.vn';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const LIVE_url = 'https://eoffice.petrolimex.com.vn'; // LIVE
export const BaseSubSite = '';
export const BASE_URL = UAT_URL;
export const subsiteStore = {
  subsite: BaseSubSite, // Initial value is an empty string

  getSubsite: function () {
    return this.subsite;
  },

  setSubsite: function (newSubsite: string) {
    this.subsite = newSubsite;
  },
};

export const getFullLink = () => {
  var subsite: string = subsiteStore.getSubsite()
  return BASE_URL + (!isNullOrEmpty(subsite) ? "/" + subsite : "");
}
export const cookieStore = {
  cookie: '', // Initial value is an empty string

  getCookie: function () {
    return this.cookie;
  },

  setCookie: function (newCookie: string) {
    this.cookie = newCookie;
  },
};
export const modifiedStore = {
  modified: '', // Initial value is an empty string

  getModified: function () {
    return this.modified;
  },

  setModified: function (newModified: string) {
    this.modified = newModified;
  },
};
export const currentUserStore = {
  currentUser: {
    Position: "",
    ImagePath: "",
    DefaultSite: "",
    SiteName: "",
    Title: "",
    AccountID: "",
    Birthday:""
  },

  getCurrentUser: function () {
    return this.currentUser;
  },

  setCurrentUser: function (newCurrentUser: any) {
    this.currentUser = newCurrentUser;
  },
};
export const currentDateFormat = "yyyy-mm-ddTHH:MM:SS"
