import { get } from "./api_client.ts";
import { BeanBanLanhDao } from "../database/models/bean_ban_lanh_dao.ts";
import { DbServices } from "../database/db_service.ts";
import { BeanSettingRepository } from "../database/repositories/bean_setting_repository.ts";
import { BeanSetting } from "../database/models/bean_setting.ts";
import { BeanDepartment } from "../database/models/bean_department.ts";
import { BeanCoQuanGui } from "../database/models/bean_co_quan_gui.ts";
import { BeanLoaiVanBan } from "../database/models/bean_loai_van_ban.ts";
import { BeanNguoiKyVanBan } from "../database/models/bean_nguoi_ky_van_ban.ts";
import { BeanUser } from "../database/models/bean_user.ts";
import { BeanGroup } from "../database/models/bean_group.ts";
import { currentUserStore } from "../../config/constants.ts";

export const getBanLanhDao = async (Modified: string, isFirst: string) => {
  const res = await get("/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "getV2",
      type: 1,
      lname: "Ban lãnh đạo",
      cols: "[\"ID\", \"Title\", \"DonVi\", \"Modified\", \"Created\", \"LanhDao\", \"UyQuyen\", \"Orders\", \"Group\", \"OneAssign\", \"ThayThe\"]",
      wname: "vanban",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanBanLanhDao.listFromJson(res["data"]["data"]);
        await DbServices.getInstance().getBanLanhDaoRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};

export const getSetting = async (Modified: string, isFirst: string) => {
  const res = await get("/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "getSettings",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanSetting.listFromJson(res["data"]["data"]);
        if (data != null)
          await DbServices.getInstance().getBeanSettingRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};

export const getDepartment = async (Modified: string, isFirst: string) => {
  const res = await get("/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "getV2",
      type: 2,
      bname: "BeanDepartment",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanDepartment.listFromJson(res["data"]["data"]);
        if (data != null)
          await DbServices.getInstance().getBeanDepartmentRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getCoQuanGui = async (Modified: string, isFirst: string) => {
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "get",
      lname: "Cơ quan gửi",
      type: 1,
      cols: "[\"ID\",\"Title\",\"Parent\",\"Order\"]",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanCoQuanGui.listFromJson(res["data"]["data"]);
        await DbServices.getInstance().getBeanCoQuanGuiRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getLoaiVanBan = async (Modified: string, isFirst: string) => {
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "get",
      lname: "Loại văn bản",
      type: 1,
      cols: "[\"ID\",\"Title\",\"Orders\"]",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanLoaiVanBan.listFromJson(res["data"]["data"]);
        if (data != null)
          await DbServices.getInstance().getBeanLoaiVanBanRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getNguoiKyVanBan = async (Modified: string, isFirst: string) => {
  const res = await get(
    "/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobilePublic.ashx",
    {
      func: "get",
      lname: "Người ký văn bản",
      type: 1,
      cols: "[\"ID\",\"Title\",\"IsHidden\"]",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanNguoiKyVanBan.listFromJson(res["data"]["data"]);
        await DbServices.getInstance().getBeanNguoiKyVanBanRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getUsers = async (Modified: string, isFirst: string) => {
  const res = await get(
    "/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: "Get",
      Params: "BeanName,Modified",
      Action: "DanhMuc",
      BeanName: "BeanUser",
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanUser.listFromJson(res["data"]["data"]);
        await DbServices.getInstance().getBeanUserRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getGroups = async (Modified: string, isFirst: string) => {
  const res = await get(
    "/_layouts/15/VuThao.Petrolimex.API/ApiUser.ashx",
    {
      func: "get",
      type: 2,
      Modified: Modified,
      isFirst: isFirst
    });
  if (res.data["status"] != "ERR") {
    if (res["data"] != null && res["data"]["data"] != null) {
      if (res["data"]["data"].length > 0) {
        const data = BeanGroup.listFromJson(res["data"]["data"]);
        await DbServices.getInstance().getBeanGroupRepository().insertAll(data);
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
};
export const getCurrentUser = async () => {
  const res = await get(
    "/_layouts/15/VuThao.Petrolimex.API/ApiUser.ashx",
    {
      func: "CurrentUser"
    });
  if (res.data["status"] != "ERR") {
    currentUserStore.setCurrentUser(res.data["data"]);
    return res.data["data"];
  } else {
    return null;
  }
};
