export class HealthType{
    ID: number;
    Name: string;
    Value: string;
    ValueType: string;
    KeyType: string;
    ImagePath: string;
    ImageResource: any;

    constructor(ID: number, Name: string, Value: string, ValueType: string, ImagePath: string, ImageResource: any, KeyType: string) {
        this.ID = ID;
        this.Name = Name;
        this.Value = Value;
        this.ValueType = ValueType;
        this.ImagePath = ImagePath;
        this.ImageResource = ImageResource;
        this.KeyType = KeyType;
    }
}