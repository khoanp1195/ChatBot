import { useSelector } from 'react-redux';
import { Platform, SafeAreaView, View } from 'react-native';
import LoginScreen from '../screens/login/login_screen.tsx';
import { AppNavigation } from "./app_navigation.tsx";
import { DrawerNavigation } from "../navigation/drawer_navigation.tsx";
export const AuthNavigation = () => {
  const isAuth = useSelector((state: any) => state.login.isAuth);

  const NavigateToView = () => {
    return (
      <View style={{ flex: 1 }}>
        {!isAuth ? <LoginScreen /> : <DrawerNavigation />}
      </View>
    )
  }

  return Platform.OS == 'android' ? (
    <NavigateToView />
  ) : (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: 'white',
        width: '100%',
        height: '100%',
        marginBottom: 0,
        marginTop: 35,
      }}>
      <NavigateToView />
    </SafeAreaView >
  );
};
