import * as types from './action_types.ts';

export const startChangeSite = () => ({
  type: types.START_CHANGE_SITE,
});

export const endChangeSite = () => ({
  type: types.END_CHANGE_SITE,
});
export const startLoading = () => ({
  type: types.START_CHANGE_SITE,
});

export const endLoading= () => ({
  type: types.END_CHANGE_SITE,
});
