import {combineReducers} from 'redux';
import loginReducer from './login/reducer';
import leftMenuReducer from "./leftmenu/reducer.ts";
import baseScreenReducer from "./base_screen/reducer.ts";
import loadingReducer from "./loading/reducer.ts";
import typeTinnoBoReducer from "./tinnoibo/reducer.ts";
import typeVeMayBayReducer from "./vemaybay/reducer.ts";
import typeLichTuanReducer from './lichtuan/reducer.ts';
const rootReducer = combineReducers({
  login: loginReducer,
  leftMenu:leftMenuReducer,
  baseScreen:baseScreenReducer,
  loading:loadingReducer,
  tinNoiBo:typeTinnoBoReducer,
  veMayBay:typeVeMayBayReducer,
  lichtuan:typeLichTuanReducer
});

export default rootReducer;
