import { CHANGE_DONVI } from "./action_types.ts";
import { TypeDatVeMayBay } from "../../config/enum.ts";

const initialState = {
  item: [],
  title: '',
  reload : false
};

const typeLichTuanReducer = (state = initialState,   action: any) => {
  switch (action.type) {
    case CHANGE_DONVI:
      return {
        ...state,
        item: action.payload,
        reload: true
      };
    default:
      return state;
  }
};

export default typeLichTuanReducer;
