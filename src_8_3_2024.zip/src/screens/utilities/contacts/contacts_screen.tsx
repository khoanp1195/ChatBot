import { CircleButton } from "../../../components/circleButton";
import { memo, useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Alert, Keyboard, Linking, Pressable, SectionList, StyleSheet, Text, TextInput, View } from "react-native";
import { Image } from "react-native-elements";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation } from "@react-navigation/native";
import { appMainBlueColor } from "../../../utils/color.ts";
import { getListItemBackground, isNullOrEmpty, mapLstDataIntoListSection } from "../../../utils/functions.ts";
import { getContactData, getListUnitData } from "../../../services/api/api_contacts.ts";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
// @ts-ignore
import EmptyView from "../../../components/empty_view.tsx";
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";

export const ContactsScreen = memo(() => {
  const navigation = useNavigation();
  const [DATA, setData] = useState([])
  const [expandedSections, setExpandedSections] = useState(new Set());
  const [searchKey, setSearchKey] = useState("")
  const [urlUnit, setUrlUnit] = useState("")
  const [unitTitle, setUnitTitle] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isFirst, setIsFirst] = useState(true)

  useEffect(() => {
    if (isFirst) {
      getListUnit().then(value => {
        console.log('site unit nè: ' + value.toString())
        setUrlUnit(value.toString())
        getContact().then(contacts => {
          // @ts-ignore
          setData(contacts)
          setIsFirst(false);
          setIsLoading(false);
        });
      });

    }
    else {
      setUrlUnit(urlUnit)
      getContact().then(contacts => {
        // @ts-ignore
        setData(contacts);
        setIsLoading(false);
      });
    }
  }, [urlUnit]);

  const createSectionList = (data: any, item: any) => {
    if (item && data) {
      const items = data.filter(
        //@ts-ignore
        (r) =>
          (r.URL === null || r.URL === "") &&
          r.ParentDept != null &&
          r.ParentDept.split(";")[0] === item.ID.toString()
        //@ts-ignore
      ).map((record) => ({
        ...record,
        level: item.level
      }));

      if (items?.length > 0) {
        item.children = items;
        item.isUser = false;
        item.dummyID = item.ID;
        for (let index = 0; index < item.children.length; index++) {
          const element = item.children[index];
          element.level = element.level + 1
          element.isExpanded = element.level === 1
          createSectionList(data, element);
        }
      } else {
        if (item.MultipleManagers?.length > 0) {
          //@ts-ignore
          item.MultipleManagers.forEach((r) => {
            item.children.push({
            });
          });
        }
      }
    }
  };

  const getContact = async () => {//limit: number, offset: number
    setIsLoading(true)

    const dataPost = {
      urlDonVi: urlUnit,
      PhongBan: "",
      KeySearch: searchKey,
      Limit: -1,//limit, ///Truyền -1 để lấy all
      Offset: 0,// offset, /// luôn =0 do không có loadmore
    };

    let newData = new FormData();
    newData.append("data", JSON.stringify(dataPost));

    const retData = await getContactData(newData);
    if (retData !== null && retData.Data !== null) {
      const uniqueTitles = mapLstDataIntoListSection(retData.Data, "DepartmentECard");
      console.log("Group nè", JSON.stringify(uniqueTitles));
      return uniqueTitles;// retData.Data;
    } else {
      return [];
    }

  };

  const getListUnit = async () => {
    const dataPost = {
      urlDonVi: urlUnit,
    };

    let newData = new FormData();
    newData.append("data", JSON.stringify(dataPost));

    const retData = await getListUnitData(newData, 1)
    var url = getFullLink();

    try {
      if (retData !== null) {
        // var res = JSON.parse(retData.data)
        if (retData.Data !== null) {

          //@ts-ignore
          retData.Data.forEach(element => {
            if (!isNullOrEmpty(element.Url) && element.Url == url) {
              setUnitTitle(element.TenToChucVN)

              // setUrlUnit(element.Url)

              return element.Url;
            }
          });
        }
      } else {
      }
    }
    catch (ex) {
      console.error(ex);
    }

    // setUrlUnit(url)
    return url;
  }

  //@ts-ignore
  const OnClickExpandHeader = (title) => {
    console.log('expand nè')
    handleToggle(title)
  }

  const OnClickChooseUnit = () => {
    if (__DEV__) console.log('Chọn đơn vị nè')

    // @ts-ignore
    navigation.navigate("ChooseContactUnitScreen",
      {
        url: urlUnit,
        onSelected: (title: string, url: string) => {
          setUnitTitle(title)
          setUrlUnitFromList(url);
        }
      });
  }

  const setUrlUnitFromList = (url: string) => {
    setUrlUnit(url);
  }

  //@ts-ignore
  const ItemContact = ({ item, index }) => {
    return (
      <View style={{
        backgroundColor: getListItemBackground(index % 2 != 0),
        flex: 1,
        flexDirection: 'row',
        padding: 10,
      }}>
        <View
          style={{
            flex: 1,
            marginHorizontal: 5,
          }}>
          {
            !isNullOrEmpty(item.Img) ?
              <CustomFastImage
                urlOnline={getFullLink() + item.Img}
                defaultImage={require("../../../assets/images/avatar80.jpg")}
                styleImg={styles.imgStyle}
                resizeMode={'stretch'} />
              :
              <Image
                style={styles.imgStyle}
                source={require('../../../assets/images/avatar80.jpg')}
                resizeMode="stretch"
              />
          }
        </View>
        <View
          style={{
            flex: 3,
            marginHorizontal: 5,
          }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: 'bold' }}>{item.FullName}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text>{item.Position}</Text>
          </View>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <Text style={styles.greyText}>Số ĐT nội bộ: </Text><Text>{item.Ext}</Text>
          </View>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <Text style={styles.greyText}>Số ĐT di động: </Text>
            <Pressable onPress={() => {
              console.log('====================================');
              console.log('Nhấn Số di động ' + item.Mobile);
              console.log('====================================');
              openSharedApplication(`tel:${item.Mobile}`)
            }}>
              <Text style={styles.focusedText}> {item.Mobile}</Text>
            </Pressable>
          </View>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <Text style={styles.greyText}>Email: </Text>
            <Pressable onPress={() => {
              console.log('====================================');
              console.log('Nhấn email ' + item.Email);
              console.log('====================================');
              openSharedApplication(`mailto::${item.Email}`)
            }}>
              <Text style={styles.focusedText}>{item.Email}</Text>
            </Pressable>
          </View>
        </View>
      </View>)
  }
  const openSharedApplication = async (linkUrl: string) => {
    //@ts-ignore
    if (Linking.canOpenURL(linkUrl))
      Linking.openURL(linkUrl)
  }

  //@ts-ignore
  const HeaderContact = ({ title, isExpand, itemCount }) => {
    return (<Pressable
      style={{
        height: 40,
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        alignContent: 'center',
        backgroundColor: '#F5F5F5'
      }}
      onPress={() => { OnClickExpandHeader(title) }}>
      <View style={{ flex: 5, marginHorizontal: 5, }}>
        <Text style={{
          fontWeight: 'bold',
          color: 'black'
        }}>{title}</Text>
      </View>
      <View style={[{
        // flex: 1,
        alignItems: 'center',
        alignContent: 'center',
        alignSelf: 'center',
        padding: 5,
        borderRadius: 20,
        borderWidth: 1,
        justifyContent: 'center',
        paddingVertical: 5,
      }, styles.circleShape]}>
        <Text style={[{
          flex: 1,
          color: 'white',
          alignContent: 'center',
          textAlign: 'center',
          fontSize: 15,
          alignItems: 'center',
          flexWrap: 'wrap',
        }]}>
          {itemCount}
        </Text>
      </View>
      <View style={{
        flex: 0.5,
        alignSelf: "flex-end",
        alignContent: 'center',
        flexDirection: "row-reverse",
        padding: 10,
      }}>
        <CircleButton
          path={isExpand ? require("../../../assets/images/icon_file_expand.png") : require("../../../assets/images/icon_leftmenu_user_next.png")}
          title=''
          onClick={() => { OnClickExpandHeader(title) }}
        />
      </View>
    </Pressable>)
  }

  //@ts-ignore
  const handleToggle = (title) => {
    setExpandedSections((expandedSections) => {
      // Using Set here but you can use an array too
      const next = new Set(expandedSections);
      if (next.has(title)) {
        next.delete(title);
      } else {
        next.add(title);
      }
      return next;
    });
  };
  return (
    // <Pressable
    //   style={{ flex: 1, backgroundColor: 'white' }
    //   }
    //   onPress={Keyboard.dismiss}
    // >
    <View style={{ flex: 1, backgroundColor: 'white' }} >
      <ModalTopBar
        title={"Danh bạ"}
        onPress={() => {
          //dispatch(showLeftMenuUtilities());
          // @ts-ignore
          if (navigation.canGoBack())
            navigation.goBack();
        }} />

      <View style={{
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: 'lightgrey'
      }}>
        <View style={styles.searchBar}>
          <Image
            style={{
              // flex: 1,
              height: '50%',
              aspectRatio: 1,
              marginLeft: 10,
              justifyContent: 'center',
              // backgroundColor: 'cyan'
            }}
            source={require('../../../assets/images/icon_search26.png')}
            resizeMode="stretch"
          />
          < TextInput
            style={styles.input}
            placeholder="Tên, Email hoặc số điện thoại"
            autoCapitalize="none"
            value={searchKey}
            onChangeText={(text) => setSearchKey(text)} />
        </View>

      </View>

      <Pressable style={styles.btnUnit} onPress={() => { OnClickChooseUnit() }}>
        <Image
          style={{
            // flex: 1,
            height: '50%',
            aspectRatio: 2 / 3,
            marginLeft: 10,
            justifyContent: 'center',
            // backgroundColor: 'cyan'
          }}
          source={require('../../../assets/images/icon_focus_contact.png')}
          resizeMode="stretch"
        />
        <Text style={{ fontWeight: 'bold' }}>{unitTitle}</Text>
      </Pressable>

      {
        DATA != null && DATA.length > 0 ?
          <View style={{
            flex: 1,
          }}>
            <SectionList
              sections={DATA}
              // @ts-ignore
              extraData={expandedSections}
              keyExtractor={(item, index) => item + index}
              renderItem={({ section: { title }, item, index }) => {// check to see if the section is expanded
                const isExpanded = !expandedSections.has(title);

                //return null if it is
                if (!isExpanded) return null;

                return <ItemContact item={item} index={index} />;
              }
              }
              renderSectionHeader={({ section: { title, data } }) => {
                const isExpanded = !expandedSections.has(title);
                // @ts-ignore
                return <HeaderContact title={title} isExpand={isExpanded} itemCount={data.length} />;
              }
              }
            />

            {/* <FlatList
              scrollEnabled={true}
              // @ts-ignore
              keyExtractor={(item, index) => item + index}
              data={DATA}
              numColumns={1}
              // @ts-ignore
              // getItemCount={DATA.length}
              renderItem={({ item, index }) => {
                return <ItemContact item={item} index={index} />;
              }
              }
            /> */}
          </View>
          : isLoading
            ? <ActivityIndicator size="large" color={appMainBlueColor} />
            : <EmptyView />
      }
      {/* </Pressable> */}
    </View>
  )

})

const styles = StyleSheet.create({
  rootContainer: {
    height: "100%",
    backgroundColor: "white"
  },
  searchBar: {
    height: 40,
    backgroundColor: "#f5f5f5",
    marginHorizontal: 5,
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
  },
  input: {
    // height: 30,
    fontSize: 14,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    flex: 1,
    borderRadius: 6,
  },
  btnUnit: {
    height: 50,
    flexDirection: 'row',
    alignSelf: 'flex-start',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 5,
  },
  circleShape: {
    marginTop: 5,
    width: 30,
    height: 30,
    borderRadius: 30 / 2,
    borderColor: appMainBlueColor,
    backgroundColor: appMainBlueColor,
  },
  focusedText: { color: appMainBlueColor },
  greyText: { color: 'grey' },
  imgStyle: {
    flex: 1,
    aspectRatio: 4 / 5,
    alignItems: 'flex-start',
    justifyContent: 'center',
    borderRadius: 6,
  },
});
