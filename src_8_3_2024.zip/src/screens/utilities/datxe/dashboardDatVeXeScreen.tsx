import { Dimensions, Image, Pressable, Text, TouchableOpacity, View } from "react-native";
import { PetroAppBarCustom } from "../../../components/petro_appbar_custom.tsx";
import { showLeftMenuHome, showLeftMenuVeMayBay } from "../../../stores/leftmenu/actions.ts";
import { useDispatch, useSelector } from "react-redux";
import { TypeDatVeMayBay } from "../../../config/enum.ts";
import React, { FC, useEffect } from "react";
import { getDataByType } from "../../../services/api/apiDatVeMayBay.ts";
import { CustomFlatListRefreshLoadMore } from "../../../components/custom_flat_list_refresh_loadmore.tsx";
import { convertStringToMoment, getListItemBackground } from "../../../utils/functions.ts";
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";
import { BASE_URL, subsiteStore } from "../../../config/constants.ts";
import { useNavigation } from "@react-navigation/native";

export const DashboardDatVeXeScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const type = useSelector((state: any) => state.veMayBay.item);

  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const width = Dimensions.get("window").width;
    return <Pressable onPress={() => {
      // @ts-ignore
      navigation.navigate("DetailDatVeXeScreen", {
        item: item
      });
    }}>
      <View style={{ backgroundColor: getListItemBackground(index % 2 != 0), padding: 10, flexDirection: 'row' }}>
        <CustomFastImage
          styleImg={{ height: 40, width: 40, borderRadius: 100, marginRight: 10 }}
          urlOnline={BASE_URL + "/" + subsiteStore.getSubsite() + item.ImagePath}
          defaultImage={require("../../../assets/images/avatar80.jpg")}
        />
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', marginBottom: 5 }}>
            <Text style={{ flex: 2, textAlign: 'left', fontSize: 15, color: 'black', fontWeight: "400" }} numberOfLines={1}>{item.FullName}</Text>
            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center', justifyContent: 'flex-end' }}>
              <Text style={{ textAlign: 'right', fontSize: 12 }} numberOfLines={1}>{item.FromDate != null ? convertStringToMoment(item.FromDate).format("DD/MM/YY") : ""}</Text>
              {(item.FromDate != null && item.ToDate != null) && <Text style={{ fontSize: 12 }} numberOfLines={1}> - </Text>}
              <Text style={{ textAlign: 'right', fontSize: 12 }} numberOfLines={1}>{item.ToDate != null ? convertStringToMoment(item.ToDate).format("DD/MM/YY") : ""}</Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', marginBottom: 5 }}>
            <Text style={{ flex: 1, textAlign: 'left', fontSize: 12, color: '#5E5E5E', fontWeight: "400" }} numberOfLines={1}>{item.Type}</Text>
            <Text style={{ flex: 1, textAlign: 'right', fontSize: 12, color: '#5E5E5E', fontWeight: "400" }} numberOfLines={1}>{item.Location}</Text>
          </View>
          <Text style={{ textAlign: 'left', fontSize: 15, color: 'black', fontWeight: "400", marginBottom: 5 }} numberOfLines={2}>{item.Subject}</Text>
          <View style={{ flexDirection: 'row' }}>
            <Text style={{ textAlign: 'left', fontSize: 12, color: 'black', fontWeight: "400", padding: 5, backgroundColor: '#A5DEFF', borderRadius: 5 }} numberOfLines={1}>{item.StatusText}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  };
  const getData = async (limit: number, offset: number) => {
    const data = await getDataByType(type, limit, offset);
    if (data != null) {
      return data;
    } else {
      return [];
    }
  };
  return <View style={{ marginBottom: 10 }}>
    <PetroAppBarCustom
      title={type}
      onPress={() => {
        dispatch(showLeftMenuVeMayBay());
        // @ts-ignore
        navigation.openDrawer();
        // navigation.dispatch(DrawerActions.openDrawer())
      }} />
    <CustomFlatListRefreshLoadMore key={type} ItemRenderFlatlist={RenderItem} limit={10}
      callData={getData}
      enableMoreData={true} numColumn={1} />
  </View>
}
