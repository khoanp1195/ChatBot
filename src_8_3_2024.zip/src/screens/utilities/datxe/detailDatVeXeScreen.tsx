import { Text, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import React, { useEffect, useRef, useState } from "react";
import { getFullLink } from "../../../config/constants.ts";
import { WebView } from "react-native-webview";
import { DbServices } from "../../../services/database/db_service.ts";
import { isNullOrEmpty } from "../../../utils/functions.ts";

export const DetailDatVeXeScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const [title, setTitle] = useState("");
  const [currentUrl, setCurrentUrl] = useState("");
  const [url, setUrl] = useState("");
  const webViewRef = useRef(null);
  // @ts-ignore
  const item = route.params["item"];
  
  useEffect(() => {
    if (item != null) {
      if(item.Type.includes("Đổi vé"))
      {
        setTitle("Đổi vé máy bay");
      }
      if (isNullOrEmpty(item.ItemUrlMobile)) {
        if (item.Step != -1) {
          DbServices.getInstance().getBeanSettingRepository().findByKey("Mobile_LinkVeMayBayByIID").then(value => {
            const UrlReplaceID = value[0].VALUE.replace("{0}", item.ID);
            setUrl(UrlReplaceID);
          });
        } else {
          DbServices.getInstance().getBeanSettingRepository().findByKey("Mobile_LinkDangKyVeMayBay").then(value => {
            setUrl(value[0].VALUE);
          });
        }
      } else {
        setUrl(item.ItemUrlMobile);
      }
      setCurrentUrl(item.ItemUrlMobile);
    } else {
      setTitle("Đăng ký vé máy bay");
      DbServices.getInstance().getBeanSettingRepository().findByKey("Mobile_LinkDangKyVeMayBay").then(value => {
        setUrl(value[0].VALUE);
        setCurrentUrl(value[0].VALUE);
      });
    }

  }, []);


  const navigationGoBack = () => {
    if (item != null && !currentUrl.includes(item.ItemUrlMobile)) {
      // @ts-ignore
      webViewRef.current.injectJavaScript(`window.location.href = '${getFullLink() + item.ItemUrlMobile}'`);
    } else
      navigation.goBack();
  };
  return <View style={{ flex: 1 }}>
    <ModalTopBar onPress={navigationGoBack} title={title} />
    <WebView
      ref={webViewRef}
      style={{ flex: 1 }}
      originWhitelist={["*"]}
      source={{ uri: getFullLink() + url }}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
      onShouldStartLoadWithRequest={request => {
        console.log("request.url", request.url);
        if(request.url.includes("DoiVeCongTac_Form")) {
          setTitle("Đổi vé");
        }
        else {
          if(item!=null) {
            if (item.Step == 1) {
              setTitle("Chọn người phê duyệt");
            } else {
              setTitle("Đăng ký vé máy bay");
            }
          }
        }
        if(request.url.includes("bussinessdoc-byme")) {
          navigation.goBack();
        }
        setCurrentUrl(request.url);
        return true;
      }}
    />
  </View>;
};
