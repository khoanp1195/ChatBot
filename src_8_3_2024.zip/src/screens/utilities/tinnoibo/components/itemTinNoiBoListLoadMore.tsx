import { Text, View } from "react-native";
import { FC } from "react";
import { convertStringToMoment, getScreenWidth, isNullOrEmpty } from "../../../../utils/functions.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import { getFullLink } from "../../../../config/constants.ts";

interface Props {
  item: any,
  showLine: boolean
}

export const ItemTinNoiBoListLoadMore: FC<Props> = ({ item, showLine }) => {
  const imgUrl = !isNullOrEmpty(item.ImageThumb) ? JSON.parse(item.ImageThumb).Path : "";
  return <View>
    <View style={{ flexDirection: "row" }}>
      <CustomFastImage resizeMode={"stretch"} styleImg={{ height: 72, width: 115, borderRadius: 6 }}
                       defaultImage={require("../../../../assets/images/temp_tinnoibo.png")}
                       urlOnline={getFullLink() + imgUrl} />
      <View style={{marginLeft:10}}>
        <Text style={{ width: getScreenWidth() - 165, height: 60, color: "black", fontWeight: "bold", fontSize: 14 }}
              numberOfLines={3}>{item.Title}</Text>
        <Text style={{ color: "#999999", fontSize: 10 }}>
          {isNullOrEmpty(item.Modified) ? "" : convertStringToMoment(item.Modified).format("DD/MM/yyyy")}</Text>

      </View>
    </View>
    {
      showLine && <View style={{ height: 1, backgroundColor: "#E9E9E9", marginTop: 10 }} />
    }
  </View>;
};
