import { Text, TouchableOpacity } from "react-native";
import { useDispatch } from "react-redux";
import { logout } from "../stores/login/actions.ts";
import { useEffect } from "react";
import { getCount } from "../services/api/api_home_page.ts";
import { getVBChoXuLy } from "services/api/api_doc.ts";


export const TestScreen1 = () => {
  const dp = useDispatch();
  return (
    <TouchableOpacity
      onPress={() => {
        dp(logout());
      }}>
      <Text style={{ color: "blue", textDecorationLine: "underline" }}>
        Click me!
      </Text>
    </TouchableOpacity>
  );
};
