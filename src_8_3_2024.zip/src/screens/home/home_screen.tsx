import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { TestChart } from "./test_chart.tsx";
import { useEffect, useState } from "react";
import { getCount } from "../../services/api/api_home_page.ts";
import { CircleButton } from "../../components/circleButton.tsx";
import { DashBoardButton } from "../../components/dashBoardButton.tsx";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import BaseScreen from "../../components/basescreen.tsx";
import { TinNoiBoComponent } from "../../screens/utilities/tinnoibo/tinNoiBoComponent.tsx";
import { getDashboard } from "../../services/api/apiTinNoiBo.ts";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../config/enum.ts";
import {
  redirectHSLTCuaToi,
  redirectTBScreen,
  redirectTinNoiBo,
  redirectVBDenTitle,
  redirectVBDiTitle,
  redirectVBPHScreen,
  redirectVCXLHighScreen,
  redirectVCXLScreen
} from "../../stores/base_screen/actions.ts";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";

export const HomeScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [data, setData] = useState({ "ThongBao": 0, "VBCanXuLy": 0, "VBCanXuLyHigh": 0, "VBPhoiHop": 0 });
  const [dataTinNoiBo, setDataTinNoiBo] = useState();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  useEffect(() => {
    getCount().then(value => {
      setData(value);
    });
    getDashboard().then(value => {
      setDataTinNoiBo(value);
    });
  }, [onLoading]);

  const onClickVBDen = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }

  const onClickVBPH = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }

  return <View style={styles.root}>
    <BaseScreen>
      <View style={{
        backgroundColor: "white",
        height: "100%"
      }}>
        <PetroAppBarCustom
          title={"Trang chủ"}
          rightAction={
            <TouchableOpacity onPress={() => {
              // @ts-ignore
              navigation.navigate("QRScreen");

            }}>
              <Image style={{ height: 30, width: 30 }} source={require("../../assets/images/icon_qr.png")} />
            </TouchableOpacity>
          }
          onPress={() => {
            try {
              dispatch(showLeftMenuHome());
              // @ts-ignore 
              navigation.openDrawer();
              // navigation.dispatch(DrawerActions.openDrawer())
            } catch (e) {
              if (__DEV__)
                console.log("Lỗi gòi: " + e);
            }
          }} />
        <ScrollView style={styles.scrollView}>
          <View
            style={[
              styles.container,
              {
                flexDirection: "row",
                height: Dimensions.get("window").height * 15 / 100//200,
              }
            ]}>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbden_db.png")} title={"VB đến"} onClick={() => {
                dispatch(redirectVBDenTitle());
              }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbdi_db.png")} title={"VB đi/Nội bộ"}
                onClick={() => {
                  dispatch(redirectVBDiTitle());
                }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_hslt_db.png")} title={"Hồ sơ lưu trữ"}
                onClick={() => {
                  dispatch(redirectHSLTCuaToi());
                }} />
            </View>
          </View>
          {/*<TestChart countData={data} />*/}
          <TinNoiBoComponent
            sizeTitle={20}
            title={"Tin nội bộ"}
            data={dataTinNoiBo}
            typeView={TinNoiBoType.DashBoard}
            viewMode={ViewModeTinNoiBo.Horizontal}
            showDot={true}
            showAll={true}
            autoScroll={true}
            onPressAll={() => {
              dispatch(changePageTypeTinNoiBo(undefined));
              // @ts-ignore
              navigation.navigate("TienIch");

              dispatch(redirectTinNoiBo());
            }}
            showLine={false}
          />
          <Text style={{ color: "#004374", fontSize: 20, fontWeight: "bold", marginHorizontal: 20, marginTop: 5 }}>Xử lý
            văn bản</Text>
          <View style={{ height: 340 }}>
            <View style={[
              styles.container,
              {
                flexDirection: "column"
              }
            ]}>
              <View
                style={[
                  styles.innerContainer,
                  {
                    flexDirection: "row"
                  }
                ]}>
                <View style={[styles.viecXLContainer, { backgroundColor: "#DFF1FF" }]}>
                  <DashBoardButton title={"Thông báo (để biết)"}
                    path={require("../../assets/images/icon_db_tb.png")}
                    countNum={data !== undefined ? data.ThongBao : 0}
                    countNumColor={"#004EE1"}
                    handleClick={() => {
                      dispatch(redirectTBScreen());
                    }} />
                </View>
                <View style={[styles.viecXLContainer, { backgroundColor: "#D6FFE0" }]}>
                  <DashBoardButton
                    title={"VB phối hợp"}
                    path={require("../../assets/images/icon_db_vbph.png")}
                    countNum={data !== undefined ? data.VBPhoiHop : 0} countNumColor={"#00CF6C"}
                    handleClick={() => {
                      dispatch(redirectVBPHScreen());
                    }} />
                </View>
              </View>
              <View
                style={[
                  styles.innerContainer,
                  {
                    flexDirection: "row"
                  }
                ]}>
                <View style={[styles.viecXLContainer, { backgroundColor: "#FFF3C4" }]}>
                  <DashBoardButton
                    title={"VB cần xử lý"}
                    path={require("../../assets/images/icon_db_vcxl.png")}
                    countNum={data !== undefined ? (data?.VBCanXuLy ?? 0) - (data?.VBCanXuLyHigh ?? 0) : 0}
                    countNumColor={"#FFCF2C"}
                    handleClick={() => {
                      dispatch(redirectVCXLScreen());
                    }}
                  />
                </View>
                <View style={[styles.viecXLContainer, { flex: 1, backgroundColor: "#FFE2CE" }]}>
                  <DashBoardButton
                    title={"VB ưu tiên xử lý sớm"}
                    path={require("../../assets/images/icon_db_vcxl_hight.png")}
                    countNum={data !== undefined ? data.VBCanXuLyHigh : 0}
                    countNumColor={"#FA6400"}
                    handleClick={() => {
                      dispatch(redirectVCXLHighScreen());
                    }}
                  />
                </View>
              </View>
            </View>
          </View>
        </ScrollView >
      </View >
    </BaseScreen >
  </View >;
};

const styles = StyleSheet.create({
  root: {
    height: "100%"
  },
  scrollView: {
    backgroundColor: "white",
    height: "100%",
    paddingBottom: 20
  },
  container: {
    flex: 1,
    padding: 15
  },
  innerContainer: {
    flex: 1,
    padding: 0
  },
  topButtonContainer: {
    flex: 1
    // margin: 5,
  },
  viecXLContainer: {
    flex: 1,
    borderRadius: 12,
    margin: 5
  }
});
