import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../components/modalTopBar";
import { useEffect, useState } from "react";
import { FlatList, Image, Platform, Pressable, SafeAreaView, StyleSheet, Text, View } from "react-native";
import { appMainBlueColor } from "../../utils/color";
import { isNullOrEmpty } from "../../utils/functions.ts";
import { getUserInfoQRCode } from "../../services/api/api_qrScreen.ts";
import { CustomFastImage } from "../../components/custom_fast_image.tsx";
import { CircleButton } from "../../components/circleButton.tsx";
import Share from 'react-native-share';
import ReactNativeBlobUtil from 'react-native-blob-util';
import { showAlert } from "../../screens/commonAlertView.jsx";
import { CameraRoll } from "@react-native-camera-roll/camera-roll";

export const QRScreen = () => {
  const navigation = useNavigation();

  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    // @ts-ignore
    getUserInfoQRCode().then(value => {
      if (value !== null)
        setUser(value)
      else
        showAlert("Bạn không đủ thông tin để tạo mã QR, vui lòng liên hệ quản trị viên.", true)
    }).catch(e => {
      if (__DEV__)
        console.log('Lỗi lấy thông tin danh bạ nè: ', e)
      showAlert("Bạn không đủ thông tin để tạo mã QR, vui lòng liên hệ quản trị viên.", true)
    })
  }, []);

  const closeScreen = () => {
    // @ts-ignore
    if (navigation.canGoBack())
      navigation.goBack();
  }

  const onClickDownload = async () => {
    let imgUrl = user.UrlImageQRCodeDanhBa
    // if (Platform.OS == 'android') {

    // } else {
    //   CameraRoll.saveToCameraRoll(imgUrl);
    //   console.log("down gòi")
    // }

    if (user !== null) {
      await ReactNativeBlobUtil.fetch(
        'GET',
        imgUrl,
      )
        .then(res => {
          let status = res.info().status;
          if (status === 200) {
            let base64Str = res.base64();
            let options = {
              url: `data:image/jpeg;base64,${base64Str}`,
              saveToFiles: true,
            };
            Share.open(options)
              .then(r => {
                if (__DEV__)
                  console.log(r);
              })
              .catch(e => {
                e && __DEV__ && console.log(e);
              });
          } else {
            // handle other status codes
          }
        })
        // Something went wrong:
        .catch(err => {
          if (__DEV__)
            // error handling
            console.log(err);
        });
    }
    else {
      if (__DEV__)
        console.log("user null gòi")
    }
  }

  const onClickShared = () => {
    if (user !== null) {
      ReactNativeBlobUtil.fetch(
        'GET',
        user.UrlImageQRCodeDanhBa,
      )
        .then(res => {
          let status = res.info().status;
          if (status === 200) {
            let base64Str = res.base64();
            let options = {
              url: `data:image/jpeg;base64,${base64Str}`,
            };
            Share.open(options)
              .then(r => {
                if (__DEV__)
                  console.log(r);
              })
              .catch(e => {
                e && __DEV__ && console.log(e);
              });
          } else {
            // handle other status codes
          }
        })
        // Something went wrong:
        .catch(err => {
          if (__DEV__)
            // error handling
            console.log(err);
        });
    }
    else {
      if (__DEV__)
        console.log("user null gòi")
    }
  }

  return (
    <SafeAreaView
      style={{ flex: 1, backgroundColor: '#8D8D8D' }}
    >
      <ModalTopBar
        title={""}
        onPress={() => {
          closeScreen()
        }} />
      <View style={{
        flex: 9,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 10,
      }}>
        <View style={styles.topButtonContainer}>
          <Text style={{ fontWeight: 'bold', color: appMainBlueColor, fontSize: 15 }}> {user !== null ? user.Department : "DepartMent"} </Text>
          {
            user !== null && !isNullOrEmpty(user.UrlAvatar) ?
              <CustomFastImage
                urlOnline={user.UrlAvatar}
                defaultImage={require("../../assets/images/avatar80.jpg")}
                styleImg={styles.imgStyle}
                resizeMode={'stretch'} />
              :
              <Image
                style={styles.imgStyle}
                source={require('../../assets/images/avatar80.jpg')}
                resizeMode="stretch"
              />
          }
          <Text style={{ fontWeight: 'bold', fontSize: 15 }}> {user !== null ? user.FullName : "FullName"}</Text>
          <Text style={{ fontSize: 12 }}> {user !== null ? user.Position : "Position"}</Text>
        </View>
        <View style={styles.qrCodeViewStyle}>
          {
            user !== null && !isNullOrEmpty(user.UrlImageQRCodeDanhBa) ?
              <CustomFastImage
                urlOnline={user.UrlImageQRCodeDanhBa}
                defaultImage={require("../../assets/images/avatar80.jpg")}
                styleImg={styles.qrImageStyle}
                resizeMode={'stretch'} />
              :
              <Image
                style={styles.qrImageStyle}
                source={require('../../assets/images/avatar80.jpg')}
                resizeMode="stretch"
              />
          }
        </View>
      </View>

      <View style={{
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingTop: 10,
      }}>
        <View style={styles.botButtonStyle}>
          <CircleButton path={require("../../assets/images/icon_download_qr.png")} title={'Tải xuống'} onClick={() => { onClickDownload() }} />
        </View>
        <View style={styles.botButtonStyle}>
          <CircleButton path={require("../../assets/images/icon_share_qr.png")} title={'Chia sẻ'} onClick={() => { onClickShared() }} />
        </View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  rootContainer: {
    height: "100%",
    backgroundColor: "white",
  },
  topButtonContainer: {
    flex: 1,
    backgroundColor: 'white',
    width: '90%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    margin: 10,
    borderRadius: 6,
  },
  imgStyle: {
    flex: 1,
    width: '80%',
    aspectRatio: 1,
    borderRadius: 999,
    margin: 20,
    borderWidth: 1,
    borderColor: 'darkgrey'
  },
  qrCodeViewStyle: {
    flex: 1,
    backgroundColor: 'white',
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  qrImageStyle: {
    flex: 1,
    height: '80%',
    aspectRatio: 1,
    margin: 10,
  },
  botButtonContainer: {
    flex: 1,
  },
  botButtonStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    margin: 5,
  }
});
