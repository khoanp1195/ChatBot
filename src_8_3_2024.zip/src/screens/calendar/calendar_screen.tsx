import { FlatList, Image, Text, TouchableOpacity, View, StyleSheet, Alert, Pressable, LogBox } from "react-native";
import ReactNativeCalendarStrip from "react-native-calendar-strip";
import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
import { showLeftMenuCalendar, showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import React, { memo, useCallback, useEffect, useMemo, useState } from "react";
import BaseScreen from "../../components/basescreen.tsx";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import { formatDate, formatDateNum, getDisplayTxtFromDateString, getDisplayTxtFromHourString, getStartOfWeek, getWeekOfYear } from "../../utils/functions.ts";
import moment, { isDate } from "moment";
import { appMainBlueColor } from "../../utils/color.ts";
import { getListDonVi, getMeetingCalendars } from "../../services/api/api_calendar.ts";
import Empty_view from "../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";

export const CalendarScreen = () => {
  moment.locale("en");
  const dispatch = useDispatch();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
  const [donvi, setDonVi] = useState();
  const [lichhHop, setlichhHop] = useState([])
  const [lichtuan, setLichTuan] = useState([])
  const [firstDayofWeek, setfirstDayofWeek] = useState(new Date());
  const [lastDayOfWeek, setlastDayOfWeek] = useState(new Date())
  const [uniTitle, setUnitTitle] = useState("")
  const [siteConnection, setSiteConnection] = useState("")
  const [keyConnection, setKeyConnection] = useState("")
  const itemUnitSelected = useSelector((state: any) => state.lichtuan);
  const [isFirst, setIsFirst] = useState(true)
  const [flag, setFlag] = useState(1)
  const [isShowMonthCalendar, setIsShowMonthCalendar] = useState(false);
  const [dictLichhop, setdictLichhop] = useState({})
  const [isWeekView, setisWeekView] = useState(false)
  const [weeknum, setweeknum] = useState("")
  const [week, setweek] = useState(Number)
  const [dotCalendar, setdotCalendar] = useState([])
  const [isBlurBackground, setisBlurBackground] = useState(false)
  const [isNextDate, setisNextDate] = useState(false)
  const [isPreDate, setisPreDate] = useState(false)

  const datesBlacklistFunc = (date: { isoWeekday: () => number; }) => {
    return date.isoWeekday() === 6 || date.isoWeekday() === 7; // disable Saturdays
  };
  const tabs = [
    { title: "Lịch lãnh đạo" },
    { title: "Lịch ban" },
    { title: "Lịch của tôi" }
  ];

  const [indexTab, setIndexTab] = useState(0);
  const [isFullWeek, setIsFullWeek] = useState(false);

  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const getColorByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case "Lịch dự kiến":
          return '#A7FFA5'
        case "Điều chỉnh":
          return '#ACB0EE';
        case "Hủy lịch":
          return '#FF8685';
        case "Hoãn":
          return '#FFD770';
        default:
          return '#E7F8FF';
      }
    }
    const getColorBorderByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case "Lịch dự kiến":
          return '#A7FFA5'
        case "Điều chỉnh":
          return '#ACB0EE';
        case "Hủy lịch":
          return '#FF8685';
        case "Hoãn":
          return '#FFD770';
        default:
          return '#8ECFFF';
      }
    }

    const getStatusItem = (StatusItem: any) => {
      switch (StatusItem) {
        case 1:
          return "Bổ sung"
        case 2:
          return "Điều chỉnh";
        case 3:
          return "Hoãn";
        case 4:
          return "Dự kiến";
        default:
          return '';
      }
    }

    return <Pressable onPress={() => {
      // @ts-ignore
      navigation.navigate("DetailCalendarScreen", {
        item: item
      });
    }}
      style={{
        borderWidth: 1.5,
        borderRadius: 10,
        flexDirection: "row",
        alignItems: "center",
        alignContent: "center",
        justifyContent: "center",
        marginTop: 10,
        borderColor: getColorBorderByAppStatus(item.Status)
      }}>
      <View style={{
        padding: 10,
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
        flexDirection: "column",
        flex: 3,
        height: "100%",
        backgroundColor: getColorByAppStatus(item.Status),
        alignItems: "center"
      }}>

        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.StartTime)}</Text>
          <Text> - </Text>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.EndTime)}</Text>
        </View>

        <View style={{
          // borderWidth: 1,
          // borderRadius: 3,
          width: "100%",
          alignItems: "center"
        }}>
          <Text>{getStatusItem(item.StatusItem)}</Text>
        </View>
        <Text numberOfLines={2} style={{ marginTop: '15%' }}>{item.LocationTitle}</Text>
        {
          item.MeetingLink != undefined && item.MeetingLink != "" ? (<View style={{ flexDirection: "row", marginTop: '45%' }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
              source={require("../../assets/images/icon_meeting_call.png")} />
            <Text style={{ marginLeft: '5%' }}>Vào link họp</Text>
          </View>) : null
        }
      </View>
      <View style={{
        flexDirection: "column",
        flex: 7,
        height: "100%",
        padding: 10,
        backgroundColor: "white",
        borderTopRightRadius: 9,
        borderBottomRightRadius: 9
      }}>
        <Text numberOfLines={2}>{item?.Title}</Text>
        <View style={{
          width: "100%",
          height: 1,
          borderWidth: 0.5,
          marginTop: '3%',
          borderColor: "#474747",
          borderStyle: "dashed"

        }} />
        <View style={{ flexDirection: "column", marginTop: 20 }}>
          <View style={{ flexDirection: "row", marginBottom: 10 }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_user_calendar.png")} />
            <Text>{item.HostTitle}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_group_calendar.png")} />
            <TouchableOpacity onPress={() => {
                    OnClickParticipant(item.PreparerDetail?.split(';$').join(','))
            }} style={{ width: '80%', marginLeft: '2%' }}>
              <Text>{item.PreparerDetail?.split(';$').join(',')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Pressable>;
  };
  console.log("selectedDate = >: ", selectedDate);


  useEffect(() => {
    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
    if (isFirst) {
      getListDonVi().then(data => {
        if (data != null) {
          setDonVi(data)
          setIsFirst(false)
          setUnitTitle(data[0].Title)
          calculateWeekBounds();
          loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 2, keyConnection).then(dataFirstLich => {
            if (dataFirstLich != null) {
              setlichhHop(dataFirstLich)
            }
          })
        }
      })
    }
    else {
      setUnitTitle(uniTitle)
      loadListCalendarByWeek(selectedDate, selectedDate, flag, keyConnection).then(dataLichHop => {
        if (dataLichHop != null) {
          setlichhHop(dataLichHop)
        }
      })
    }
  }, [uniTitle])


  const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag: number, keyConnection: any) => {
    const data = await getMeetingCalendars(fromDate, toDate, flag, keyConnection);
    if (data != null) {
      return data;
    } else {
      return [];
    }
  };

  const OnClickUnit = (item: any) => {
    // @ts-ignore
    navigation.navigate("Calendar_unit", {
      item: donvi, title: uniTitle, flag: getFlag(indexTab),
      onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
        setUnitTitle(title)
        setSiteConnection(SiteConnection)
        setKeyConnection(KeyConnection)
        setFlag(flag)
        console.log("KeyConnection - here " + KeyConnection)

      }
    })
  };

  const OnClickParticipant = (item: any) => {
    // @ts-ignore
    navigation.navigate("Participant_Screen", {
      item: donvi, title: uniTitle, flag: getFlag(indexTab),
      onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
        setUnitTitle(title)
        setSiteConnection(SiteConnection)
        setKeyConnection(KeyConnection)
        setFlag(flag)
        console.log("KeyConnection - here " + KeyConnection)

      }
    })
  };

  const onDateChanged = (date: any) => {
    setSelectedDate(date)
    // date = getStartOfWeek();
    // const lastDay = new Date(date);
    // lastDay.setDate(date.getDate() + 6);
    loadListCalendarByWeek(date, date, 2, keyConnection).then(data => {
      if (data != null) {
        setlichhHop(data)
      }
    })
  };

  const changeTab = (index: any) => {
    setFlag(getFlag(index))
    loadListCalendarByWeek(selectedDate, selectedDate, getFlag(index), keyConnection).then(data => {
      if (data != null) {
        setlichhHop(data)
      }
    })
  }

  function startOfWeek(dt, startOfWeek = 1 /* Monday */) {
    const diff = (7 + (dt.getDay() - startOfWeek)) % 7;
    const newDate = new Date(dt);
    newDate.setDate(dt.getDate() - diff);
    newDate.setHours(0, 0, 0, 0); // Set time to midnight
    return newDate;
  }
  function formatDateToVietnamese(date) {
    const daysOfWeek = ['Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];
    const months = ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'];
    const dayOfWeek = daysOfWeek[date.getDay()];
    const dayOfMonth = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();

    return `${dayOfWeek}, ${dayOfMonth} ${month} ${year}`;
  }

  useEffect(() => {
    const dateObject = new Date(selectedDate)
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate())
    lastDay.setDate(firstDay.getDate() + 6);
    if (isWeekView) {
      let flagWeek = getFlag(indexTab)
      loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), flagWeek, keyConnection)
        .then(dataFirstLich => {
          if (dataFirstLich != null) {
            setLichTuan(dataFirstLich);
            setweek(getWeekOfYear(selectedDate));
            setweeknum(`(${formatDateNum(firstDay)} - ${formatDateNum(lastDay)})`);
            console.log("From Date - To Date - v3: ", formatDate(firstDay), "/", formatDate(lastDay));
            console.log("dictLichhop - here: ", Object.keys(dictLichhop));
            console.log("dataFirstLich - here - count: ", dataFirstLich.length);
            const tempDict = {};
            dataFirstLich.forEach(item => {
              if (item.StartTime) {
                const key = formatDateToVietnamese(new Date(item.StartTime));
               // const key = moment(item.StartTime).format("YYYY-MM-DD")
                tempDict[key] = tempDict[key] ? [...tempDict[key], item] : [item];
              }
            });
            setdictLichhop(tempDict);
          }

        });
    }
    else {
      loadMyCalendar()
    }
  }, [isWeekView, isPreDate, flag]);


  // set dot for week
  // const loadMyCalendar = () => {
  //   const dateObject = new Date(selectedDate)
  //   const firstDay = startOfWeek(dateObject);
  //   const lastDay = new Date(firstDay);
  //   firstDay.setDate(firstDay.getDate())
  //   lastDay.setDate(firstDay.getDate() + 6);
  //   loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, keyConnection)
  //     .then(dataMyCalendar => {
  //       if (dataMyCalendar != null) {
  //         const tempDict = {};
  //         dataMyCalendar.forEach(item => {
  //           if (item.StartTime) {
  //             const key = moment(item.StartTime).format("YYYY-MM-DD")
  //             tempDict[key] = tempDict[key] ? [...tempDict[key], item] : [item];
  //           }
  //         });
  //         const propertiesToAssign = {
  //           textColor: 'green',
  //           color: 'green',
  //           dotColor: 'red',
  //           marked: true
  //         };
  //         let markedDates = {} as { [date: string]: any };
  //         Object.keys(tempDict).forEach(date => {
  //           markedDates[date] = { ...propertiesToAssign };
  //         })
  //         setdotCalendar(markedDates)
  //       }

  //     });
  // }
  const loadMyCalendar = () => {
    const dateObject = new Date(selectedDate);
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate() - 10)
    lastDay.setDate(firstDay.getDate() + 10);

    loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, keyConnection)
      .then(dataMyCalendar => {
        if (dataMyCalendar) {
          const tempDict = dataMyCalendar.reduce((acc, item) => {
            if (item.StartTime) {
              const key = moment(item.StartTime).format("YYYY-MM-DD");
              acc[key] = acc[key] ? [...acc[key], item] : [item];
            }
            return acc;
          }, {});

          const propertiesToAssign = {
            textColor: 'green',
            color: 'green',
            dotColor: 'red',
            marked: true
          };

          const markedDates = Object.keys(tempDict).reduce((acc, date) => {
            acc[date] = { ...propertiesToAssign };
            return acc;
          }, {});

          setdotCalendar(markedDates);
        } else {
          console.error('No calendar data available');
        }
      })
      .catch(error => {
        console.error('Error loading calendar:', error);
      });
  };

  const calculateWeekBounds = () => {
    const firstDay = getStartOfWeek();
    const lastDay = new Date(firstDay);
    lastDay.setDate(firstDay.getDate() + 6);
    setfirstDayofWeek(firstDay);
    setlastDayOfWeek(lastDay);
  };

  const getFlag = (index: number) => {
    switch (index) {
      case 0:
        return 2
      case 1:
        return 1;
      case 2:
        return 3;
    }
  }

  const loadWeekCalendar = useCallback(() => {
    setIsFullWeek(!isFullWeek);
    setisWeekView(!isWeekView)
  }, [isWeekView, isFullWeek])


  LocaleConfig.locales["vn"] = {
    monthNames: [
      "Tháng 1",
      "Tháng 2",
      "Tháng 3",
      "Tháng 4",
      "Tháng 5",
      "Tháng 6",
      "Tháng 7",
      "Tháng 8",
      "Tháng 9",
      "Tháng 10",
      "Tháng 11",
      "Tháng 12"
    ],
    monthNamesShort: [
      "Th 1",
      "Th 2",
      "Th 3",
      "Th 4",
      "Th 5",
      "Th 6",
      "Th 7",
      "Th 8",
      "Th 9",
      "Th 10",
      "Th 11",
      "Th 12"
    ],
    dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
  };
  LocaleConfig.defaultLocale = "vn";

  return (
    <BaseScreen>
     {
     <View style={{ height: "100%", backgroundColor: "white" }}>

     <PetroAppBarCustom
       title={"Lịch tuần"}
       rightAction={
         <View style={{ flexDirection: 'row' }}>
           <TouchableOpacity onPress={() => {
             setIsShowMonthCalendar(!isShowMonthCalendar)
           }}>
             <Text style={{ marginRight: 15, marginTop: '7%', color: '#0072C6', fontWeight: '600' }}>{getDisplayTxtFromDateString(selectedDate)}</Text>
           </TouchableOpacity>

           <TouchableOpacity onPress={() => {
             loadWeekCalendar()
           }}>
             <Image style={{ height: 25, width: 25 }} source={
               !isFullWeek ?
                 require("../../assets/images/icon_change_type_date.png") :
                 require("../../assets/images/icon_change_type_week.png")
             } />
           </TouchableOpacity>
         </View>
       }
       onPress={() => {
         dispatch(showLeftMenuCalendar());
         // @ts-ignore
         navigation.openDrawer();
       }} />
     <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />


     {/* <ReactNativeCalendarStrip
       locale={{
         name: "vi",
         config: {
           months: [
             "Tháng 1",
             "Tháng 2",
             "Tháng 3",
             "Tháng 4",
             "Tháng 5",
             "Tháng 6",
             "Tháng 7",
             "Tháng 8",
             "Tháng 9",
             "Tháng 10",
             "Tháng 11",
             "Tháng 12"
           ],
           weekdaysShort: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
           weekdays: ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"]
         }
       }}
       datesBlacklist={datesBlacklistFunc}
       highlightDateNameStyle={{ color: "#0072C6" }}
       highlightDateNumberStyle={{ color: "#0072C6" }}
       scrollable
       // @ts-ignore
       selectedDate={Date.now()}
       style={{
         width: "100%",
         height: 60
       }} /> */}

     <View style={{ height: 80, backgroundColor: "cyan" }}>
       {
         isWeekView ? (
           <View>
             <View style={{ width: '100%', height: 80, backgroundColor: '#FAFAFA', flexDirection: 'row' }}>
               <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
                 onPress={() => {
                   setisPreDate(
                     !isPreDate)
                 }}
               >
                 <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                   source={require("../../assets/images/icon_preWeek.png")} />
               </TouchableOpacity>
               <View style={{ width: '70%', justifyContent: 'center', flexDirection: 'row' }}>
                 <Text style={{ marginRight: '2%', alignSelf: 'center', fontSize: 16, fontWeight: '600' }}>Tuần {week}</Text>
                 <Text numberOfLines={1} style={{ alignSelf: 'center', fontSize: 16 }}>
                   {weeknum}
                 </Text>
               </View>
               <Pressable style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}>
                 <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                   source={require("../../assets/images/icon_nextWeek.png")} />
               </Pressable>
             </View>
           </View>
         ) :
           (
             null
           )
       }
       <CalendarProvider
         date={selectedDate} // date={"2024-01-01"}
         //@ts-ignore
         onDateChanged={(date) => { onDateChanged(date) }}
         disabledOpacity={1}
         showTodayButton={true}
         markedDates={dotCalendar}
       >
         <WeekCalendar testID={'weekCalendar'}
           firstDay={1}
           theme={{
             backgroundColor: '#ffffff',
             calendarBackground: 'white',//#ffffff
             textSectionTitleColor: 'black',
             selectedDayBackgroundColor: appMainBlueColor,//'#00adf5'
             selectedDayTextColor: '#ffffff',
             todayTextColor: appMainBlueColor,// '#00adf5'
             dayTextColor: 'black',
           }}
           disableOnPageChange={true}
           markedDates={dotCalendar}
         />

       </CalendarProvider>

     </View>

     <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />

     <TouchableOpacity
       style={{ paddingVertical: 10, paddingHorizontal: 15, flexDirection: "row", backgroundColor: "white" }}
       onPress={(item) => {
         OnClickUnit(item);
       }}>
       <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
         source={require("../../assets/images/icon_focus_contact.png")} />
       <Text style={{ color: "black", fontWeight: "bold", fontSize: 16, backgroundColor: "white" }}>{uniTitle}</Text>
     </TouchableOpacity>
     <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA" }} />
     <Tab
       value={indexTab}
       onChange={(index) => {
         setIndexTab(index);
         // setFlag(index)
         console.log("Index here " + index)
         changeTab(index)
       }}
       indicatorStyle={{ backgroundColor: "#0072C6", height: 3, borderRadius: 100, marginHorizontal: 4 }}
     >
       {tabs.map((tab, index) => (
         <Tab.Item key={index} title={tab.title} containerStyle={{ backgroundColor: "white" }} titleStyle={{
           fontSize: 12,
           color: "#000000",
           height: 30,
           width: '100%'
         }} />
       ))}
     </Tab>
     <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA", marginTop: 5 }} />

     <View style={{
       height: "55%",
       marginTop: '-50%',
       zIndex: 99,
       width: '95%',
       alignSelf: 'center',
       backgroundColor: 'transparent',
       borderRadius: 15,
       display: !isShowMonthCalendar ? 'none' : 'flex'
     }}>
       <Calendar
         date={selectedDate}
         onDayPress={day => {
           setSelectedDate(day.dateString);
           setIsShowMonthCalendar(false)
           onDateChanged(day.dateString)
         }}
         markedDates={dotCalendar}
         theme={{
           backgroundColor: '#F3F9FF',
           calendarBackground: '#F3F9FF',
           textSectionTitleColor: '#b6c1cd',
           selectedDayBackgroundColor: '#00adf5',
           selectedDayTextColor: '#ffffff',
           todayTextColor: '#0A78C8',
           dayTextColor: '#2d4150',
           textDayHeaderFontWeight: '600',
         }}
         style={{
           borderColor: 'gray',
           height: '100%',
           borderRadius: 15,
           marginTop: '6%',
           shadowColor: '#000',
           shadowOffset: { width: 0, height: 2 },
           shadowOpacity: 0.5, // Set the shadow opacity here
           shadowRadius: 4,
         }}
       />
     </View>
  

     <ScrollView style={{ alignContent: 'center' }} >
       {
         isWeekView ? (
           <FlatList
             style={{ padding: 10 }}
             data={Object.keys(dictLichhop)}
             renderItem={({ item }) => (
               <View>
                 <View style={styles.headerWeekCalendar}>
                   <Image style={{ height: 20, width: 20, marginRight: 10 }}
                     source={require("../../assets/images/icon_week_header.png")} />

                   <Text style={{ alignSelf: 'center', fontWeight: '600', color: '#0072C6' }}>{item}</Text></View>
                 <FlatList
                   style={{ marginTop: '2%' }}
                   data={dictLichhop[item]}
                   renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
                   keyExtractor={(item, index) => index.toString()}
                 />
               </View>
             )}
             keyExtractor={(item, index) => index.toString()}
           />
         ) : null
       }
       {lichhHop != undefined && lichhHop.length > 0 && !isWeekView ? (
         <FlatList
           data={lichhHop}
           renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
           keyExtractor={item => item.id}
           scrollEnabled={false}
           style={{ padding: 10 }}
         />
       ) : !isWeekView ? (
         <View style={styles.viewNoData}>
           <Text style={styles.textNoData}>Không có dữ liệu</Text>
         </View>) : null}
     </ScrollView>
   </View>
     }


    </BaseScreen>
  );
};
const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    marginTop: '50%',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#5E5E5E',
    fontStyle: 'italic'
  },
  headerWeekCalendar: {
    backgroundColor: '#E7F5FF',
    height: 40,
    width: '58%',
    justifyContent: "center",
    flexDirection: 'row',
    borderRadius: 14,
    alignItems: 'center',
    marginTop: '5%'
  },
  absolute: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});
