import { View, Text, StyleSheet } from 'react-native'
import React from 'react'

export const DetailVBDI = ({ vBDi }) => {
    return (
        <View style={styles.basicStyle}>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Loại văn bản</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {vBDi?.CodeDocumentTypeTitle}
            </Text>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Đơn vị soạn thảo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {vBDi?.DepartmentTitle}
            </Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Hồ sơ kèm theo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {vBDi?.DocumentName}
            </Text>
            {/* <Text style={[styles.titleTextStyle, styles.basicStyle]}>Đơn vị soạn thảo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{vBDen.CoQuanGuiText}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Hồ sơ kèm theo</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{vBDen.SoDen}</Text>
                </View>
            </View> */}
        </View>
    )
}
const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
})
