import moment from "moment";
import { View, FlatList, StyleSheet, Text, Pressable } from "react-native"
import { Image } from "react-native-elements";
import { appMainBlueColor } from "../../../utils/color.ts";
import { getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts"
import React, { useEffect, useState } from "react";
import { customStyles } from "../../../utils/customStyles.ts";
import { getDisplayTxtFromDateString } from "../../../utils/functions.ts"
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";
import { SwipeableRight } from "../../../components/swipeableRight.tsx";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { DbServices } from "../../../services/database/db_service.ts";
import { getFullLink } from "../../../config/constants.ts";
import { BeanUser } from "../../../services/database/models/bean_user.ts";

//@ts-ignore
export const ListDepartmentTask = ({ doHideHeader = false, data, OnPress, isEdited = false, onDelete = (item, index) => { } }) => {
    moment.locale('en');

    // const [isUnit, setIsUnit] = useState(data.AssignedToType == 1)

    //@ts-ignore
    const Item = ({ item, index }) => {
        let isUnit = item.AssignedToType == 1;
        const getPositionStr = (str: string) => {
            if (str!=undefined &&str.includes(";#")) {
                return str.split(";#")[1];
            }
            else
                return isNullOrEmpty(str)?"":str;
        }
        return (
            <Pressable
                style={[
                    customStyles.tableContentItemContainer,
                    {
                        backgroundColor: getListItemBackground(index % 2 != 0),
                    },
                ]}
                onPress={() => { OnPress(item) }}
            >

                {!isUnit && <CustomFastImage
                    styleImg={styles.imgStyle}
                    defaultImage={require('../../../assets/images/avatar80.jpg')}
                    urlOnline={getFullLink() + (item != undefined ? item.ImagePath : "")}
                    resizeMode="contain"
                />
                }
                <View
                    style={{
                        flex: 4,
                        flexDirection: 'column',
                    }}
                >
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Text style={[{ flex: 4, fontSize: 15, }]} > {item.DepartmentTitle}</Text>
                        {!isNullOrEmpty(item.DueDate) && <Text
                            style={{
                                flex: 1,
                                textAlign: 'right',
                                //@ts-ignore
                                color: !isNullOrEmpty(item.DueDate) && moment(item.DueDate) <= new Date() ? 'red' : 'darkgrey',
                                fontSize: 12,
                            }}
                        >
                            {isNullOrEmpty(item.DueDate) ? '' : getDisplayTxtFromDateString(item.DueDate)}
                        </Text>
                        }
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row-reverse' }}>
                        <TaskState state={item.TrangThai} />

                        {
                            <View style={{
                                flex: 1,
                                height: 30,
                                alignItems: 'center',
                                flexDirection: 'row',
                            }}>
                                <Text style={[{
                                    flex: 1,
                                    width: '100%',
                                    fontSize: 12,
                                    color: item.DeThucHien ? appMainBlueColor : 'darkgrey',
                                }]}>
                                    {item != undefined && !isUnit ? getPositionStr(item.Position) : ""}{!isUnit ? ' - ' : ''} {item.DeThucHien ? 'Thực hiện' : 'Phối hợp'}
                                </Text>
                            </View>
                        }

                        {isUnit
                            && !isNullOrEmpty(item.Position)
                            && <Text style={[{ flex: 1, fontSize: 13, }]}>
                                {getPositionStr(item.Position)}
                            </Text>
                        }

                    </View>
                </View>
            </Pressable>
        )
    };

    return <View>
        {!doHideHeader && <Text style={customStyles.tableContentHeader}>
            Tổ chức phân công thực hiện
        </Text>
        }
        <FlatList
            data={data}
            renderItem={({ item, index }) => isEdited ?
                <SwipeableRight rightActions={
                    <Pressable onPress={() => {
                        showAlert("Bạn chắc chắn muốn xóa", false, () => {
                            onDelete(item, index)
                        }, "Không", "Có");
                    }} style={{ backgroundColor: "red", flex: 1, justifyContent: "center", paddingHorizontal: 15 }}>
                        <Image
                            resizeMode={"contain"}
                            style={{ height: 20, width: 20 }}
                            source={require("../../../assets/images/icon_swipe_delete.png")} />
                    </Pressable>
                }>
                    <Item item={item} index={index} />
                </SwipeableRight>
                : <Item item={item} index={index} />}
            keyExtractor={item => item.ID}
            scrollEnabled={false}
        />
    </View>
}

//@ts-ignore
export const TaskState = ({ state }) => {
    return (
        <View style={{
            backgroundColor: getStateBackgroundColor(state),
            // flex: 1,
            width: 140,
            height: 30,
            flexDirection: 'row',
            // margin: 5,
            padding: 5,
            alignItems: "center",
            alignContent: "center",
            borderRadius: 5,
            flexShrink: 1,
        }}>
            <Image
                style={{
                    height: 15,
                    aspectRatio: 1,
                    alignItems: 'flex-start',
                    justifyContent: 'center',
                    marginLeft: 5,
                    tintColor: getStateTxtColor(state),
                }}
                source={getStateIcon(state)}
                resizeMode="stretch" />

            <View style={{
                flex: 1,
                flexDirection: 'row',
                paddingHorizontal: 5,
            }}>
                <Text style={{
                    flex: 1,
                    color: getStateTxtColor(state),
                    width: 1,
                    fontSize: 13,
                    textAlign: 'center',
                }}>
                    {state}
                </Text>
            </View>
        </View>)
}

//@ts-ignore
const getStateIcon = (state) => {
    switch (state) {
        default: return require('../../../assets/images/icon_ChuaBatDau.png')
        case "Đang thực hiện": return require('../../../assets/images/icon_ChuaBatDau.png')
        case "Hoàn tất": return require('../../../assets/images/icon_HoanTat.png')
        case "Tạm hoãn": return require('../../../assets/images/icon_TamHoan.png')
    }
}

//@ts-ignore
const getStateTxtColor = (state) => {
    switch (state) {
        default: return '#626262'
        case "Đang thực hiện": return appMainBlueColor
        case "Hoàn tất": return '#1CC564'
        case "Tạm hoãn": return '#FB4B45'
    }
}
//@ts-ignore
const getStateBackgroundColor = (state) => {
    switch (state) {
        default: return '#F0F0F0'
        case "Đang thực hiện": return '#D1E9FF'
        case "Hoàn tất": return '#DCFFDA'
        case "Tạm hoãn": return '#FFCBCB'
    }
}

const styles = StyleSheet.create({
    item: {
        flex: 1,
        flexDirection: 'row',
    },
    imgStyle: {
        height: 40,
        aspectRatio: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
        borderRadius: 20,
        marginRight: 10,
    }
})
