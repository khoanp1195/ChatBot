import moment from "moment";
import { View, FlatList, StyleSheet, Text } from "react-native"
import { Image } from "react-native-elements";
import { getDisplayTxtFromDateString } from "../../../utils/functions"
import { customStyles } from "../../../utils/customStyles.ts";
import { getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import cheerio from 'cheerio';
import { getFullLink } from "../../../config/constants.ts";
import { CustomFastImage } from "../../../components/custom_fast_image.tsx";
import {  getImagePathTagImageCheerio } from "../../../services/cheerio/cheerioServices.tsx";

export const ListIdea = ({ doHideHeader = false, data, isBODIdea = false }) => {
    moment.locale('en');
    const Item = ({ item, index }) => {
        return <View
            style={
                [customStyles.tableContentItemContainer,
                { backgroundColor: getListItemBackground(index % 2 != 0) }]
            }
        >
            <CustomFastImage
                styleImg={{
                    // flex: 1,
                    height: 40,
                    aspectRatio: 1,
                    alignItems: 'flex-start',
                    justifyContent: 'center',
                    borderRadius: 30,
                    marginRight: 5,
                }}
                defaultImage={require('../../../assets/images/avatar80.jpg')}
                urlOnline={getFullLink()+ getImagePathTagImageCheerio(item.ImagePath)}
                resizeMode="stretch" />
            <View
                style={{
                    flex: 4,
                    flexDirection: 'column',
                    marginHorizontal: 5,
                }}
            >
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Text style={[{ flex: 2, fontSize: 15, fontWeight: 'bold' }]}>{item.Title}</Text>
                    <Text style={{ flex: 1, color: 'grey', textAlign: 'right' }}>{getDisplayTxtFromDateString(item.Created, 'DD/MM/YY HH:mm')}</Text>
                </View>
                <Text style={{ flex: 1, fontSize: 13, color: 'grey', }}>{item.Position}</Text>
                <Text style={{ flex: 1, fontSize: 15, paddingTop: 5 }}>{item.Value}</Text>
            </View>
        </View >
    };

    return <View>
        {!doHideHeader && <Text style={customStyles.tableContentHeader}>
            {"Ý kiến" + (isBODIdea ? " lãnh đạo" : "")}
        </Text>}

        <FlatList
            data={data}
            renderItem={({ item, index }) => <Item item={item} index={index} />}
            keyExtractor={item => item.id}
            scrollEnabled={false}
        />
    </View>
}

const styles = StyleSheet.create({
})