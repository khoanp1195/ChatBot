import { FC } from "react"
import { FormOnlyComment } from "./formOnlyComment"
import { Text, View } from "react-native"
import { TouchableOpacity } from "react-native-gesture-handler"
import { BeanUser } from "../../../services/database/models/bean_user"
import { useNavigation } from "@react-navigation/native"
import { TypeSelectUser } from "../../../config/enum"
interface PropsAceptVBDi {
    onChangeText(text: string): void,
    selectedUser: BeanUser[],
    setSelectedUser(user: BeanUser[]): void,
    isRequire: boolean
}
export const PopUpActionAceptVBDi: FC<PropsAceptVBDi> = ({ onChangeText, selectedUser, setSelectedUser, isRequire }) => {
    return <View>
        <View>
            <FormOnlyComment onChangeText={onChangeText} isForce={false} isRequire={isRequire} />
        </View>
        <FormChonNguoiDeBiet selectedUser={selectedUser} setSelectedUser={setSelectedUser} />
    </View>
}
interface PropsFormChonNguoiDeBiet {
    selectedUser: BeanUser[],
    setSelectedUser(user: BeanUser[]): void
}
const FormChonNguoiDeBiet: FC<PropsFormChonNguoiDeBiet> = ({ selectedUser, setSelectedUser }) => {
    const navigation = useNavigation();
    const onClickCC = () => {
        //@ts-ignore
        navigation.navigate("SelectUserScreen",
            {
                typeSelect: TypeSelectUser.Multiple,
                usersSelected: selectedUser,
                onSelectApply: (users: any) => {
                    setSelectedUser(users);
                },
                beanTask: null,
                result: null
            });
    }
    return <View style={{ marginTop: 10 }}>
        <Text style={{ fontWeight: 'bold', color: 'black' }}>Chọn người để biết</Text>
        <Text style={{ fontSize: 13, marginVertical: 5 }}>CC</Text>
        <TouchableOpacity onPress={onClickCC}>
            <Text style={{ borderRadius: 10, borderColor: "#E5E5E5", borderWidth: 1, padding: 10 }}>{
                selectedUser != undefined && selectedUser.length > 0 ? selectedUser.map(r => r.Title).join(", ") : ""
            }</Text>
        </TouchableOpacity>
    </View>
}