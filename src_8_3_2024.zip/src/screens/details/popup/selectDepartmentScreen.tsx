import { FlatList, Image, Pressable, Text, View } from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import React, { useEffect, useState } from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
import { DbServices } from "../../../services/database/db_service.ts";
import { appMainBlueColor } from "../../../utils/color.ts";

export const SelectDepartmentScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  // @ts-ignore
  const beanTasks_Donvi = route.params["beanTasks_Donvi"];
  const [data, setData] = useState();
  // @ts-ignore
  const onSelectApply = route.params["onSelectApply"];
  // @ts-ignore
  const selectedTemp = route.params["selectedTemp"];
  const [selected, setSelected] = useState(selectedTemp);

  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    let condition = "";
    if (beanTasks_Donvi != null && beanTasks_Donvi.length > 0) {
      const mapStr = JSON.parse(beanTasks_Donvi).map((item: { DepartmentId: any; }) => item.DepartmentId).join(",");
      condition = `and ID not in(${mapStr}) `;
    }
    if (isNullOrEmpty(subsiteStore.getSubsite())) {
      let setting = await DbServices.getInstance().getBeanSettingRepository().findByKey("ItemTCTDepartmentId");
      // @ts-ignore
      let query = `select * from BeanDepartment where ParentID = ${setting[0]["VALUE"]} ` + condition + " order by [Order] ";
      const lstDepartment = await DbServices.getInstance().getBeanDepartmentRepository().excuseQuery(query);
      // @ts-ignore
      setData(lstDepartment);
    } else {
      let query = "SELECT ID FROM BeanDepartment WHERE IsRoot = 1 ";
      let root = await DbServices.getInstance().getBeanDepartmentRepository().excuseQuery(query);
      if (root != null) {
        query = `SELECT *
                 FROM BeanDepartment
                 WHERE Url is not null
                   and Url <> ''
                   and ParentID = ${root[0]["ID"]} ` + condition;
        const lstDepartment = await DbServices.getInstance().getBeanDepartmentRepository().excuseQuery(query);
        // @ts-ignore
        setData(lstDepartment);
      } else {
        query = `SELECT ID
                 FROM BeanDepartment
                 WHERE Url IS NOT NULL
                   AND Url = '${getFullLink()}' `;
        root = await DbServices.getInstance().getBeanDepartmentRepository().excuseQuery(query);
        if (root != null) {
          query = `SELECT *
                   FROM BeanDepartment
                   WHERE Url is not null
                     and Url <> ''
                     and ParentID = ${root[0]["ID"]} ` + condition;
          const lstDepartment = await DbServices.getInstance().getBeanDepartmentRepository().excuseQuery(query);
          // @ts-ignore
          setData(lstDepartment);
        }

      }
    }
  };

  // @ts-ignore
  const renderItem = ({ item, index }) => {
    const checkUnSelect = () => {
      if (selected != undefined) {
        // @ts-ignore
        return (selected.find((itemDatta: { Title: any; }) => itemDatta.Title == item.Title) == undefined);
      } else
        return true;
    };
    return <Pressable
      onPress={() => {
        if (selected != undefined) {
          // @ts-ignore
          if (selected.find((itemDatta: { Title: any; }) => itemDatta.Title == item.Title) == undefined) {
            // @ts-ignore
            setSelected((prevData) => [...prevData, item]);
          } else {
            // @ts-ignore
            const difItem = selected.filter(itemDatta => itemDatta.Title != item.Title);
            setSelected(difItem);
          }
        } else {
          // @ts-ignore
          setSelected([item]);
        }
      }}
      style={{ padding: 10, flexDirection: "row", backgroundColor: getListItemBackground(index % 2 != 0) }}>
      <Text style={{ flex: 9 }}>{item.Title}</Text>
      <View style={{ flex: 1 }}>
        <Image style={{ height: 20, width: 20, marginRight: 10 }}
               source={checkUnSelect() ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />

      </View>
    </Pressable>;
  };
  return <View style={{ flex: 1 }}>
    <ModalTopBar
      title={"Chuyển đến Tập đoàn, các đơn vị thành viên"}
      onPress={() => {
        navigation.goBack();
      }} />
    <View style={{
      backgroundColor: "#F9F9F9", flexDirection: "row",
      padding: 10
    }}>
      <View style={{ flex: 9 }} />
      <Text style={{ flex: 1 }}>Thực hiện</Text>
    </View>
    <View style={{ flex: 1, backgroundColor: "white" }}>
      <FlatList
        data={data}
        renderItem={renderItem}
      />
    </View>
    <View style={{ height: 50, flexDirection: "row", backgroundColor: "white" }}>
      <View style={{ flex: 1 }} />
      <View style={{ flex: 1, padding: 5 }}>
        <Pressable
          onPress={() => {
            navigation.goBack();
          }}
          style={{
            alignItems: "center",
            justifyContent: "center",
            padding: 10
          }}>
          <Text style={{ color: "#f65a5b" }}>Thoát</Text>
        </Pressable>
      </View>
      <View style={{ flex: 1, padding: 5 }}>
        <Pressable
          onPress={() => {
            onSelectApply(selected);
            navigation.goBack();
          }}
          style={{
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: appMainBlueColor,
            padding: 10,
            borderRadius: 5
          }}>
          <Text style={{ color: "white" }}>Chọn</Text>
        </Pressable>
      </View>
    </View>

  </View>;
};
