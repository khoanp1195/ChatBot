import { FC } from "react";
import { Text, TextInput, View } from "react-native";
import TextRequire from "../../../components/textRequire";
interface Props {
  onChangeText(text: string): void,
  isForce: boolean,
  isRequire: boolean
}
export const FormOnlyComment: FC<Props> = ({ onChangeText, isForce, isRequire }) => {
  return <View style={{ maxHeight: ' 80%' }}>
    <View style={{ marginBottom: 10, flexDirection: 'row' }}>
      <Text style={{ marginBottom: 10 }}>Ý kiến</Text>
      {
        isRequire && <TextRequire />
      }
    </View>
    <TextInput
      numberOfLines={4}
      onChangeText={text => onChangeText(text)}
      multiline
      style={{
        textAlignVertical: 'top',
        borderRadius: 10, borderWidth: 1, borderColor: "#E5E5E5", paddingVertical: 10, height: 100
      }}
      placeholder={"Vui lòng nhập ý kiến …"} />

    {
      isForce && <Text style={{ marginBottom: 10, color: 'red' }}>Anh/Chị xác nhận kết thúc luồng xử lý của văn bản này?</Text>
    }
  </View>;
};

