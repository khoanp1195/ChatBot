import { Button, Image, Text, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { useEffect, useState } from "react";
import {
  getAttFileVBBHByID,
  getDetailTaskVanBanBanHanh,
  getDetailVBBHByID,
  getVBBHWorkflowHistory, getViewerVBBH, getWorkflowHistoryOtherDepartmentVBBH
} from "../../../../services/api/apiDetailVBBH.ts";
import EmptyView from "../../../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { DetailVBDen } from "../../docDetail/detailVBDen.jsx";
import { ListAttachment } from "../../docDetail/listAttachment.jsx";
import { CustomImageButton } from "../../../../components/customImageButton.tsx";
import { appMainBlueColor } from "../../../../utils/color.ts";
import { ListIdea } from "../../../../screens/details/docDetail/listIdea.jsx";
import { ListDepartmentTask } from "../../../../screens/details/docDetail/listDepartmentTask.tsx";
import { ListUnitTask } from "../../../../screens/details/docDetail/listUnitTask.jsx";
import { getDisplayTxtFromDateString, isNullOrEmpty, mapActionVBDen, sortTask } from "../../../../utils/functions.ts";
import { BottomAction } from "../../../../components/bottomAction.tsx";
import { MoreAction } from "../../../../screens/details/popup/moreAction.tsx";
import { RootPopUpContainer } from "../../../../screens/details/popup/rootPopUpContainer.tsx";
import { downloadFile } from "../../../../services/api/api_client.ts";
import { useSelector } from "react-redux";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { DetailVBBH } from "../../../../screens/details/docDetail/detailVBBH.tsx";
import { openFile } from "../../../../utils/fileUtil.ts";
import { BeanVBBH } from "../../../../services/database/models/beanVBBH.ts";
import { ClassActionTasks } from "../../../../services/database/models/classActionTasks.ts";
import { EnumTaskRole } from "../../../../config/enum.ts";

// @ts-ignore
export const VBBHDetailScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  // @ts-ignore
  const item = route.params["item"];
  const [detailVanBanBH, setDetailVanBanBH] = useState<BeanVBBH | null>();
  const [lstAttachment, setListAttachment] = useState();
  const [lstBODIdea, setLstBODIdea] = useState([]);
  const [lstTCTH, setListTCTH] = useState<[]>();
  const [lstDVTH, setListDVTH] = useState([]);
  const [isViewDetail, setIsViewDetail] = useState(true);
  const [lstAction, setListAction] = useState<ClassActionTasks[] | null>();
  const [isShowMoreAction, setShowMoreAction] = useState(false);
  const [isShowPopup, setShowPopup] = useState(false);
  const [indexAction, setIndexAction] = useState(0);
  const [isLoading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    getAttFileVBBHByID(item.DocumentID ?? item.ID).then(attachments => {
      setListAttachment(attachments);
    });
    getDetailVBBHByID(item.DocumentID ?? item.ID).then((detail) => {
      setDetailVanBanBH(detail);
      if (detail != null) {
        setListTCTH(JSON.parse(detail.TaskJson) as []);
        setLstBODIdea(getListFromTxt(detail.CommentJson));
        if (detail.CodeItemId != null) {
          setListAction([
            new ClassActionTasks(1024, "Hồ sơ dự thảo", 999, "", true, 1024, "VBBH"),
            new ClassActionTasks(2048, "Chia sẻ", 999, "", true, 2048, "VBBH"),
          ]);
        }
        else {
          setListAction([
            new ClassActionTasks(2048, "Chia sẻ", 999, "", true, 2048, "VBBH"),
          ]);
        }
        setLoading(false);
      }
    });
  }, [onLoading]);


  const getListFromTxt = (txt: string) => {
    return !isNullOrEmpty(txt) ? JSON.parse(txt) : null;
  };

  //@ts-ignore
  const onClickAttachment = (item) => {
    if (__DEV__)
      console.log(item.Title);
    //@ts-ignore
    if (Platform.OS == "ios") {
      //@ts-ignore
      navigation.navigate('AttachmentDetailView', { item })
    }
    else {
      downloadFile(item.Path).then(filePath => {
        openFile(filePath);
      })
    }
  };

  //@ts-ignore
  const onClickDepartmentTask = (task) => {
    if (__DEV__) console.log("Task nè " + task.DepartmentTitle, "item nè:", JSON.stringify(task));
    //@ts-ignore
    navigation.navigate("RooTaskScreen",
      {
        checkType: () => getDetailTaskVanBanBanHanh(task.ID),
        itemVB: detailVanBanBH,
        isVBDen: false,
        lstBODIdea: lstBODIdea,
        lstAttachment: lstAttachment
      });
  };
  const handlePressShowAction = (index: number) => {
    console.log(index);
    switch (index) {
      case 0:
        setShowMoreAction(true);
        break;
      case 1024:
        console.log(" hồ sơ tài liệu nè");
        break;
      case 2048:
        //@ts-ignore
        navigation.navigate("ShareScreen",
          {
            item: detailVanBanBH,
            type: "VBBH"
          });
        break;
    }
  };

  return <View style={{ flex: 1 }}>
    <View style={{ flex: 1 }}>

      <ModalTopBar
        title={""}
        rightAction={
          detailVanBanBH != undefined ? <TouchableOpacity onPress={() => {
            // @ts-ignore
            navigation.navigate("RootWorkflowHistory", {
              // @ts-ignore
              getWorkflowHistory: () => getVBBHWorkflowHistory(detailVanBanBH.ID),
              // @ts-ignore
              getViewer: () => getViewerVBBH(detailVanBanBH.ID),
              // @ts-ignore
              getOtherDepartment: () => getWorkflowHistoryOtherDepartmentVBBH(detailVanBanBH.ID),
              isVBDen: true,
              itemVB: detailVanBanBH
            });
          }}>
            <Image style={{ height: 25, width: 25 }} resizeMode={"stretch"}
              source={require("../../../../assets/images/icon_proce.png")} />
          </TouchableOpacity> :
            <View />
        }
        onPress={() => {
          navigation.goBack();
        }} />

      {
        detailVanBanBH != undefined
          ? <View style={{ flex: 1 }}>

            <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row" }}>
              <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>{detailVanBanBH.TrichYeu}</Text>
            </View>

            <View style={{
              flex: 1,
              backgroundColor: "white"
            }}>

              <ScrollView style={{ flex: 1, backgroundColor: "white" }}>
                <View style={{ flex: 1, backgroundColor: "white", marginHorizontal: 10 }}>
                  {isViewDetail && <DetailVBBH vBBH={detailVanBanBH} />}
                  {
                    //@ts-ignore
                    lstAttachment != null && lstAttachment.length > 0 ?
                      <ListAttachment data={lstAttachment} onClick={(item: any) => onClickAttachment(item)} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstBODIdea != null && lstBODIdea.length > 0 ? <ListIdea data={lstBODIdea} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstTCTH != null && lstTCTH.length > 0 ? <ListDepartmentTask data={lstTCTH} OnPress={(item) => {
                      onClickDepartmentTask(item);
                    }} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstDVTH != null && lstDVTH.length > 0 ? <ListUnitTask data={lstDVTH} />
                      : null
                  }

                </View>
              </ScrollView>

              <View style={{
                width: 50,
                height: 40,
                position: "absolute",
                top: 0,
                right: 0
                // justifyContent: 'flex-end',
              }}>
                <CustomImageButton imgPath={require("../../../../assets/images/icon_more_detail.png")}
                  //@ts-ignore
                  imgColor={isViewDetail ? appMainBlueColor : "black"} onClickHandle={() => {
                    setIsViewDetail(!isViewDetail);
                  }} />
              </View>

            </View>
            {
              //@ts-ignore
              lstAction != undefined && lstAction.length > 0 &&
              <View style={{ width: "100%", height: 60 }}>
                <BottomAction data={lstAction} onPressAction={handlePressShowAction} />
              </View>
            }
          </View>
          :
          isLoading ? <LoadingScreen /> : <EmptyView />
      }
    </View>
    {
      isShowMoreAction && <MoreAction actionJson={lstAction} onPressAcion={handlePressShowAction}
        onPressCancel={() => setShowMoreAction(false)} />
    }
    {
      isShowPopup && <RootPopUpContainer
        type={"VBDen"}
        //@ts-ignore
        action={lstAction.find(item => item.ID == indexAction)}
        cancelPress={() => setShowPopup(false)}
        itemVB={detailVanBanBH}
      />
    }

  </View>;
}