import { FC } from "react"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { Text, View } from "react-native";
import { HeaderValueTextView } from "../../../../../components/headerValueTextView";
import { isNullOrEmpty } from "../../../../../utils/functions";

interface Props {
    dataForm: BeanVBDi
}
export const ItemFormVanBanDi:FC<Props>=({dataForm})=>{
    return <View>
        <HeaderValueTextView headerText={"Loại văn bản"} valueText={isNullOrEmpty(dataForm.DepartmentTitle)?"":dataForm.DepartmentTitle}/>
        <HeaderValueTextView headerText={"Đơn vị soạn thảo"} valueText={isNullOrEmpty(dataForm.CodeDocumentTypeTitle)?"":dataForm.CodeDocumentTypeTitle}/>
        <HeaderValueTextView headerText={"Ký thừa lệnh"} valueText={dataForm.IsDelegate!=null?"Thừa lệnh ủy quyền":"Không"}/>
    </View>
}