import { FC } from "react"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { View } from "react-native"
import { HeaderValueTextView } from "../../../../../components/headerValueTextView"
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions"

interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLKhac: FC<Props> = ({ dataForm }) => {
    return <View>
        <HeaderValueTextView headerText={"Tên hồ sơ"}
            valueText={isNullOrEmpty(dataForm.DocumentName) ?
                "" :
                dataForm.DocumentName}
        />
        <HeaderValueTextView headerText={"Nội dung"}
            valueText={isNullOrEmpty(dataForm.Subject) ? ""
                : dataForm.Subject} />
        <HeaderValueTextView headerText={"Lĩnh Vực"}
            valueText={isNullOrEmpty(dataForm.CodeFieldTitle) ? ""
                : dataForm.CodeFieldTitle} />
        <HeaderValueTextView headerText={"Nơi lưu"} valueText={isNullOrEmpty(dataForm.NoiLuu) ? "" : dataForm.NoiLuu} />
        <HeaderValueTextView headerText={"Hồ sơ"} valueText={isNullOrEmpty(dataForm.HoSoTitle) ? "" : dataForm.HoSoTitle} />
    </View>
}