import { useRoute } from "@react-navigation/native"
import { useEffect, useState } from "react";
import { Text } from "react-native";
import { BeanTaskDocument } from "../../../../services/database/models/beanTaskDocument";
import { EnumTaskRole } from "../../../../config/enum";
import { LoadingScreen } from "../../../../components/loadingScreen";
import { NhiemVuDaPhanCongView } from "./nhiemVuDaPhanCongView";
import { TaskDetailScreen } from "./taskDetailScreen";
import { View } from "react-native";
//item: _taskVBDen,
//               itemVB: item,
//               isVBDen: false,
//               lstBODIdea: lstBODIdea,
export const RooTaskScreen = () => {
    const route = useRoute();
    const [itemTask, setItemTask] = useState<BeanTaskDocument>();
    //@ts-ignore
    const checkType = route.params['checkType'];
    //@ts-ignore
    const itemVB = route.params['itemVB'];
    //@ts-ignore
    const isVBDen = route.params['isVBDen'];
    //@ts-ignore
    const lstBODIdea = route.params['lstBODIdea'];
    //@ts-ignore
    const lstAttachment = route.params['lstAttachment'];


    useEffect(() => {
        checkType().then((value: BeanTaskDocument) => {
            setItemTask(value);
        });
    }, [])


    const DetailTaskScreen = () => {
        if (itemTask != undefined) {
            switch (itemTask.Role) {
                case EnumTaskRole.Assignor://Form người chuyển
                case EnumTaskRole.AssignorPBan:
                    return <NhiemVuDaPhanCongView item={itemTask} itemVB={itemVB} isVBDen={false} lstBODIdea={lstBODIdea} />

                case EnumTaskRole.AssignedTo: //Form người nhận
                case EnumTaskRole.Viewer://nguoi xem                
                    return <TaskDetailScreen item={itemTask} itemVB={itemVB} isVBDen={false} lstBODIdea={lstBODIdea} lstAttachment={lstAttachment} />
                default:
                    return <View/>;
            }

        }
        else {
            return <LoadingScreen />
        }
    }
    return <DetailTaskScreen />
}