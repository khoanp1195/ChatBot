import { showAlert } from "../../commonAlertView";

// @ts-ignore
export const gotoDetailDocs = (navigation, item) => {
  console.log("data click", item);
  switch (item.ModuleId) {
    case 9:
    case 7:
      navigation.navigate('VBDiDetailScreen', { item });
      break;
    case 8:
      navigation.navigate('VBBHDetailScreen', { item });
      break;
    case 10:
    case 11:
    case 12:
      showAlert("Tính năng đang phát triển");
      break;
    default:
      navigation.navigate('VBDenDetailScreen', { item });
      break;
  }
  // navigation.navigate('detail',{item})
}
