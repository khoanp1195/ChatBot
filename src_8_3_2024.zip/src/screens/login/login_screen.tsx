import React, { useCallback, useEffect, useState } from "react";
import { View, StyleSheet, Alert, ImageBackground, TextInput, Image, Text, Pressable, Keyboard } from "react-native";
import { Input, Button } from "react-native-elements";
import { soapAuth } from "../../services/api/soap_service.ts";
import strings from "../../assets/strings.ts";
import { useDispatch, useSelector } from "react-redux";
import {
  loginRequest,
  loginSuccess,
  logout
} from "../../stores/login/actions.ts";
import { getPassword, getUsername, saveModified } from "../../utils/async_storage.ts";
import { getAllData,  isNullOrEmpty } from "../../utils/functions.ts";
import { getCurrentUser } from "../../services/api/api_data.ts";



const LoginScreen = () => {
  const dispatch = useDispatch();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { loading } = useSelector((state: any) => state.login);

  const relogin = useCallback(async () => {
    if (loading) {
      const user = await getUsername();
      const pass = await getPassword();
      if (!isNullOrEmpty(user) && !isNullOrEmpty(pass)) {
        soapAuth(user!, pass!).then(async isAuth => {
          if (isAuth) {
            const result=await getAllData(true);
            if(result)
            {
              dispatch(loginSuccess());
            }
            else {
              dispatch(logout());
              Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
            }
          } else {
            dispatch(logout());
            Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
          }
        });
      } else {
        dispatch(logout());
      }
    }
  }, [dispatch]);
  useEffect(() => {
    relogin();
  }, [relogin]);
  const handleLogin = () => {
    if (username !== "" && password !== "") {
      dispatch(loginRequest());
      soapAuth(username, password).then(async isAuth => {
        if (isAuth) {
          const result=await getAllData();
          if(result)
          {
            dispatch(loginSuccess());
          }
          else {
            dispatch(logout());
            Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
          }
        } else {
          dispatch(logout());
          Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
        }
      });
    } else {
      dispatch(logout());
      Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
    }
  };
  return (
    <Pressable style={{flex:1}} onPress={Keyboard.dismiss}>
      <ImageBackground
        source={require("../../assets/images/icon_splashscreen.png")}
        style={[styles.container, { justifyContent: loading ? "flex-end" : "center" }]}>
        {!loading ? (
            <View style={styles.loginContainer}>
              <View style={styles.inputContainer}>
                <Image style={styles.iconInput} source={require("../../assets/images/icon_login_username.png")} />
                <TextInput
                  style={styles.input}
                  placeholder="Tên đăng nhập"
                  autoCapitalize='none'
                  value={username}
                  onChangeText={(text) => setUsername(text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <Image style={styles.iconInput} source={require("../../assets/images/icon_login_password.png")} />
                <TextInput
                  style={styles.input}
                  placeholder="Mật khẩu"
                  secureTextEntry
                  value={password}
                  onChangeText={text => setPassword(text)}
                />
              </View>
              <View style={styles.containerButtonLogin}>
                <Button title="Đăng nhập" onPress={handleLogin} />
              </View>
            </View>
          ) :

          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading...</Text>
          </View>}
      </ImageBackground>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  loginContainer: {

    paddingHorizontal: "3%"
  },
  loadingText: {
    color: "#000000",
    fontStyle: "italic"
  },
  loadingContainer: {
    width: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.45)",
    padding: 5,
    alignItems: "center",
    marginBottom: 10
  },
  containerButtonLogin: {
    paddingHorizontal: 10
  },
  container: {
    flex: 1
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 5,
    paddingHorizontal: 5,
    margin: 10
  },
  input: {
    flex: 1,
    paddingVertical: 10
  },
  iconInput: {
    height: 20,
    width: 20,
    marginRight: 5,
  }
});

export default LoginScreen;
